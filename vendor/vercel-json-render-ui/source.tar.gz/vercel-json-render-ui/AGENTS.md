# Repository guidance

This is a standalone Vite + React + TypeScript Json Render workbench.

- Keep `src/json-render/catalog/catalog.ts` as the complete reference contract copied from the dashboard. Do not trim it merely because the starter registry implements fewer components.
- Keep runtime UI components in the smaller `chatCatalog` and typed `chatRegistry`; adding a schema to the reference catalog does not make it safe to render.
- Keep backend work behind `ChatAdapter`. The default application must remain usable with no credentials, OP-DBUS service, gRPC code, or network backend.
- Preserve accessible labels, keyboard behavior, visible focus states, and `aria-live` status messaging.
- Run `npm run type-check`, `npm run lint`, `npm test`, and `npm run build` before committing.
