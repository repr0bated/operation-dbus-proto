import { Renderer } from "@json-render/react";
import { antigravitySpec } from "../json-render/pages/antigravity.pagespec";
import {
  JsonRenderProvider,
  useJsonRender,
} from "../json-render/runtime/JsonRenderProvider";

function ChatOnlySurface() {
  const { registry } = useJsonRender();
  return (
    <main className="chat-only-page">
      <Renderer key="chat-only" spec={antigravitySpec} registry={registry} />
    </main>
  );
}

export default function ChatOnlyPage() {
  return (
    <JsonRenderProvider>
      <ChatOnlySurface />
    </JsonRenderProvider>
  );
}
