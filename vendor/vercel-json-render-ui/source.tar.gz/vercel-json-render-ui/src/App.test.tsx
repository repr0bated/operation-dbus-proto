import { fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import { cleanup } from "@testing-library/react";
import App from "./App";

afterEach(() => cleanup());

describe("ChatOnly home page", () => {
  it("renders the local Json Render workbench at the root", () => {
    render(<App />);

    expect(
      screen.getByRole("heading", { level: 1, name: "Antigravity Chat" }),
    ).toBeInTheDocument();
    expect(screen.getByLabelText("Local model routing")).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Golden workbench" })).toBeInTheDocument();
    expect(screen.getAllByRole("button", { name: /Reorder Canvas tile/i })).toHaveLength(6);
  });

  it("adds a local user message and deterministic assistant response", async () => {
    render(<App />);
    const input = screen.getByRole("textbox", { name: "Message" });

    fireEvent.change(input, {
      target: { value: "Build an incident triage board" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Send" }));

    expect(screen.getByText("Build an incident triage board")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Sending" })).toBeDisabled();
    expect(
      await screen.findByText(/Local adapter acknowledged:/, {}, { timeout: 1600 }),
    ).toHaveTextContent("Build an incident triage board");
    expect(screen.getByRole("button", { name: "Send" })).toBeDisabled();
  });
});
