# Vercel Json Render UI

A fresh, standalone React workbench for developing schema-rendered interfaces with Vercel's published `@json-render/core` and `@json-render/react` packages.

The `/` route is a self-contained port of the operation dashboard's ChatOnly surface: no sidebar, top bar, authentication flow, OP-DBUS service, gRPC client, generated protocol code, credentials, or backend is required. A deterministic in-memory adapter powers the conversation and local routing controls.

## Start locally

Requirements: Node.js 22.22.2 or newer and npm.

```bash
npm install
npm run dev
```

Then open the URL printed by Vite. The default adapter makes no network calls.

## Publish through the Rust HTTP server

The OP-DBUS Rust `op-web-server` already owns port `8080` and serves files from
`OP_WEB_STATIC_DIR` (normally `/usr/local/share/op-dbus/dashboard`). Publish this
standalone workbench beneath its own `/vercel-json-render/` path without replacing the
main dashboard:

```bash
npm run deploy:op-web
```

With the private relay active, open
`http://10.0.0.1:8080/vercel-json-render/` from the OpenWrt LAN.

The deploy script builds with Vite's base URL set to `/vercel-json-render/`, copies the
hashed assets first, and installs `index.html` last. Override the mount path or
static directory when testing or deploying elsewhere:

```bash
URL_PREFIX=/workbench/ OP_WEB_STATIC_DIR=/tmp/dashboard npm run deploy:op-web
```

## Why there are two catalogs

`src/json-render/catalog/catalog.ts` is the complete dashboard `appCatalog` contract copied as a future-facing reference. Its component and action names, descriptions, schemas, stream plugin expansion, and source attribution remain intact. It is intentionally **not** paired with a runnable registry because many of those components depend on the dashboard's event stream, hosted pages, gRPC methods, and application shell.

`src/json-render/catalog/chat-catalog.ts` is the smaller trusted runtime catalog. It contains the five direct elements used by the adapted `antigravitySpec` (`container`, `pageHeader`, `tchedRouterPicker`, `antigravityChatContainer`, and `chatMessage`) plus an implemented local Canvas vocabulary (`autoTile`, `autoTileItem`, `heading`, `text`, `badge`, `row`, and `stat`). `chatRegistry` implements every one of those schemas, so any spec rendered by the starter has a known local component.

The Canvas uses a dense 12-column, golden-ratio/Mondrian-like tile pattern. Tile spans follow deterministic phi-ish proportions, then resize and repack when reordered. Drag handles support pointer input and the DnD Kit keyboard interaction: focus a handle, press Space, move with the arrow keys, and press Space again to drop. Narrow screens fall back to a reachable vertical board.

## Backend adapter boundary

The UI talks only to the `ChatAdapter` interface in `src/chat/chat-adapter.ts`:

```ts
import type { ChatAdapter } from "./src/chat/chat-adapter";

export const backendAdapter: ChatAdapter = {
  kind: "remote",
  providers: [
    {
      id: "production-router",
      label: "Production router",
      models: [
        { id: "model-id", label: "Model label", detail: "Backend route" },
      ],
    },
  ],
  async selectRoute(selection) {
    // Persist or validate the selected backend route.
    return selection;
  },
  async submit(request) {
    // Send request.message, request.history, and request.route to your backend.
    // Return an assistant ChatMessage and, optionally, a validated Json Render Spec.
    return {
      message: { id: "server-1", role: "agent", content: "Connected." },
      canvasSpec: undefined,
    };
  },
};
```

Pass the implementation to `JsonRenderProvider` as its `adapter` prop. A streaming implementation can accumulate server deltas inside the adapter and resolve with the final message/spec; the page catalog and registry do not need backend-specific imports.

## Project map

```text
src/
  chat/                         adapter contract, local adapter, runtime context
  json-render/
    catalog/catalog.ts          full copied reference contract
    catalog/stream-plugins.ts   complete copied plugin list
    catalog/chat-catalog.ts     runnable local schemas
    catalog/chat-registry.tsx   typed React registry and Canvas DnD
    pages/antigravity.pagespec.ts
    runtime/JsonRenderProvider.tsx
  pages/ChatOnlyPage.tsx
```

## Verification

```bash
npm run type-check
npm run lint
npm test
npm run build
```

The package versions were checked against the npm registry when this repository was scaffolded. TypeScript 6.0 is used instead of the newer 7.x line because it is the current release compatible with `typescript-eslint`'s declared peer range. The committed lockfile pins the resolved dependency graph.

## Provenance and license

The copied catalog contract and stream plugin list came from `repr0bated/operation-dashboard-ui-07` at commit `1e72483c4227d12820419d4a901f3ef3dbf77dc9`; see [NOTICE](./NOTICE). Json Render is distributed by Vercel under Apache-2.0. The applicable license text is retained in [LICENSE](./LICENSE). No upstream package internals or Git history were copied.
