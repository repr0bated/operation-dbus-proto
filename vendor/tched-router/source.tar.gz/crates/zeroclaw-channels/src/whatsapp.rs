use async_trait::async_trait;
use regex::Regex;
use std::collections::HashMap;
use std::sync::{Arc, LazyLock};
use tokio::sync::{Mutex, oneshot};
use uuid::Uuid;
use zeroclaw_api::channel::{
    Channel, ChannelApprovalRequest, ChannelApprovalResponse, ChannelMessage, SendMessage,
};

type PendingApprovalsMap = Mutex<HashMap<String, oneshot::Sender<ChannelApprovalResponse>>>;
static PENDING_APPROVALS: LazyLock<Arc<PendingApprovalsMap>> =
    LazyLock::new(|| Arc::new(Mutex::new(HashMap::new())));

fn ensure_https(url: &str) -> anyhow::Result<()> {
    if !url.starts_with("https://") {
        anyhow::bail!(
            "Refusing to transmit sensitive data over non-HTTPS URL: URL scheme must be https"
        );
    }
    Ok(())
}

pub struct WhatsAppChannel {
    access_token: String,
    endpoint_id: String,
    verify_token: String,
    /// The alias key under `[channels.whatsapp.<alias>]` this handle is
    /// bound to. Used to scope peer-group writes and resolver lookups.
    alias: String,
    /// Resolves inbound external peers from canonical state at message-time.
    /// No cache (see AGENTS.md "ABSOLUTE RULE — SINGLE SOURCE OF TRUTH").
    peer_resolver: Arc<dyn Fn() -> Vec<String> + Send + Sync>,
    /// Per-channel proxy URL override.
    proxy_url: Option<String>,
    /// Compiled mention patterns for DM mention gating.
    dm_mention_patterns: Vec<Regex>,
    /// Compiled mention patterns for group-chat mention gating.
    group_mention_patterns: Vec<Regex>,
    /// Seconds to wait for an operator reply to a `request_approval` prompt
    /// before treating the silence as a deny. Default 300.
    approval_timeout_secs: u64,
}

impl WhatsAppChannel {
    pub fn new(
        access_token: String,
        endpoint_id: String,
        verify_token: String,
        alias: impl Into<String>,
        peer_resolver: Arc<dyn Fn() -> Vec<String> + Send + Sync>,
    ) -> Self {
        Self {
            access_token,
            endpoint_id,
            verify_token,
            alias: alias.into(),
            peer_resolver,
            proxy_url: None,
            dm_mention_patterns: Vec::new(),
            group_mention_patterns: Vec::new(),
            approval_timeout_secs: 300,
        }
    }

    /// Return the alias under `[channels.whatsapp.<alias>]` that this
    /// channel handle is bound to.
    pub fn alias(&self) -> &str {
        &self.alias
    }

    pub fn with_approval_timeout_secs(mut self, secs: u64) -> Self {
        self.approval_timeout_secs = secs;
        self
    }

    /// Access the process-wide pending-approvals map shared across every
    /// `WhatsAppChannel` instance. See [`PENDING_APPROVALS`] for why this
    /// must be a static rather than per-instance.
    pub fn pending_approvals(&self) -> &Arc<PendingApprovalsMap> {
        &PENDING_APPROVALS
    }

    /// Set a per-channel proxy URL that overrides the global proxy config.
    pub fn with_proxy_url(mut self, proxy_url: Option<String>) -> Self {
        self.proxy_url = proxy_url;
        self
    }

    /// Set mention patterns for DM mention gating.
    /// Each pattern string is compiled as a case-insensitive regex.
    /// Invalid patterns are logged and skipped.
    pub fn with_dm_mention_patterns(mut self, patterns: Vec<String>) -> Self {
        self.dm_mention_patterns = Self::compile_mention_patterns(&patterns);
        self
    }

    /// Set mention patterns for group-chat mention gating.
    /// Each pattern string is compiled as a case-insensitive regex.
    /// Invalid patterns are logged and skipped.
    pub fn with_group_mention_patterns(mut self, patterns: Vec<String>) -> Self {
        self.group_mention_patterns = Self::compile_mention_patterns(&patterns);
        self
    }

    /// Compile raw pattern strings into case-insensitive regexes.
    /// Invalid or excessively large patterns are logged and skipped.
    pub fn compile_mention_patterns(patterns: &[String]) -> Vec<Regex> {
        patterns
            .iter()
            .filter_map(|p| {
                let trimmed = p.trim();
                if trimmed.is_empty() {
                    return None;
                }
                match regex::RegexBuilder::new(trimmed)
                    .case_insensitive(true)
                    .size_limit(1 << 16) // 64 KiB — guard against ReDoS
                    .build()
                {
                    Ok(re) => Some(re),
                    Err(e) => {
                        ::zeroclaw_log::record!(
                            WARN,
                            ::zeroclaw_log::Event::new(
                                module_path!(),
                                ::zeroclaw_log::Action::Note
                            )
                            .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                            .with_attrs(
                                ::serde_json::json!({"trimmed": trimmed, "e": e.to_string()})
                            ),
                            "ignoring invalid mention_pattern"
                        );
                        None
                    }
                }
            })
            .collect()
    }

    /// Check whether `text` matches any pattern in the given slice.
    pub fn text_matches_patterns(patterns: &[Regex], text: &str) -> bool {
        patterns.iter().any(|re| re.is_match(text))
    }

    pub fn apply_mention_gating(
        dm_patterns: &[Regex],
        group_patterns: &[Regex],
        content: &str,
        is_group: bool,
    ) -> Option<String> {
        let patterns = if is_group {
            group_patterns
        } else {
            dm_patterns
        };
        if patterns.is_empty() {
            return Some(content.to_string());
        }
        if !Self::text_matches_patterns(patterns, content) {
            return None;
        }
        Some(content.to_string())
    }

    /// Detect group messages in the WhatsApp Cloud API webhook payload.
    /// A message is considered a group message when it carries a `context`
    /// object containing a non-empty `group_id` field.
    fn is_group_message(msg: &serde_json::Value) -> bool {
        msg.get("context")
            .and_then(|ctx| ctx.get("group_id"))
            .and_then(|g| g.as_str())
            .is_some_and(|s| !s.is_empty())
    }

    fn http_client(&self) -> reqwest::Client {
        zeroclaw_config::schema::build_channel_proxy_client(
            "channel.whatsapp",
            self.proxy_url.as_deref(),
        )
    }

    /// Check if a phone number is allowed (E.164 format: +1234567890)
    fn is_number_allowed(&self, phone: &str) -> bool {
        let peers = (self.peer_resolver)();
        crate::allowlist::is_user_allowed(&peers, phone, crate::allowlist::Match::Sensitive)
    }

    /// Get the verify token for webhook verification
    pub fn verify_token(&self) -> &str {
        &self.verify_token
    }

    /// Parse an incoming webhook payload from Meta and extract messages
    pub fn parse_webhook_payload(&self, payload: &serde_json::Value) -> Vec<ChannelMessage> {
        let mut messages = Vec::new();

        // WhatsApp Cloud API webhook structure:
        // { "object": "whatsapp_business_account", "entry": [...] }
        let Some(entries) = payload.get("entry").and_then(|e| e.as_array()) else {
            return messages;
        };

        for entry in entries {
            let Some(changes) = entry.get("changes").and_then(|c| c.as_array()) else {
                continue;
            };

            for change in changes {
                let Some(value) = change.get("value") else {
                    continue;
                };

                // Extract messages array
                let Some(msgs) = value.get("messages").and_then(|m| m.as_array()) else {
                    continue;
                };

                for msg in msgs {
                    // Get sender phone number
                    let Some(from) = msg.get("from").and_then(|f| f.as_str()) else {
                        continue;
                    };

                    // Check allowlist
                    let normalized_from = if from.starts_with('+') {
                        from.to_string()
                    } else {
                        format!("+{from}")
                    };

                    if !self.is_number_allowed(&normalized_from) {
                        ::zeroclaw_log::record!(
                            WARN,
                            ::zeroclaw_log::Event::new(
                                module_path!(),
                                ::zeroclaw_log::Action::Note
                            )
                            .with_outcome(::zeroclaw_log::EventOutcome::Unknown)
                            .with_attrs(::serde_json::json!({"normalized_from": normalized_from})),
                            "ignoring message from unauthorized number: . Add to channels.whatsapp.allowed_numbers in config.toml, or run `zeroclaw config set channels.whatsapp.allowed-numbers='[\"<msisdn>\"]'`."
                        );
                        continue;
                    }

                    // Extract content. Four shapes that produce a usable
                    // text body:
                    //   1. text       — plain message; .text.body
                    //   2. location   — geographic coordinates and optional name
                    //   3. interactive.button_reply  — user tapped a button
                    //                                  in an interactive message
                    //   4. interactive.list_reply    — user picked a row in
                    //                                  an interactive list
                    //
                    // For (2) and (3), surface the option's `id` as
                    // `[choice]<id>` so consumers can correlate it with the
                    // original option set; consumers that don't care can
                    // ignore the prefix.
                    let content = if let Some(text_obj) = msg.get("text") {
                        let Some(body) = text_obj.get("body").and_then(|b| b.as_str()) else {
                            continue;
                        };
                        body.to_string()
                    } else if let Some(loc) = msg.get("location") {
                        let lat = loc.get("latitude").and_then(|v| v.as_f64());
                        let lng = loc.get("longitude").and_then(|v| v.as_f64());
                        match (lat, lng) {
                            (Some(lat), Some(lng)) => crate::util::format_location_content(
                                lat,
                                lng,
                                loc.get("name").and_then(|v| v.as_str()),
                            ),
                            // Missing coordinates — drop rather than fabricate 0,0.
                            _ => {
                                ::zeroclaw_log::record!(
                                    DEBUG,
                                    ::zeroclaw_log::Event::new(
                                        module_path!(),
                                        ::zeroclaw_log::Action::Note
                                    )
                                    .with_attrs(::serde_json::json!({"from": from})),
                                    "skipping location message without coordinates"
                                );
                                continue;
                            }
                        }
                    } else if let Some(interactive) = msg.get("interactive") {
                        let kind = interactive
                            .get("type")
                            .and_then(|t| t.as_str())
                            .unwrap_or("");
                        let reply = match kind {
                            "button_reply" => interactive.get("button_reply"),
                            "list_reply" => interactive.get("list_reply"),
                            _ => None,
                        };
                        match reply.and_then(|r| r.get("id")).and_then(|i| i.as_str()) {
                            Some(id) if !id.is_empty() => format!("[choice]{id}"),
                            _ => {
                                ::zeroclaw_log::record!(
                                    DEBUG,
                                    ::zeroclaw_log::Event::new(
                                        module_path!(),
                                        ::zeroclaw_log::Action::Note
                                    )
                                    .with_attrs(::serde_json::json!({"from": from})),
                                    "WhatsApp interactive reply missing id, dropping"
                                );
                                continue;
                            }
                        }
                    } else {
                        // Could be image, audio, etc. — skip for now
                        ::zeroclaw_log::record!(
                            DEBUG,
                            ::zeroclaw_log::Event::new(
                                module_path!(),
                                ::zeroclaw_log::Action::Note
                            )
                            .with_attrs(::serde_json::json!({"from": from})),
                            "skipping non-text message from"
                        );
                        continue;
                    };

                    if content.is_empty() {
                        continue;
                    }

                    // Mention-pattern gating: apply dm_mention_patterns for
                    // DMs and group_mention_patterns for groups. When the
                    // applicable pattern set is non-empty, messages without a
                    // match are dropped and matched fragments are stripped.
                    //
                    // Bypass for native-interactive replies: a `[choice]<id>`
                    // body comes from the user tapping a button or list row
                    // we sent — the bot's own UI counts as an explicit
                    // interaction with the bot, so the mention requirement
                    // (intended to gate freeform messages) does not apply.
                    let is_group = Self::is_group_message(msg);
                    let content = if content.starts_with("[choice]") {
                        content
                    } else {
                        match Self::apply_mention_gating(
                            &self.dm_mention_patterns,
                            &self.group_mention_patterns,
                            &content,
                            is_group,
                        ) {
                            Some(c) => c,
                            None => {
                                ::zeroclaw_log::record!(
                                    DEBUG,
                                    ::zeroclaw_log::Event::new(
                                        module_path!(),
                                        ::zeroclaw_log::Action::Note
                                    )
                                    .with_attrs(::serde_json::json!({"from": from})),
                                    "WhatsApp message did not match mention patterns, dropping"
                                );
                                continue;
                            }
                        }
                    };

                    // Get timestamp
                    let timestamp = msg
                        .get("timestamp")
                        .and_then(|t| t.as_str())
                        .and_then(|t| t.parse::<u64>().ok())
                        .unwrap_or_else(|| {
                            std::time::SystemTime::now()
                                .duration_since(std::time::UNIX_EPOCH)
                                .unwrap_or_default()
                                .as_secs()
                        });

                    messages.push(ChannelMessage {
                        id: Uuid::new_v4().to_string(),
                        reply_target: normalized_from.clone(),
                        sender: normalized_from,
                        content,
                        channel: "whatsapp".to_string(),
                        channel_alias: Some(self.alias.clone()),
                        timestamp,
                        thread_ts: None,
                        interruption_scope_id: None,
                        attachments: vec![],
                        subject: None,

                        ..Default::default()
                    });
                }
            }
        }

        messages
    }

    /// Send an interactive button message (≤ 3 buttons per Meta's Cloud
    /// API limit). Each tuple is `(id, label)`; `id` round-trips back
    /// through the inbound `interactive.button_reply.id` field as a
    /// `[choice]<id>` synthetic `ChannelMessage` content (see
    /// `parse_webhook_payload`).
    ///
    /// Meta's `interactive` body schema:
    /// https://developers.facebook.com/docs/whatsapp/cloud-api/reference/messages
    pub async fn send_interactive_buttons(
        &self,
        recipient: &str,
        body_text: &str,
        buttons: &[(String, String)],
    ) -> anyhow::Result<()> {
        if buttons.is_empty() || buttons.len() > 3 {
            anyhow::bail!(
                "WhatsApp interactive buttons require 1..=3 options (got {}); \
                 use send_interactive_list for more",
                buttons.len()
            );
        }
        let url = format!(
            "https://graph.facebook.com/v18.0/{}/messages",
            self.endpoint_id
        );
        ensure_https(&url)?;
        let to = recipient.strip_prefix('+').unwrap_or(recipient);
        let action_buttons: Vec<serde_json::Value> = buttons
            .iter()
            .map(|(id, label)| {
                // Meta caps button title at 20 chars and id at 256.
                let title = label.chars().take(20).collect::<String>();
                let id_trim = id.chars().take(256).collect::<String>();
                serde_json::json!({
                    "type": "reply",
                    "reply": { "id": id_trim, "title": title },
                })
            })
            .collect();
        let body = serde_json::json!({
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to,
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": { "text": body_text },
                "action": { "buttons": action_buttons },
            }
        });
        self.post_to_meta(&url, &body).await
    }

    /// Send an interactive list message (more than 3 options, up to 10
    /// rows per section, up to 10 sections per Meta's limits). `sections`
    /// each carry a section title + rows. Each row's `id` round-trips
    /// through the inbound `interactive.list_reply.id` as `[choice]<id>`.
    ///
    /// `button_text` is the button label that opens the list (Meta limits
    /// to 20 chars).
    pub async fn send_interactive_list(
        &self,
        recipient: &str,
        body_text: &str,
        button_text: &str,
        sections: &[InteractiveListSection],
    ) -> anyhow::Result<()> {
        if sections.is_empty() {
            anyhow::bail!("WhatsApp interactive list requires at least one section");
        }
        if sections.len() > 10 {
            anyhow::bail!(
                "WhatsApp interactive list capped at 10 sections (got {})",
                sections.len()
            );
        }
        for s in sections {
            if s.rows.len() > 10 {
                anyhow::bail!(
                    "WhatsApp interactive list section '{}' capped at 10 rows (got {})",
                    s.title,
                    s.rows.len()
                );
            }
        }
        let url = format!(
            "https://graph.facebook.com/v18.0/{}/messages",
            self.endpoint_id
        );
        ensure_https(&url)?;
        let to = recipient.strip_prefix('+').unwrap_or(recipient);
        let action_sections: Vec<serde_json::Value> = sections
            .iter()
            .map(|s| {
                let rows: Vec<serde_json::Value> = s
                    .rows
                    .iter()
                    .map(|r| {
                        let mut row = serde_json::json!({
                            "id": r.id.chars().take(200).collect::<String>(),
                            "title": r.title.chars().take(24).collect::<String>(),
                        });
                        if let Some(d) = &r.description {
                            row["description"] =
                                serde_json::Value::String(d.chars().take(72).collect());
                        }
                        row
                    })
                    .collect();
                serde_json::json!({
                    "title": s.title.chars().take(24).collect::<String>(),
                    "rows": rows,
                })
            })
            .collect();
        let body = serde_json::json!({
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to,
            "type": "interactive",
            "interactive": {
                "type": "list",
                "body": { "text": body_text },
                "action": {
                    "button": button_text.chars().take(20).collect::<String>(),
                    "sections": action_sections,
                },
            }
        });
        self.post_to_meta(&url, &body).await
    }

    async fn post_to_meta(&self, url: &str, body: &serde_json::Value) -> anyhow::Result<()> {
        let resp = self
            .http_client()
            .post(url)
            .bearer_auth(&self.access_token)
            .header("Content-Type", "application/json")
            .json(body)
            .send()
            .await?;
        if !resp.status().is_success() {
            let status = resp.status();
            let error_body = resp.text().await.unwrap_or_default();
            ::zeroclaw_log::record!(ERROR, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail).with_outcome(::zeroclaw_log::EventOutcome::Failure).with_attrs(::serde_json::json!({"status": status.to_string(), "error_body": error_body})), "WhatsApp interactive send failed:");
            anyhow::bail!("WhatsApp API error: {status}");
        }
        Ok(())
    }
}

/// One section in an interactive list message. Sections group related
/// rows under a header.
#[derive(Debug, Clone)]
pub struct InteractiveListSection {
    /// Section header (Meta caps at 24 chars; we truncate).
    pub title: String,
    /// Rows in this section. Up to 10 per Meta's limit.
    pub rows: Vec<InteractiveListRow>,
}

/// One row in an interactive list message.
#[derive(Debug, Clone)]
pub struct InteractiveListRow {
    /// Stable identifier round-tripped via inbound `interactive.list_reply.id`
    /// as `[choice]<id>`.
    pub id: String,
    /// User-visible label (Meta caps at 24 chars).
    pub title: String,
    /// Optional secondary line (Meta caps at 72 chars).
    pub description: Option<String>,
}

impl WhatsAppChannel {
    /// POST one message body to the Cloud API `/messages` endpoint.
    async fn post_message(&self, body: serde_json::Value) -> anyhow::Result<()> {
        // WhatsApp Cloud API: POST to /v18.0/{phone_number_id}/messages
        let url = format!(
            "https://graph.facebook.com/v18.0/{}/messages",
            self.endpoint_id
        );
        ensure_https(&url)?;

        let resp = self
            .http_client()
            .post(&url)
            .bearer_auth(&self.access_token)
            .header("Content-Type", "application/json")
            .json(&body)
            .send()
            .await?;

        if !resp.status().is_success() {
            let status = resp.status();
            // `None` when the error body itself could not be read.
            let error_body = resp.text().await.ok();
            ::zeroclaw_log::record!(ERROR, ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Fail).with_outcome(::zeroclaw_log::EventOutcome::Failure).with_attrs(::serde_json::json!({"status": status.to_string(), "error_body": error_body})), "send failed:");
            anyhow::bail!("WhatsApp API error: {status}");
        }

        Ok(())
    }
}

/// The marker kinds the Cloud API backend extracts from outgoing text.
const LOCATION_MARKER_KIND: &[&str] = &["LOCATION"];

fn text_message_body(to: &str, content: &str) -> serde_json::Value {
    serde_json::json!({
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": to,
        "type": "text",
        "text": {
            "preview_url": false,
            "body": content
        }
    })
}

fn location_message_body(to: &str, loc: &crate::util::WhatsAppLocation) -> serde_json::Value {
    // Meta's location-messages contract quotes outbound coordinates as
    // strings (inbound webhooks deliver them as numbers — the asymmetry is
    // theirs, see the official location-messages reference).
    let mut location = serde_json::json!({
        "latitude": loc.lat.to_string(),
        "longitude": loc.lng.to_string(),
    });
    if let Some(name) = &loc.name {
        location["name"] = serde_json::json!(name);
    }
    if let Some(address) = &loc.address {
        location["address"] = serde_json::json!(address);
    }
    serde_json::json!({
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": to,
        "type": "location",
        "location": location
    })
}

impl ::zeroclaw_api::attribution::Attributable for WhatsAppChannel {
    fn role(&self) -> ::zeroclaw_api::attribution::Role {
        ::zeroclaw_api::attribution::Role::Channel(
            ::zeroclaw_api::attribution::ChannelKind::WhatsappBusiness,
        )
    }
    fn alias(&self) -> &str {
        &self.alias
    }
}

#[async_trait]
impl Channel for WhatsAppChannel {
    fn name(&self) -> &str {
        "whatsapp"
    }

    async fn send(&self, message: &SendMessage) -> anyhow::Result<()> {
        // Normalize recipient (remove leading + if present for API)
        let to = match message.recipient.strip_prefix('+') {
            Some(digits) => digits,
            None => &message.recipient,
        };

        // Native location pins ([LOCATION:...]) are the only marker kind this
        // backend can deliver; markers of any other kind stay in the text.
        let (text, location_markers) =
            crate::util::parse_attachment_markers_of_kinds(&message.content, LOCATION_MARKER_KIND);

        if location_markers.is_empty() {
            // No pins: send the content untouched (extraction trims the text).
            return self
                .post_message(text_message_body(to, &message.content))
                .await;
        }

        if !text.is_empty() {
            self.post_message(text_message_body(to, &text)).await?;
        }

        let mut failed_markers = 0usize;
        for (_, target) in &location_markers {
            match crate::util::WhatsAppLocation::parse(target) {
                Some(loc) => self.post_message(location_message_body(to, &loc)).await?,
                None => {
                    ::zeroclaw_log::record!(
                        WARN,
                        ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Reject)
                            .with_outcome(::zeroclaw_log::EventOutcome::Failure)
                            .with_attrs(::serde_json::json!({"reason": "invalid_location"})),
                        "whatsapp: location marker target is malformed or outside WGS84 range"
                    );
                    failed_markers += 1;
                }
            }
        }
        if failed_markers == location_markers.len() && text.is_empty() {
            anyhow::bail!(
                "WhatsApp location marker must be `lat,lng[,name[,address]]` with in-range WGS84 coordinates"
            );
        }

        Ok(())
    }

    async fn send_choice(
        &self,
        recipient: &str,
        prompt: &str,
        options: &[(String, String)],
    ) -> anyhow::Result<()> {
        let trimmed_prompt = prompt.trim();
        // No options → send the prompt as plain text (or no-op when both
        // empty); never render a "(reply with name or number)" hint with
        // nothing under it. Mirrors the trait default's empty guard.
        if options.is_empty() {
            if trimmed_prompt.is_empty() {
                return Ok(());
            }
            return self
                .send(&SendMessage::new(trimmed_prompt, recipient))
                .await;
        }
        // WhatsApp Cloud interactive: ≤ 3 buttons OR up to 10×10 list rows.
        // 1 option falls through to plain text — there's no UX win to a
        // single-button interactive message.
        if options.len() >= 2 && options.len() <= 3 {
            let buttons: Vec<(String, String)> = options
                .iter()
                .map(|(id, label)| (id.clone(), label.clone()))
                .collect();
            return self
                .send_interactive_buttons(recipient, prompt, &buttons)
                .await;
        }
        if options.len() > 3 {
            // List messages: max 10 rows per section, max 10 sections per
            // message → up to 100 options. Chunk into sections of ≤10 rows
            // each so we don't blow past the per-section row cap. Section
            // titles mark the index range so list UIs render cleanly.
            const MAX_ROWS_PER_SECTION: usize = 10;
            const MAX_SECTIONS: usize = 10;
            let max_total = MAX_ROWS_PER_SECTION * MAX_SECTIONS;
            if options.len() > max_total {
                anyhow::bail!(
                    "WhatsApp send_choice: {} options exceeds list cap ({}); split the prompt or call send_interactive_list directly",
                    options.len(),
                    max_total
                );
            }
            let sections: Vec<InteractiveListSection> = options
                .chunks(MAX_ROWS_PER_SECTION)
                .enumerate()
                .map(|(chunk_idx, chunk)| {
                    let start = chunk_idx * MAX_ROWS_PER_SECTION + 1;
                    let end = start + chunk.len() - 1;
                    let title = if options.len() <= MAX_ROWS_PER_SECTION {
                        "Options".to_string()
                    } else {
                        format!("Options {start} to {end}")
                    };
                    InteractiveListSection {
                        title,
                        rows: chunk
                            .iter()
                            .map(|(id, label)| InteractiveListRow {
                                id: id.clone(),
                                title: label.clone(),
                                description: None,
                            })
                            .collect(),
                    }
                })
                .collect();
            return self
                .send_interactive_list(recipient, prompt, "Choose", &sections)
                .await;
        }
        // Exactly 1 option → defer to plain text. (Empty case handled above.)
        let mut text = String::new();
        if !trimmed_prompt.is_empty() {
            text.push_str(trimmed_prompt);
            text.push_str("\n\n");
        }
        text.push_str("(reply with name or number)\n");
        for (idx, (_id, label)) in options.iter().enumerate() {
            text.push_str(&format!("{}. {}\n", idx + 1, label.trim()));
        }
        let trimmed = text.trim_end().to_string();
        self.send(&SendMessage::new(trimmed, recipient)).await
    }

    async fn request_approval(
        &self,
        recipient: &str,
        request: &ChannelApprovalRequest,
    ) -> anyhow::Result<Option<ChannelApprovalResponse>> {
        let token = crate::util::new_approval_token();
        let (tx_approval, rx_approval) = oneshot::channel();
        {
            let mut map = PENDING_APPROVALS.lock().await;
            map.insert(token.clone(), tx_approval);
        }

        let text = format!(
            "APPROVAL REQUIRED [{}]\nTool: {}\nArgs: {}\n\nReply: \"{} yes\", \"{} no\", or \"{} always\"",
            token, request.tool_name, request.arguments_summary, token, token, token
        );
        self.send(&SendMessage::new(text, recipient)).await?;

        let timeout = std::time::Duration::from_secs(self.approval_timeout_secs);
        let response = match tokio::time::timeout(timeout, rx_approval).await {
            Ok(Ok(response)) => response,
            _ => {
                let mut map = PENDING_APPROVALS.lock().await;
                map.remove(&token);
                ChannelApprovalResponse::Deny
            }
        };
        Ok(Some(response))
    }

    async fn listen(&self, _tx: tokio::sync::mpsc::Sender<ChannelMessage>) -> anyhow::Result<()> {
        // WhatsApp uses webhooks (push-based), not polling.
        // Messages are received via the gateway's /whatsapp endpoint.
        // This method keeps the channel "alive" but doesn't actively poll.
        ::zeroclaw_log::record!(
            INFO,
            ::zeroclaw_log::Event::new(module_path!(), ::zeroclaw_log::Action::Note),
            "WhatsApp channel active (webhook mode). \
            Configure Meta webhook to POST to your gateway's /whatsapp endpoint."
        );

        // Keep the task alive — it will be cancelled when the channel shuts down
        loop {
            tokio::time::sleep(std::time::Duration::from_secs(3600)).await;
        }
    }

    async fn health_check(&self) -> bool {
        // Check if we can reach the WhatsApp API
        let url = format!("https://graph.facebook.com/v18.0/{}", self.endpoint_id);

        if ensure_https(&url).is_err() {
            return false;
        }

        self.http_client()
            .get(&url)
            .bearer_auth(&self.access_token)
            .send()
            .await
            .map(|r| r.status().is_success())
            .unwrap_or(false)
    }

    async fn start_typing(&self, _recipient: &str) -> anyhow::Result<()> {
        // Typing indicator not wired for the WhatsApp Cloud API path.
        Ok(())
    }

    async fn stop_typing(&self, _recipient: &str) -> anyhow::Result<()> {
        // Typing indicator not wired for the WhatsApp Cloud API path.
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_channel() -> WhatsAppChannel {
        WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        )
    }

    #[test]
    fn whatsapp_channel_name() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        assert_eq!(ch.name(), "whatsapp");
    }

    #[test]
    fn whatsapp_verify_token() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        assert_eq!(ch.verify_token(), "verify-me");
    }

    #[test]
    fn whatsapp_number_allowed_exact() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        assert!(ch.is_number_allowed("+1234567890"));
        assert!(!ch.is_number_allowed("+9876543210"));
    }

    #[test]
    fn whatsapp_number_allowed_wildcard() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        assert!(ch.is_number_allowed("+1234567890"));
        assert!(ch.is_number_allowed("+9999999999"));
    }

    #[test]
    fn whatsapp_number_denied_empty() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(Vec::new),
        );
        assert!(!ch.is_number_allowed("+1234567890"));
    }

    #[test]
    fn whatsapp_parse_empty_payload() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({});
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_valid_text_message() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "object": "whatsapp_business_account",
            "entry": [{
                "id": "123",
                "changes": [{
                    "value": {
                        "messaging_product": "whatsapp",
                        "metadata": {
                            "display_phone_number": "15551234567",
                            "phone_number_id": "123456789"
                        },
                        "messages": [{
                            "from": "1234567890",
                            "id": "wamid.xxx",
                            "timestamp": "1699999999",
                            "type": "text",
                            "text": {
                                "body": "Hello ZeroClaw!"
                            }
                        }]
                    },
                    "field": "messages"
                }]
            }]
        });

        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].sender, "+1234567890");
        assert_eq!(msgs[0].content, "Hello ZeroClaw!");
        assert_eq!(msgs[0].channel, "whatsapp");
        assert_eq!(msgs[0].timestamp, 1_699_999_999);
    }

    #[test]
    fn whatsapp_parse_location_message() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "object": "whatsapp_business_account",
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "1234567890",
                            "timestamp": "1699999999",
                            "type": "location",
                            "location": {
                                "latitude": 40.7128,
                                "longitude": -74.0060,
                                "name": "NYC"
                            }
                        }]
                    }
                }]
            }]
        });

        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "[Location: 40.712800, -74.006000 — NYC]");
    }

    #[test]
    fn whatsapp_parse_location_message_without_coordinates_is_dropped() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "object": "whatsapp_business_account",
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "1234567890",
                            "timestamp": "1699999999",
                            "type": "location",
                            "location": { "latitude": 40.7128 }
                        }]
                    }
                }]
            }]
        });

        assert!(ch.parse_webhook_payload(&payload).is_empty());
    }

    #[test]
    fn location_message_body_includes_optional_fields() {
        let full = crate::util::WhatsAppLocation {
            lat: 40.7128,
            lng: -74.0060,
            name: Some("Liberty Island".into()),
            address: Some("New York, NY 10004".into()),
        };
        assert_eq!(
            location_message_body("1234567890", &full),
            serde_json::json!({
                "messaging_product": "whatsapp",
                "recipient_type": "individual",
                "to": "1234567890",
                "type": "location",
                "location": {
                    // Outbound coordinates are strings per Meta's contract.
                    "latitude": "40.7128",
                    "longitude": "-74.006",
                    "name": "Liberty Island",
                    "address": "New York, NY 10004"
                }
            })
        );

        let bare = crate::util::WhatsAppLocation {
            lat: 40.7128,
            lng: -74.0060,
            name: None,
            address: None,
        };
        assert_eq!(
            location_message_body("1234567890", &bare),
            serde_json::json!({
                "messaging_product": "whatsapp",
                "recipient_type": "individual",
                "to": "1234567890",
                "type": "location",
                "location": {
                    "latitude": "40.7128",
                    "longitude": "-74.006"
                }
            })
        );
    }

    #[test]
    fn whatsapp_parse_unauthorized_number() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "object": "whatsapp_business_account",
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "9999999999",
                            "timestamp": "1699999999",
                            "type": "text",
                            "text": { "body": "Spam" }
                        }]
                    }
                }]
            }]
        });

        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty(), "Unauthorized numbers should be filtered");
    }

    #[test]
    fn whatsapp_parse_non_text_message_skipped() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "1234567890",
                            "timestamp": "1699999999",
                            "type": "image",
                            "image": { "id": "img123" }
                        }]
                    }
                }]
            }]
        });

        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty(), "Non-text messages should be skipped");
    }

    #[test]
    fn whatsapp_parse_multiple_messages() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [
                            { "from": "111", "timestamp": "1", "type": "text", "text": { "body": "First" } },
                            { "from": "222", "timestamp": "2", "type": "text", "text": { "body": "Second" } }
                        ]
                    }
                }]
            }]
        });

        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 2);
        assert_eq!(msgs[0].content, "First");
        assert_eq!(msgs[1].content, "Second");
    }

    #[test]
    fn whatsapp_parse_normalizes_phone_with_plus() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        // API sends without +, but we normalize to +
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "1234567890",
                            "timestamp": "1",
                            "type": "text",
                            "text": { "body": "Hi" }
                        }]
                    }
                }]
            }]
        });

        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].sender, "+1234567890");
    }

    #[test]
    fn whatsapp_empty_text_skipped() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "text",
                            "text": { "body": "" }
                        }]
                    }
                }]
            }]
        });

        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    // ══════════════════════════════════════════════════════════
    // EDGE CASES — Comprehensive coverage
    // ══════════════════════════════════════════════════════════

    #[test]
    fn whatsapp_parse_missing_entry_array() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "object": "whatsapp_business_account"
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_entry_not_array() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "entry": "not_an_array"
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_missing_changes_array() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{ "id": "123" }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_changes_not_array() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": "not_an_array"
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_missing_value() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{ "field": "messages" }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_missing_messages_array() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "metadata": {}
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_messages_not_array() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": "not_an_array"
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_missing_from_field() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "timestamp": "1",
                            "type": "text",
                            "text": { "body": "No sender" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty(), "Messages without 'from' should be skipped");
    }

    #[test]
    fn whatsapp_parse_missing_text_body() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "text",
                            "text": {}
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(
            msgs.is_empty(),
            "Messages with empty text object should be skipped"
        );
    }

    #[test]
    fn whatsapp_parse_null_text_body() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "text",
                            "text": { "body": null }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty(), "Messages with null body should be skipped");
    }

    #[test]
    fn whatsapp_parse_invalid_timestamp_uses_current() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "not_a_number",
                            "type": "text",
                            "text": { "body": "Hello" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        // Timestamp should be current time (non-zero)
        assert!(msgs[0].timestamp > 0);
    }

    #[test]
    fn whatsapp_parse_missing_timestamp_uses_current() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "type": "text",
                            "text": { "body": "Hello" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert!(msgs[0].timestamp > 0);
    }

    #[test]
    fn whatsapp_parse_multiple_entries() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [
                {
                    "changes": [{
                        "value": {
                            "messages": [{
                                "from": "111",
                                "timestamp": "1",
                                "type": "text",
                                "text": { "body": "Entry 1" }
                            }]
                        }
                    }]
                },
                {
                    "changes": [{
                        "value": {
                            "messages": [{
                                "from": "222",
                                "timestamp": "2",
                                "type": "text",
                                "text": { "body": "Entry 2" }
                            }]
                        }
                    }]
                }
            ]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 2);
        assert_eq!(msgs[0].content, "Entry 1");
        assert_eq!(msgs[1].content, "Entry 2");
    }

    #[test]
    fn whatsapp_parse_multiple_changes() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [
                    {
                        "value": {
                            "messages": [{
                                "from": "111",
                                "timestamp": "1",
                                "type": "text",
                                "text": { "body": "Change 1" }
                            }]
                        }
                    },
                    {
                        "value": {
                            "messages": [{
                                "from": "222",
                                "timestamp": "2",
                                "type": "text",
                                "text": { "body": "Change 2" }
                            }]
                        }
                    }
                ]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 2);
        assert_eq!(msgs[0].content, "Change 1");
        assert_eq!(msgs[1].content, "Change 2");
    }

    #[test]
    fn whatsapp_parse_status_update_ignored() {
        // Status updates have "statuses" instead of "messages"
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "statuses": [{
                            "id": "wamid.xxx",
                            "status": "delivered",
                            "timestamp": "1699999999"
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty(), "Status updates should be ignored");
    }

    #[test]
    fn whatsapp_parse_audio_message_skipped() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "audio",
                            "audio": { "id": "audio123", "mime_type": "audio/ogg" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_video_message_skipped() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "video",
                            "video": { "id": "video123" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_document_message_skipped() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "document",
                            "document": { "id": "doc123", "filename": "file.pdf" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_sticker_message_skipped() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "sticker",
                            "sticker": { "id": "sticker123" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_location_message_without_name() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "location",
                            "location": { "latitude": 40.7128, "longitude": -74.0060 }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "[Location: 40.712800, -74.006000]");
    }

    #[test]
    fn whatsapp_parse_contacts_message_skipped() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "contacts",
                            "contacts": [{ "name": { "formatted_name": "John" } }]
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_reaction_message_skipped() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "reaction",
                            "reaction": { "message_id": "wamid.xxx", "emoji": "👍" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_mixed_authorized_unauthorized() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1111111111".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [
                            { "from": "1111111111", "timestamp": "1", "type": "text", "text": { "body": "Allowed" } },
                            { "from": "9999999999", "timestamp": "2", "type": "text", "text": { "body": "Blocked" } },
                            { "from": "1111111111", "timestamp": "3", "type": "text", "text": { "body": "Also allowed" } }
                        ]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 2);
        assert_eq!(msgs[0].content, "Allowed");
        assert_eq!(msgs[1].content, "Also allowed");
    }

    #[test]
    fn whatsapp_parse_unicode_message() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "text",
                            "text": { "body": "Hello 👋 世界 🌍 مرحبا" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "Hello 👋 世界 🌍 مرحبا");
    }

    #[test]
    fn whatsapp_parse_very_long_message() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let long_text = "A".repeat(10_000);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "text",
                            "text": { "body": long_text }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content.len(), 10_000);
    }

    #[test]
    fn whatsapp_parse_whitespace_only_message_skipped() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "text",
                            "text": { "body": "   " }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        // Whitespace-only is NOT empty, so it passes through
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "   ");
    }

    #[test]
    fn whatsapp_number_allowed_multiple_numbers() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| {
                vec![
                    "+1111111111".into(),
                    "+2222222222".into(),
                    "+3333333333".into(),
                ]
            }),
        );
        assert!(ch.is_number_allowed("+1111111111"));
        assert!(ch.is_number_allowed("+2222222222"));
        assert!(ch.is_number_allowed("+3333333333"));
        assert!(!ch.is_number_allowed("+4444444444"));
    }

    #[test]
    fn whatsapp_number_allowed_case_sensitive() {
        // Phone numbers should be exact match
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        assert!(ch.is_number_allowed("+1234567890"));
        // Different number should not match
        assert!(!ch.is_number_allowed("+1234567891"));
    }

    #[test]
    fn whatsapp_parse_phone_already_has_plus() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        // If API sends with +, we should still handle it
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "+1234567890",
                            "timestamp": "1",
                            "type": "text",
                            "text": { "body": "Hi" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].sender, "+1234567890");
    }

    #[test]
    fn whatsapp_channel_fields_stored_correctly() {
        let ch = WhatsAppChannel::new(
            "my-access-token".into(),
            "phone-id-123".into(),
            "my-verify-token".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+111".into(), "+222".into()]),
        );
        assert_eq!(ch.verify_token(), "my-verify-token");
        assert!(ch.is_number_allowed("+111"));
        assert!(ch.is_number_allowed("+222"));
        assert!(!ch.is_number_allowed("+333"));
    }

    #[test]
    fn whatsapp_parse_empty_messages_array() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": []
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_empty_entry_array() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "entry": []
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_empty_changes_array() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": []
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty());
    }

    #[test]
    fn whatsapp_parse_newlines_preserved() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "text",
                            "text": { "body": "Line 1\nLine 2\nLine 3" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "Line 1\nLine 2\nLine 3");
    }

    #[test]
    fn whatsapp_parse_special_characters() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "111",
                            "timestamp": "1",
                            "type": "text",
                            "text": { "body": "<script>alert('xss')</script> & \"quotes\" 'apostrophe'" }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(
            msgs[0].content,
            "<script>alert('xss')</script> & \"quotes\" 'apostrophe'"
        );
    }

    // ══════════════════════════════════════════════════════════
    // MENTION-PATTERN GATING — Unit tests
    // ══════════════════════════════════════════════════════════

    // ── compile_mention_patterns ──

    #[test]
    fn whatsapp_compile_valid_patterns() {
        let patterns = WhatsAppChannel::compile_mention_patterns(&[
            "@?ZeroClaw".into(),
            r"\+?15555550123".into(),
        ]);
        assert_eq!(patterns.len(), 2);
    }

    #[test]
    fn whatsapp_compile_skips_invalid_patterns() {
        let patterns =
            WhatsAppChannel::compile_mention_patterns(&["@?ZeroClaw".into(), "[invalid".into()]);
        assert_eq!(patterns.len(), 1);
    }

    #[test]
    fn whatsapp_compile_skips_empty_patterns() {
        let patterns =
            WhatsAppChannel::compile_mention_patterns(&["@?ZeroClaw".into(), "  ".into()]);
        assert_eq!(patterns.len(), 1);
    }

    #[test]
    fn whatsapp_compile_empty_vec() {
        let patterns = WhatsAppChannel::compile_mention_patterns(&[]);
        assert!(patterns.is_empty());
    }

    // ── text_matches_patterns ──

    #[test]
    fn whatsapp_text_matches_at_name() {
        let pats = WhatsAppChannel::compile_mention_patterns(&["@?ZeroClaw".into()]);
        assert!(WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hello @ZeroClaw"
        ));
    }

    #[test]
    fn whatsapp_text_matches_name_only() {
        let pats = WhatsAppChannel::compile_mention_patterns(&["@?ZeroClaw".into()]);
        assert!(WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hello ZeroClaw"
        ));
    }

    #[test]
    fn whatsapp_text_matches_case_insensitive() {
        let pats = WhatsAppChannel::compile_mention_patterns(&["@?ZeroClaw".into()]);
        assert!(WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hello @zeroclaw"
        ));
        assert!(WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hello ZEROCLAW"
        ));
    }

    #[test]
    fn whatsapp_text_matches_no_match() {
        let pats = WhatsAppChannel::compile_mention_patterns(&["@?ZeroClaw".into()]);
        assert!(!WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hello @otherbot"
        ));
        assert!(!WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hello world"
        ));
    }

    #[test]
    fn whatsapp_text_matches_phone_pattern() {
        let pats = WhatsAppChannel::compile_mention_patterns(&[r"\+?15555550123".into()]);
        assert!(WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hey +15555550123 help"
        ));
        assert!(WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hey 15555550123 help"
        ));
        assert!(!WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hey +19999999999 help"
        ));
    }

    #[test]
    fn whatsapp_text_matches_multiple_patterns() {
        let pats = WhatsAppChannel::compile_mention_patterns(&[
            "@?ZeroClaw".into(),
            r"\+?15555550123".into(),
        ]);
        assert!(WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hello @ZeroClaw"
        ));
        assert!(WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hey +15555550123"
        ));
        assert!(!WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hello world"
        ));
    }

    #[test]
    fn whatsapp_text_matches_empty_patterns() {
        let pats: Vec<Regex> = vec![];
        assert!(!WhatsAppChannel::text_matches_patterns(
            &pats,
            "Hello @ZeroClaw"
        ));
    }

    // ── builder tests ──

    #[test]
    fn whatsapp_with_group_mention_patterns_compiles() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(Vec::new),
        )
        .with_group_mention_patterns(vec!["@?bot".into()]);
        assert_eq!(ch.group_mention_patterns.len(), 1);
        assert!(ch.dm_mention_patterns.is_empty());
    }

    #[test]
    fn whatsapp_with_dm_mention_patterns_compiles() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(Vec::new),
        )
        .with_dm_mention_patterns(vec!["@?bot".into()]);
        assert_eq!(ch.dm_mention_patterns.len(), 1);
        assert!(ch.group_mention_patterns.is_empty());
    }

    #[test]
    fn whatsapp_default_no_mention_patterns() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(Vec::new),
        );
        assert!(ch.dm_mention_patterns.is_empty());
        assert!(ch.group_mention_patterns.is_empty());
    }

    // ── mention_patterns integration with parse_webhook_payload ──

    /// Helper: build a group message payload with optional context.group_id.
    fn group_msg(from: &str, ts: &str, body: &str) -> serde_json::Value {
        serde_json::json!({
            "from": from,
            "timestamp": ts,
            "type": "text",
            "text": { "body": body },
            "context": { "group_id": "120363012345678901@g.us" }
        })
    }

    /// Helper: build a DM message payload (no group_id).
    fn dm_msg(from: &str, ts: &str, body: &str) -> serde_json::Value {
        serde_json::json!({
            "from": from,
            "timestamp": ts,
            "type": "text",
            "text": { "body": body }
        })
    }

    #[test]
    fn whatsapp_is_group_message_with_group_id() {
        let msg = group_msg("111", "1", "Hello");
        assert!(WhatsAppChannel::is_group_message(&msg));
    }

    #[test]
    fn whatsapp_is_group_message_without_context() {
        let msg = dm_msg("111", "1", "Hello");
        assert!(!WhatsAppChannel::is_group_message(&msg));
    }

    #[test]
    fn whatsapp_is_group_message_empty_group_id() {
        let msg = serde_json::json!({
            "from": "111",
            "timestamp": "1",
            "type": "text",
            "text": { "body": "Hi" },
            "context": { "group_id": "" }
        });
        assert!(!WhatsAppChannel::is_group_message(&msg));
    }

    #[test]
    fn whatsapp_group_mention_rejects_group_message_without_match() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_group_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [group_msg("111", "1", "Hello without mention")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(
            msgs.is_empty(),
            "Should reject group messages without mention"
        );
    }

    #[test]
    fn whatsapp_group_mention_dm_passes_through_without_match() {
        // group_mention_patterns configured but DMs should pass through
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_group_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [dm_msg("111", "1", "Hello without mention")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(
            msgs.len(),
            1,
            "DMs should pass through when only group patterns are set"
        );
        assert_eq!(msgs[0].content, "Hello without mention");
    }

    #[test]
    fn whatsapp_group_mention_admits_and_preserves_in_group() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_group_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [group_msg("111", "1", "@ZeroClaw what is the weather?")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "@ZeroClaw what is the weather?");
    }

    #[test]
    fn whatsapp_group_mention_preserves_mid_sentence_mention() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_group_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [group_msg("111", "1", "Hey @ZeroClaw tell me a joke")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "Hey @ZeroClaw tell me a joke");
    }

    #[test]
    fn whatsapp_group_mention_admits_mention_only_group_message() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_group_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [group_msg("111", "1", "@ZeroClaw")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "@ZeroClaw");
    }

    #[test]
    fn whatsapp_group_mention_case_insensitive_group_match() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_group_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [group_msg("111", "1", "@zeroclaw status")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "@zeroclaw status");
    }

    #[test]
    fn whatsapp_no_patterns_passes_all_group_messages() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        );
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [group_msg("111", "1", "Hello without mention")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "Hello without mention");
    }

    #[test]
    fn whatsapp_group_mention_mixed_group_messages() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_group_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [
                            group_msg("111", "1", "No mention here"),
                            group_msg("222", "2", "@ZeroClaw help me"),
                            group_msg("333", "3", "Also no mention")
                        ]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "@ZeroClaw help me");
        assert_eq!(msgs[0].sender, "+222");
    }

    #[test]
    fn whatsapp_group_mention_phone_pattern_in_group() {
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_group_mention_patterns(vec![r"\+?15555550123".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [group_msg("111", "1", "+15555550123 tell me a joke")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "+15555550123 tell me a joke");
    }

    #[test]
    fn whatsapp_group_mention_dm_not_stripped() {
        // DMs should not have group mention patterns applied
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_group_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [dm_msg("111", "1", "@ZeroClaw what is the weather?")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(
            msgs[0].content, "@ZeroClaw what is the weather?",
            "DM content should not be stripped by group patterns"
        );
    }

    // ── dm_mention_patterns integration tests ──

    #[test]
    fn whatsapp_dm_mention_rejects_dm_without_match() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_dm_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [dm_msg("111", "1", "Hello without mention")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(msgs.is_empty(), "Should reject DMs without mention");
    }

    #[test]
    fn whatsapp_dm_mention_admits_and_preserves_in_dm() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_dm_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [dm_msg("111", "1", "@ZeroClaw what is the weather?")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "@ZeroClaw what is the weather?");
    }

    #[test]
    fn whatsapp_dm_mention_group_passes_through() {
        // dm_mention_patterns configured but group messages should pass through
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["*".into()]),
        )
        .with_dm_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [group_msg("111", "1", "Hello without mention")]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(
            msgs.len(),
            1,
            "Group messages should pass through when only DM patterns are set"
        );
        assert_eq!(msgs[0].content, "Hello without mention");
    }

    #[test]
    fn approval_timeout_defaults_to_300_and_is_overridable() {
        let ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        assert_eq!(ch.approval_timeout_secs, 300);
        let ch2 = ch.with_approval_timeout_secs(60);
        assert_eq!(ch2.approval_timeout_secs, 60);
    }

    #[tokio::test]
    async fn pending_approvals_are_shared_across_instances() {
        // Two independent WhatsAppChannel instances — the orchestrator's and
        // the gateway's — must see the same pending-approvals map so that a
        // reply intercepted on one instance resolves a token registered on
        // the other. Without the module-level static this test would fail.
        let orchestrator_ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );
        let gateway_ch = WhatsAppChannel::new(
            "test-token".into(),
            "123456789".into(),
            "verify-me".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        );

        let (tx, _rx) = oneshot::channel::<ChannelApprovalResponse>();
        {
            let mut map = orchestrator_ch.pending_approvals().lock().await;
            map.insert("test_share_tok".to_string(), tx);
        }
        {
            let map = gateway_ch.pending_approvals().lock().await;
            assert!(
                map.contains_key("test_share_tok"),
                "gateway instance must see orchestrator's registration"
            );
        }
        // Cleanup so later tests aren't polluted by this entry.
        gateway_ch
            .pending_approvals()
            .lock()
            .await
            .remove("test_share_tok");
    }

    // ══════════════════════════════════════════════════════════
    // Interactive reply parsing — button_reply / list_reply paths
    // ══════════════════════════════════════════════════════════

    fn interactive_reply_payload(
        kind: &str,
        id: &str,
        title: &str,
        from: &str,
    ) -> serde_json::Value {
        // WhatsApp Cloud API reply shape for `interactive.button_reply` and
        // `interactive.list_reply`. Both nest the selected option under the
        // type-specific key with `id` (callback_id) and `title` (label).
        serde_json::json!({
            "object": "whatsapp_business_account",
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": from,
                            "id": "wamid.interactive",
                            "timestamp": "1700000000",
                            "type": "interactive",
                            "interactive": {
                                "type": kind,
                                kind: { "id": id, "title": title }
                            }
                        }]
                    }
                }]
            }]
        })
    }

    #[test]
    fn whatsapp_parse_interactive_button_reply_emits_choice_sentinel() {
        let ch = make_channel();
        let payload =
            interactive_reply_payload("button_reply", "agent:librarian", "Librarian", "1234567890");
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "[choice]agent:librarian");
        assert_eq!(msgs[0].sender, "+1234567890");
        assert_eq!(msgs[0].channel, "whatsapp");
    }

    #[test]
    fn whatsapp_parse_interactive_list_reply_emits_choice_sentinel() {
        let ch = make_channel();
        let payload =
            interactive_reply_payload("list_reply", "session:backend", "backend", "1234567890");
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].content, "[choice]session:backend");
    }

    #[test]
    fn whatsapp_parse_interactive_reply_missing_id_dropped() {
        let ch = make_channel();
        let payload = serde_json::json!({
            "entry": [{
                "changes": [{
                    "value": {
                        "messages": [{
                            "from": "1234567890",
                            "timestamp": "1",
                            "type": "interactive",
                            "interactive": {
                                "type": "button_reply",
                                "button_reply": { "title": "no id here" }
                            }
                        }]
                    }
                }]
            }]
        });
        let msgs = ch.parse_webhook_payload(&payload);
        assert!(
            msgs.is_empty(),
            "interactive reply without id must be dropped, got: {msgs:?}"
        );
    }

    #[test]
    fn whatsapp_interactive_reply_bypasses_dm_mention_gating() {
        // With dm_mention_patterns set, a freeform body without the trigger
        // is dropped — but a [choice]<id> body produced by an interactive
        // reply must be passed through, because the user already explicitly
        // tapped a button the bot rendered.
        let ch = WhatsAppChannel::new(
            "tok".into(),
            "123".into(),
            "ver".into(),
            "whatsapp_test_alias",
            Arc::new(|| vec!["+1234567890".into()]),
        )
        .with_dm_mention_patterns(vec!["@?ZeroClaw".into()]);
        let payload =
            interactive_reply_payload("button_reply", "agent:librarian", "Librarian", "1234567890");
        let msgs = ch.parse_webhook_payload(&payload);
        assert_eq!(msgs.len(), 1, "[choice] body must bypass mention-gating");
        assert_eq!(msgs[0].content, "[choice]agent:librarian");
    }
}
