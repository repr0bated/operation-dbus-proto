//! Channel implementations and orchestration for messaging platform integrations.

#![allow(
    clippy::to_string_in_format_args,
    clippy::useless_format,
    clippy::explicit_auto_deref
)]
#![cfg_attr(feature = "channel-matrix", recursion_limit = "256")]

pub mod allowlist;
#[cfg(any(feature = "channel-wechat", feature = "whatsapp-web"))]
pub(crate) mod identity_persist;
pub mod listing;
pub mod login_events;
pub mod login_probe;
pub mod login_relink;
pub mod orchestrator;
pub mod paced_channel;
pub mod util;

// Always-compiled channels and utilities (no feature gate)
#[cfg(feature = "channel-acp-server")]
pub mod acp_channel;
pub mod cli;
pub mod link_enricher;
pub mod transcription;
pub mod tts;
pub mod voice;

// Feature-gated channels
#[cfg(feature = "channel-amqp")]
pub mod amqp;
#[cfg(feature = "channel-bluesky")]
pub mod bluesky;
#[cfg(feature = "channel-clawdtalk")]
pub mod clawdtalk;
#[cfg(feature = "channel-dingtalk")]
pub mod dingtalk;
#[cfg(feature = "channel-discord")]
pub mod discord;
#[cfg(feature = "channel-discord")]
pub mod discord_slash_state;
#[cfg(feature = "channel-email")]
pub mod email_channel;
#[cfg(feature = "channel-filesystem")]
pub mod filesystem;
#[cfg(feature = "channel-git")]
pub mod git;
#[cfg(feature = "channel-email")]
pub mod gmail_push;
#[cfg(feature = "channel-imessage")]
pub mod imessage;
#[cfg(feature = "channel-irc")]
pub mod irc;
#[cfg(feature = "channel-lark")]
pub mod lark;
#[cfg(feature = "channel-line")]
pub mod line;
#[cfg(feature = "channel-linq")]
pub mod linq;
#[cfg(feature = "channel-matrix")]
pub mod matrix;
#[cfg(feature = "channel-mattermost")]
pub mod mattermost;
#[cfg(feature = "channel-mochat")]
pub mod mochat;
#[cfg(feature = "channel-nextcloud")]
pub mod nextcloud_talk;
#[cfg(feature = "channel-nostr")]
pub mod nostr;
#[cfg(feature = "channel-notion")]
pub mod notion;
#[cfg(feature = "channel-qq")]
pub mod qq;
#[cfg(feature = "channel-reddit")]
pub mod reddit;
#[cfg(feature = "channel-signal")]
pub mod signal;
#[cfg(feature = "channel-slack")]
pub mod slack;
#[cfg(feature = "channel-telegram")]
pub mod telegram;
#[cfg(feature = "channel-twitch")]
pub mod twitch;
#[cfg(feature = "channel-twitter")]
pub mod twitter;
#[cfg(feature = "channel-voice-call")]
pub mod voice_call;
#[cfg(feature = "voice-wake")]
pub mod voice_wake;
#[cfg(feature = "channel-wati")]
pub mod wati;
#[cfg(feature = "channel-webhook")]
pub mod webhook;
#[cfg(feature = "channel-wechat")]
pub mod wechat;
#[cfg(feature = "channel-wecom")]
pub mod wecom;
#[cfg(feature = "channel-wecom-ws")]
pub mod wecom_ws;
#[cfg(any(feature = "channel-whatsapp-cloud", feature = "whatsapp-web"))]
pub mod whatsapp;
#[cfg(feature = "whatsapp-web")]
pub mod whatsapp_storage;
#[cfg(feature = "whatsapp-web")]
pub mod whatsapp_web;
