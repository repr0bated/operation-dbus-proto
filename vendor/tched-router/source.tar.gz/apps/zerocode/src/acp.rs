use std::sync::Arc;

use crossterm::event::{KeyEvent, MouseEvent};
use ratatui::layout::Rect;

use crate::chat;
use crate::client::RpcClient;

/// ACP pane — displayed as "Code" in the UI; internal name kept for historical reasons.
pub(crate) struct Acp {
    inner: chat::Chat,
}

impl Acp {
    pub(crate) fn new(rpc: Arc<RpcClient>) -> Self {
        Self {
            inner: chat::Chat::new(rpc, chat::PaneKind::Acp),
        }
    }

    pub(crate) async fn init(&mut self) -> anyhow::Result<()> {
        self.inner.init().await
    }

    pub(crate) fn set_resume_session_id(&mut self, sid: Option<String>) {
        self.inner.set_resume_session_id(sid);
    }

    pub(crate) fn set_resume_agent_alias(&mut self, alias: Option<String>) {
        self.inner.set_resume_agent_alias(alias);
    }

    pub(crate) fn current_session_id(&self) -> Option<&str> {
        self.inner.current_session_id()
    }

    pub(crate) fn current_agent_alias(&self) -> Option<&str> {
        self.inner.current_agent_alias()
    }

    pub(crate) async fn refresh_if_inactive(&mut self) {
        self.inner.refresh_if_inactive().await;
    }

    pub(crate) fn draw(&mut self, frame: &mut ratatui::Frame, area: Rect) {
        self.inner.draw(frame, area);
    }

    pub(crate) async fn handle_key(
        &mut self,
        key: KeyEvent,
        term: &mut crate::config_manager::Term,
    ) -> bool {
        self.inner.handle_key(key, term).await
    }

    pub(crate) fn wants_text_input(&self) -> bool {
        self.inner.wants_text_input()
    }

    pub(crate) fn clear_input(&mut self) {
        self.inner.clear_input();
    }

    pub(crate) fn in_browse_mode(&self) -> bool {
        self.inner.in_browse_mode()
    }

    pub(crate) fn wants_quit_chord(&self) -> bool {
        self.inner.wants_quit_chord()
    }

    pub(crate) fn take_help_request(&mut self) -> bool {
        self.inner.take_help_request()
    }

    pub(crate) fn exit_browse_mode(&mut self) {
        self.inner.exit_browse_mode();
    }

    pub(crate) async fn handle_mouse(&mut self, mouse: MouseEvent, area: Rect) {
        self.inner.handle_mouse(mouse, area).await;
    }

    pub(crate) fn handle_paste(&mut self, text: &str) {
        self.inner.handle_paste(text);
    }

    pub(crate) fn ctx_tokens(&self) -> (Option<u64>, Option<u64>) {
        self.inner.ctx_tokens()
    }

    pub(crate) fn selected_agent(&self) -> Option<&str> {
        self.inner.selected_agent()
    }

    pub(crate) fn current_cwd(&self) -> Option<&str> {
        self.inner.current_cwd()
    }
}

impl crate::widgets::HelpContext for Acp {
    fn help_context(&self) -> crate::widgets::HelpNode {
        self.inner.help_context()
    }
}
