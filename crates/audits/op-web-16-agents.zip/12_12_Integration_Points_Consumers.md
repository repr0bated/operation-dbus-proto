### Workspace Grep: `use op-web::`
* **crates/op-web/src/main.rs:10**: `use op_web::routes;`
* **crates/op-web/src/main.rs:11**: `use op_web::AppState;`

---

### Workspace Dependencies (Root `Cargo.toml`)
Based on the workspace members, the following crates are defined and potentially consumed by `op-web`:
* `op-services`, `op-gateway`, `op-core`, `op-tools`, `op-introspection`, `op-chat`, `op-http`, `op-cache`, `op-state`, `op-state-store`, `op-jsonrpc`, `op-llm`, `op-network`, `op-inspector`, `op-agents`, `op-plugins`, `op-workflows`, `op-ml`, `op-snowball`, `op-deployment`, `op-mcp`, `op-mcp-aggregator`, `op-mcp-proxy`, `op-identity`, `op-execution-tracker`, `op-dynamic-loader`, `op-cognitive-mcp`, `op-cozo-store`, `op-dbus-model`, `op-grpc-bridge`, `op-dbus-mirror`, `op-compliance`, `op-projection`.

---

### Entry Points

#### 1. HTTP Entry Points (Axum Router)
* **crates/op-web/src/main.rs:41**: Binds TCP listener on port `8080` (or `PORT` environment override) and runs the unified Axum server.
* **crates/op-web/src/routes/mod.rs:31**: The primary router definition nesting:
  * Rest API: `/api/*` (Status, Rest Chat, Logs, VPN, Mail, Users, Tools, Agents, LLM, OpenClaw, Privacy Router).
  * WebSockets: `/ws` (Real-time session-isolated Chat).
  * MCP Endpoints: `/mcp/*` (JSON-RPC for Claude/Cursor), `/mcp/agents` (SSE direct streaming).
  * Well-Known Discovery: `/.well-known/mcp.json` (Auto-configuration payload).
  * Tool Groups Admin: `/groups-admin/*` (HTML/API UI).

#### 2. D-Bus Entry Points (zbus Connection)
* **crates/op-web/src/state_manager_client.rs:25**: System D-Bus integration at `org.opdbus.v1` using object path `/org/opdbus/v1/state` and interface `org.opdbus.StateManager`. Handles system-level state querying and contract mutations.

#### 3. gRPC Entry Points (op-grpc-bridge Client & Server)
* **crates/op-web/src/bin/op-dbus.rs:34**: Runs the core system-wide gRPC control plane server on `10.200.0.2:50051`.
* **crates/op-web/src/state.rs:257**: Connects `op-web` as a gRPC client to the `op-dbus` server to stream system events and audit logs directly to SSE clients.

---

### Critical Security, Stability, and Integration Findings

#### 1. Hard Compile Failures (Missing Struct Fields & Functions)
* **crates/op-web/src/handlers/auth_bridge.rs:70**: `let bridge = &state.auth_bridge;` attempts to reference a field named `auth_bridge` on `AppState`. This field does not exist in `state::AppState` (**crates/op-web/src/state.rs:69**), leading to a compilation failure.
* **crates/op-web/src/handlers/auth_bridge.rs:81**: Duplicate reference to non-existent `state.auth_bridge`.
* **crates/op-web/src/handlers/auth_bridge.rs:114**: Duplicate reference to non-existent `state.auth_bridge`.
* **crates/op-web/src/mcp_smart_router.rs:78**: Calls `crate::mcp::get_app_state()`. The module `mcp.rs` does not contain or export a `get_app_state()` function, resulting in a compile-time failure.
* **crates/op-web/src/mcp_smart_router.rs:83**: Duplicate call to non-existent `crate::mcp::get_app_state()`.
* **crates/op-web/src/mcp_smart_router.rs:90**: Manually invokes `mcp_compact_message_handler` with `axum::extract::Json(serde_json::Value::Null)`. This function expects a signature containing `Extension<Arc<AppState>>`. Manual invocation without state injection fails compile-time signature checks.

#### 2. Security Vulnerabilities
* **crates/op-web/src/middleware/security.rs:16**: Hardcoded backdoor tokens (`4f8c2b5d-9a1e-4b7c-8d2f-3a6b5c9e4d1f` and `test-key-huggingface-2024`) bypass all IP-based security zones. Any request presenting these credentials instantly receives `AccessZone::TrustedMesh` (full access).
* **crates/op-web/src/handlers/privacy.rs:608**: In `google_auth`, the CSRF validation token map is purged completely using `.clear()` if its size exceeds 1,000 entries. An attacker can trivialy generate 1,001 fake auth requests to wipe active CSRF tokens for all legitimate, concurrently logging-in users, executing a complete Denial of Service (DoS).
* **crates/op-web/src/handlers/logs.rs:37**: Spawns an external `tail` system process. If log file paths or inputs are ever made dynamic, this becomes a vector for command injection. Standard library async file APIs should be used instead.
* **crates/op-web/src/handlers/status.rs:253**: Spawns an external escalated system process via `doas dinitctl list`. This represents a severe privilege escalation risk if environment paths or configuration parameters are hijacked.

#### 3. Unsafe Blocks (In-Place Mutability Risks)
* **crates/op-web/src/groups_admin.rs:67**: Uses `unsafe { simd_json::from_str::<HashMap<String, EnabledGroups>>(&mut raw) }`. In-place mutations of string buffers are unsafe if concurrent references exist, or if the layout/alignment assumptions of `simd-json` are violated.
* **crates/op-web/src/websocket.rs:114**: `unsafe { simd_json::from_str(&mut raw) }` decodes arbitrary WebSocket messages in-place without verifying structural alignment.
* **crates/op-web/src/handlers/websocket.rs:60**: Duplicate unsafe parsing of WebSocket packets.
* **crates/op-web/src/users.rs:101**: `unsafe { simd_json::from_str(&mut raw) }` used on user files loaded from disk. Prone to UB if files are corrupted or modified concurrently.
* **crates/op-web/src/state_manager_client.rs:29**: `unsafe { simd_json::from_str(&mut state_json) }` on D-Bus payload returns.

#### 4. Explicit `unwrap` and `expect` Panics
* **crates/op-web/src/handlers/openclaw.rs:114**: `Client::builder().build().unwrap()` will panic the worker thread if the native TLS/OpenSSL configuration fails to initialize.
* **crates/op-web/src/handlers/openclaw.rs:159**: Duplicate panic risk in client builder.
* **crates/op-web/src/handlers/openclaw.rs:232**: Duplicate panic risk in client builder.
* **crates/op-web/src/state.rs:163**: `.expect("Failed to create user store")` crashes the entire web server on startup if the directory `/var/lib/op-dbus/` is unwritable.
* **crates/op-web/src/state.rs:242**: `.expect("Failed to create in-memory state store")` triggers a panic on database fallback.
* **crates/op-web/src/server.rs:114**: `.unwrap()` on `GovernorConfigBuilder` parameters. Panics at runtime if system limits restrict bucket allocations.

#### 5. Memory and Clone Abuse
* **crates/op-web/src/groups_admin.rs:52**: `let mut raw = content.clone();` deep-clones the entire tool configuration JSON file into memory for every reload transaction rather than parsing directly from read-only slices.
* **crates/op-web/src/handlers/chat.rs:47**: `request.message.clone()` clones large natural language inputs up to 4 times per chat transaction to store them in local conversational histories and state objects.
* **crates/op-web/src/mcp_agents.rs:172**: `enabled_agents: self.entries.iter().map(|(agent_type, _)| agent_type.clone()).collect()` creates high-frequency heap allocations during state sync cycles.