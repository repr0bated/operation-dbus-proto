### Direct Dependencies

The following direct dependencies are specified in `crates/op-web/Cargo.toml` and resolved via workspace inheritance or direct versions:

*   **op-core** (Workspace, version `1.0.0`)
*   **op-chat** (Workspace, version `1.0.0`)
*   **op-llm** (Path: `../op-llm`, version `1.0.0`)
*   **op-tools** (Path: `../op-tools`, version `0.1.0`)
*   **op-agents** (Path: `../op-agents`, version `1.0.0`)
*   **op-state** (Workspace, version `1.0.0`)
*   **op-network** (Workspace, version `1.0.0`)
*   **op-mcp** (Path: `../op-mcp`, version `0.4.0`)
*   **op-mcp-aggregator** (Path: `../op-mcp-aggregator`, version `1.0.0`)
*   **op-state-store** (Path: `../op-state-store`, version `0.1.0`)
*   **op-identity** (Workspace, version `0.1.0`)
*   **op-introspection** (Workspace, version `1.0.0`)
*   **op-grpc-bridge** (Path: `../op-grpc-bridge`, version `0.1.0`)
*   **op-jsonrpc** (Path: `../op-jsonrpc`, version `1.0.0`)
*   **tower_governor** (Version `0.4`)
*   **axum** (Workspace, version `0.7`, explicitly configured with features: `["ws", "macros", "tokio"]`)
*   **tokio** (Workspace, version `1`, explicitly configured with features: `["full", "signal"]`)
*   **tower** (Workspace, version `0.4`)
*   **tower-http** (Workspace, version `0.5`, explicitly configured with features: `["cors", "fs", "compression-gzip", "trace", "timeout"]`)
*   **hyper** (Workspace, version `1.0`)
*   **serde** (Workspace, version `1`)
*   **simd-json** (Workspace, version `0.13`)
*   **toml** (Workspace, version `0.8`)
*   **futures** (Workspace, version `0.3`)
*   **async-trait** (Workspace, version `0.1`)
*   **tokio-stream** (Workspace, version `0.1`, explicitly configured with features: `["sync"]`)
*   **async-stream** (Version `0.3`)
*   **uuid** (Workspace, version `1.6`, explicitly configured with features: `["v4", "serde"]`)
*   **chrono** (Workspace, version `0.4`, explicitly configured with features: `["serde"]`)
*   **tracing** (Workspace, version `0.1`)
*   **tracing-subscriber** (Workspace, version `0.3`, explicitly configured with features: `["env-filter"]`)
*   **anyhow** (Workspace, version `1`)
*   **thiserror** (Workspace, version `1`)
*   **sysinfo** (Version `0.30`)
*   **gethostname** (Workspace, version `0.5`)
*   **lazy_static** (Version `1.4`)
*   **regex** (Workspace, version `1`)
*   **qrcode** (Version `0.14`)
*   **image** (Version `0.25`, configured with `default-features = false`, features: `["png"]`)
*   **base64** (Version `0.22`)
*   **lettre** (Version `0.11`, explicitly configured with features: `["tokio1-native-tls", "builder"]`)
*   **hex** (Workspace, version `0.4`)
*   **zbus** (Workspace, version `4.0` / inherited dependency resolved dynamically)
*   **ring** (Version `0.17`)
*   **oauth2** (Version `4.4`)
*   **reqwest** (Version `0.11`, explicitly configured with features: `["json"]`)
*   **rust-embed** (Version `8`, explicitly configured with features: `["compression"]`)
*   **axum-embed** (Version `0.1`)
*   **mime_guess** (Version `2`)
*   **linemux** (Version `0.3.0`)

---

### Features

Crate `crates/op-web/Cargo.toml` has no `[features]` section defined.
*   **Crate Features**: none

---

### Crate Audit: `anyhow`, `thiserror`, and `tokio`

1.  **Crate anyhow**: Inherited from workspace (version `1`).
2.  **Crate thiserror**: Inherited from workspace (version `1`).
3.  **Crate tokio**: Configured with `features = ["full", "signal"]` in `op-web`, which is bloated for a web microservice. It pulls in heavy dependencies like `mio`, `parking_lot`, and complete runtime engines, increasing compile times and binary size unnecessarily.
4.  **Count of `anyhow` Usages**:
    There are **25 lines** referencing or importing `anyhow` across **14 files** in the `crates/op-web` crate:
    *   `src/email.rs`: 1
    *   `src/main.rs`: 1
    *   `src/mcp_compact.rs`: 1
    *   `src/privacy_container.rs`: 1
    *   `src/privacy_openflow.rs`: 1
    *   `src/privacy_routes.rs`: 3
    *   `src/state.rs`: 7
    *   `src/state_manager_client.rs`: 1
    *   `src/privacy_network.rs`: 1
    *   `src/users.rs`: 1
    *   `src/wireguard.rs`: 1
    *   `src/bin/op-dbus.rs`: 1
    *   `src/orchestrator/execution.rs`: 1
    *   `src/orchestrator/process.rs`: 4

---

### Critical Code Quality & Security Audit

#### 1. Remote Exploitation & Undefined Behavior via Unsafe JSON Parsing

Every JSON parsing operation in this web service relies on unsafe `simd-json` deserialization. This bypasses Rust's memory safety guarantees and represents a massive remote exploit vector (RCE/DoS) if a client submits mutated or malformed JSON payloads.

*   **file:crates/op-web/src/groups_admin.rs:59**
    ```rust
    if let Ok(saved) = unsafe { simd_json::from_str::<HashMap<String, EnabledGroups>>(&mut raw) }
    ```
    Bypasses safety checks when reading `/var/lib/op-dbus/tool-groups.json` from disk.
*   **file:crates/op-web/src/users.rs:77**
    ```rust
    let data: StoredData = unsafe { simd_json::from_str(&mut raw) }?;
    ```
    Bypasses safety when deserializing the persistent user database file.
*   **file:crates/op-web/src/websocket.rs:79**
    ```rust
    let ws_msg: Result<WsMessage, _> = unsafe { simd_json::from_str(&mut raw) };
    ```
    Extremely dangerous. Parses arbitrary WebSocket text frames sent directly from untrusted public clients.
*   **file:crates/op-web/src/handlers/websocket.rs:60**
    ```rust
    let ws_msg: Result<WsMessage, _> = unsafe { simd_json::from_str(&mut raw) };
    ```
    Duplicate remote exploit vector on the fallback WebSocket handler.
*   **file:crates/op-web/src/orchestrator/parsing.rs:31**
    ```rust
    if let Ok(parsed) = unsafe { simd_json::from_str(&mut raw) } {
    ```
    Parses LLM output using `unsafe`. Model hallucinations or unexpected syntax can trigger undefined memory behavior.
*   **file:crates/op-web/src/orchestrator/parsing.rs:76**
    ```rust
    if let Ok(parsed) = unsafe { simd_json::from_str(&mut raw) } {
    ```
    Parses LLM arguments utilizing unsafe string slicing mutations.
*   **file:crates/op-web/src/orchestrator/parsing.rs:104**
    ```rust
    unsafe { simd_json::from_str(&mut raw) }.unwrap_or(json!({}))
    ```
    Unsafely parses arguments for tool execution.
*   **file:crates/op-web/src/orchestrator/parsing.rs:120**
    ```rust
    if let Ok(parsed) = unsafe { simd_json::from_str::<Value>(&mut raw) } {
    ```
    Unsafely parses embedded JSON blocks.
*   **file:crates/op-web/src/orchestrator/execution.rs:59**
    ```rust
    unsafe { simd_json::from_str(&mut raw) }.unwrap_or(json!({}))
    ```
    Unsafely parses raw JSON arguments for direct tool invocation.
*   **file:crates/op-web/src/state_manager_client.rs:34**
    ```rust
    let query_state: QueryStateResponse = unsafe { simd_json::from_str(&mut state_json) }
    ```
    Unsafely parses D-Bus responses retrieved from the StateManager service.

#### 2. False Cryptographic Claims: Plain-Text Storage of Private Keys

The codebase purports to store encrypted private keys, but actually writes plain-text WireGuard private keys directly to disk.

*   **file:crates/op-web/src/users.rs:28**
    ```rust
    pub wg_private_key_encrypted: String,
    ```
    The field name indicates the key is encrypted.
*   **file:crates/op-web/src/handlers/privacy.rs:166**
    ```rust
    // Create user (we'll encrypt the private key later, for now just store it)
    ```
    The developer explicitly documents that the key is **not** encrypted. The raw private key is passed directly into `wg_private_key_encrypted`.
*   **file:crates/op-web/src/users.rs:88**
    ```rust
    let content = simd_json::to_string_pretty(&data)?;
    // ...
    tokio::fs::write(&temp_path, content).await?;
    ```
    Serializes all unencrypted private keys directly into a plain-text JSON file (`/var/lib/op-dbus/privacy-users.json`) on the host filesystem. Any compromise of this file exposes the entire WireGuard network.

#### 3. Privilege Escalation & Unsafe Subprocess Execution

The web application shells out to OS commands, some of which execute with root privileges or are vulnerable to environment manipulation.

*   **file:crates/op-web/src/handlers/status.rs:200**
    ```rust
    let out = tokio::process::Command::new("doas")
        .arg("dinitctl")
        .arg("list")
    ```
    Shells out to `doas` (OpenBSD's `sudo` equivalent) synchronously. If the web server runs as a restricted user with `NOPASSWD` configuration for this command, it constitutes a trivial local privilege escalation vector if the web application is compromised.
*   **file:crates/op-web/src/handlers/dashboard.rs:51**
    ```rust
    Command::new("wg")
        .args(&["show", "wg0", "peers"])
    ```
    Fails to handle permission errors if the web server is not running as root, and invokes synchronous process creation.
*   **file:crates/op-web/src/handlers/logs.rs:44**
    ```rust
    if let Ok(output) = Command::new("tail").args(&["-n", "50", log_path]).output() {
    ```
    Invokes a synchronous `tail` command inside an async context. This blocks the executor thread pool.

#### 4. Unbounded Resource Allocation & Denials of Service (DoS)

*   **file:crates/op-web/src/websocket.rs:48**
    ```rust
    let (session_tx, mut session_rx) = mpsc::channel::<String>(100);
    // ...
    let mut send_task = tokio::spawn(async move { ... });
    let mut recv_task = tokio::spawn(async move { ... });
    ```
    Each WebSocket connection spawns two unbounded tasks without frame rate-limiting. A client can easily spawn thousands of connections and flood the server with empty messages, causing thread/memory exhaustion.
*   **file:crates/op-web/src/handlers/logs.rs:126**
    ```rust
    while let Ok(Some(line)) = lines.next_line().await {
        // ...
        broadcaster.broadcast("log", &payload);
    }
    ```
    Under heavy log output or a targeted log spam attack, the file watcher will flood the SSE channel. This creates a cascade failure, exhausting network buffers and causing heap memory spikes.
*   **file:crates/op-web/src/handlers/privacy.rs:104**
    ```rust
    static LAST_SIGNUP: tokio::sync::Mutex<Option<HashMap<String, Instant>>> = ...
    ```
    Uses a global synchronous Mutex wrapper over a rate-limiting `HashMap`. This introduces severe lock contention. Additionally, memory cleanup is executed synchronously: `map.retain(|_, v| v.elapsed().as_secs() < 3600)` only when the map exceeds 1000 items, exposing the server to state-exhaustion DoS attacks.

#### 5. Unsafe Panics & `unwrap` Abuse

*   **file:crates/op-web/src/server.rs:141**
    ```rust
    let governor_conf = GovernorConfigBuilder::default()
        // ...
        .finish()
        .unwrap();
    ```
    Using `.unwrap()` on rate-limiter initialization will panic and crash the web server at boot if configuration parameters are out of range.
*   **file:crates/op-web/src/state.rs:175**
    ```rust
    UserStore::new("/var/lib/op-dbus/privacy-users.json")
        .await
        .expect("Failed to create user store")
    ```
    Triggers a hard panic at startup if the path is write-protected or locked.
*   **file:crates/op-web/src/state.rs:211**
    ```rust
    SqliteStore::new(":memory:")
        .await
        .expect("Failed to create in-memory state store")
    ```
    Hard panic on failure to allocate in-memory fallback state storage.
*   **file:crates/op-web/src/handlers/openclaw.rs:128**
    ```rust
    Client::builder()
        .timeout(Duration::from_secs(5))
        .build()
        .unwrap();
    ```
    Unnecessary use of `.unwrap()` on a static HTTP client build.

#### 6. Insecure Cryptographic Hashing

*   **file:crates/op-web/src/privacy_openflow.rs:244**
    ```rust
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    route_id.hash(&mut hasher);
    return_path.hash(&mut hasher);
    PRIVACY_FLOW_COOKIE_PREFIX | (hasher.finish() & !PRIVACY_FLOW_COOKIE_MASK)
    ```
    Uses `DefaultHasher` to derive security cookies. `DefaultHasher` is non-cryptographic and non-deterministic across Rust compiler releases, leading to potential cookie collisions and routing table mismatches after software updates.

#### 7. Excessive Clones & Memory Overhead

*   **file:crates/op-web/src/groups_admin.rs:57**
    ```rust
    let mut raw = content.clone();
    ```
    Clones the entire contents of the configuration file. This is completely unnecessary since `content` is not reused.
*   **file:crates/op-web/src/privacy_openflow.rs:136**
    ```rust
    bridges.push(merge_bridge_config(
        bridge,
        bridge_routes.cloned().unwrap_or_default(),
    ));
    ```
    Deep-clones lists of routes for every single bridge in the routing table.
*   **file:crates/op-web/src/state.rs:430**
    ```rust
    "tool_name": self.name.clone(),
    ```
    Clones the static tool name string on every single proxy execution.

#### 8. Public API Encapsulation Breakage

*   **file:crates/op-web/src/state.rs:64**
    The `AppState` struct exposes all internal fields publicly:
    ```rust
    pub struct AppState {
        pub orchestrator: Arc<UnifiedOrchestrator>,
        pub tool_registry: Arc<ToolRegistry>,
        pub chat_manager: Arc<ChatManager>,
        pub user_store: Arc<UserStore>,
        pub state_store: Arc<dyn StateStore>,
        // ...
    }
    ```
    This completely bypasses encapsulation, allowing any handler or middleware to mutably manipulate global state, database connections, and internal registries directly.