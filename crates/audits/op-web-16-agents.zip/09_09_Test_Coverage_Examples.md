### Test Audit Summary

- **Total Test Functions Found**: 17

### Representative Tests

1. **Test `generates_container_name_from_uuid`**
   - **File**: `crates/op-web/src/privacy_container.rs:255`
   - **Description**: Verifies that a container name is correctly generated and truncated from a standard UUID string.

2. **Test `test_route_id_is_deterministic`**
   - **File**: `crates/op-web/src/privacy_routes.rs:144`
   - **Description**: Assures that deriving a route ID using HKDF remains deterministic across multiple invocations with the same key.

3. **Test `test_detects_ovs_vsctl`**
   - **File**: `crates/op-web/src/orchestrator/anti_hallucination.rs:195`
   - **Description**: Confirms the anti-hallucination engine flags and rejects LLM outputs recommending forbidden CLI commands like `ovs-vsctl`.