# Rust Code Audit: op-web

## 1. Metrics & Data Structure Analysis

### Interior Mutability & Synchronization Primitive Counts
* **Arc**: 38 occurrences
* **Rc**: 0 occurrences
* **RefCell**: 0 occurrences
* **RwLock**: 13 occurrences
* **Mutex**: 2 occurrences
* **OnceCell**: 0 occurrences

### Clone Count (Regex: `\.clone\s*\(`)
* **Total Clones**: 137 occurrences

---

### Large Structs (>5 fields)

| Struct Name | File & Line | Field Count | Purpose / Fields |
| :--- | :--- | :---: | :--- |
| `EmailConfig` | `email.rs:15` | 7 | Email server credentials and target addresses. |
| `ManagedAgentInfo` | `mcp_agents.rs:105` | 7 | Metadata tracking for runtime agent deployment. |
| `IncusInstance` | `privacy_container.rs:33` | 8 | Deployment target definition for user container creation. |
| `OpenFlowConfig` | `privacy_openflow.rs:13` | 6 | Switch config containing bridge arrays and flow policies. |
| `FlowEntry` | `privacy_openflow.rs:32` | 7 | Represents a match-action table entry in OVS. |
| `PrivacyRoute` | `privacy_routes.rs:17` | 13 | High-dimensional routing record mapping users to ports. |
| `AppState` | `state.rs:66` | 17 | Central dependency injection hub for the server. |
| `PendingAuth` | `handlers/auth_bridge.rs:25` | 8 | PTY prompt interception state payload. |
| `ChatResponse` | `handlers/chat.rs:31` | 7 | HTTP output payload for LLM responses. |
| `DashboardMetrics` | `handlers/dashboard.rs:15` | 7 | System resource instrumentation payload. |
| `McpServer` | `handlers/mcp.rs:14` | 7 | Active MCP target registry state. |
| `Agent` | `handlers/mcp.rs:25` | 7 | AI Agent state metadata reporting. |
| `StatusResponse` | `handlers/status.rs:43` | 6 | Consolidated host and service telemetry. |
| `SystemInfo` | `handlers/status.rs:53` | 9 | Detailed CPU, Memory, and Kernel telemetry. |
| `UserResponse` | `handlers/users.rs:13` | 9 | REST payload for client records. |
| `VpnConnection` | `handlers/vpn.rs:30` | 8 | WireGuard active peer telemetry metrics. |
| `MailQueueItem` | `handlers/mail.rs:22` | 7 | Telemetry output for mail server queuing. |
| `OpenClawStatusResponse` | `handlers/openclaw.rs:50` | 6 | Connectivity output for Xray gateway integration. |

---

## 2. Ruthless Code Audit

### Critical Architectural Bugs & Compiler Errors

#### Broken Local Imports and Missing Functions
* **`mcp_smart_router.rs:104`**: `crate::mcp::get_app_state()` is called, but no such function exists in `mcp.rs`. This will trigger a critical compilation error.
* **`mcp_smart_router.rs:108`**: Duplicate invocation of `crate::mcp::get_app_state()` which is absent.
* **`mcp_smart_router.rs:129`**: Third invalid call to `crate::mcp::get_app_state()`.

---

### Unsafe Memory Usage

#### Undefined Behavior Potential in simd-json Zero-Copy Parsers
* **`groups_admin.rs:53`**: `simd_json::from_str::<HashMap<String, EnabledGroups>>(&mut raw)` is invoked within an `unsafe` block on a mutable string `raw`. Because `simd_json` is a destructive in-place parser, the returned `HashMap` contains references that borrow directly from `raw`. If `raw` is mutated or dropped before the `HashMap` is discarded, it can result in a use-after-free or dangling references.
* **`state_manager_client.rs:31`**: `simd_json::from_str(&mut state_json)` is called within `unsafe`. Any borrowed references inside the `QueryStateResponse` become invalid immediately once `state_json` goes out of scope at the end of the helper block.
* **`websocket.rs:106`**: `unsafe { simd_json::from_str(&mut raw) }` inside the WebSocket task message handler.
* **`handlers/websocket.rs:82`**: `unsafe { simd_json::from_str(&mut raw) }` inside the duplicate websocket implementation file.

---

### Unwrap / Panic-Prone Code

#### Startup Panics in Web Server Initializers
* **`server.rs:120`**: `GovernorConfigBuilder::default().per_second(...).burst_size(...).finish().unwrap()` is called on startup. If an invalid rate limit or negative parameter overflow is passed in the environmental parameters, the entire application will crash immediately on startup.
* **`bin/op-dbus.rs:31`**: `"10.200.0.2:50051".parse().unwrap()` can panic if there is any environmental platform variance or invalid hardcoded parsing.

#### Task Panics in Live WebSocket Request Loops
* **`websocket.rs:60`**: `simd_json::to_string(&welcome).unwrap()` will cause a task panic if the enum structure has any serialization failures.
* **`handlers/websocket.rs:53`**: Duplicate unsafe `.unwrap()` call during serialization of the welcome message inside the alternative websocket implementation.
* **`handlers/websocket.rs:93`**: `simd_json::to_string(&response).unwrap()` will panic the websocket task loop if formatting fails.
* **`handlers/websocket.rs:100`**: `simd_json::to_string(&error).unwrap()` can panic during an error handling path, causing a cascading failure that drops the client connection instead of safely transmitting the error.
* **`handlers/websocket.rs:108`**: `simd_json::to_string(&pong).unwrap()` panics on keepalive serialization issues.

#### Environmental Key Initialization Failures
* **`handlers/privacy.rs:346`**: `AuthUrl::new(...).unwrap()` is a panic risk.
* **`handlers/privacy.rs:347`**: `TokenUrl::new(...).unwrap()` is a panic risk.
* **`handlers/privacy.rs:349`**: `RedirectUrl::new(...).unwrap()` is a panic risk.
* **`handlers/privacy.rs:429`**: Duplicate `.unwrap()` calls on OAuth endpoints inside `google_callback`.

---

### Clone Abuse & Allocation Inefficiencies

#### Repetitive Redundant Allocations inside REST Handlers
* **`handlers/chat.rs:49`**: `request.message.clone()`
* **`handlers/chat.rs:53`**: `request.message.clone()`
* **`handlers/chat.rs:58`**: `result.message.clone()`
* **`handlers/chat.rs:64`**: `response_message.clone()`
* **`handlers/chat.rs:98`**: `request.message.clone()`
* **`handlers/chat.rs:105`**: `request.message.clone()`
* **`handlers/chat.rs:114`**: `response.message.clone()`
* **`handlers/chat.rs:115`**: `response.tools_executed.clone()`
* **`handlers/chat.rs:207`**: `session_id.clone()`
* **`mcp_agents.rs:414`**: `request.id.clone()` called on almost every branch match of JSON-RPC processing.
* **`mcp_agents.rs:420`**: `request.id.clone()`
* **`mcp_agents.rs:425`**: `request.id.clone()`
* **`mcp_agents.rs:482`**: `request.id.clone()`
* **`mcp_agents.rs:493`**: `request.id.clone()`
* **`mcp_agents.rs:517`**: `request.id.clone()`
* **`mcp_agents.rs:534`**: `request.id.clone()`
* **`mcp_agents.rs:549`**: `request.id.clone()`

---

### Public API Leakage & Encapsulation Violations

#### Public Global Statics Exposing Mutable Config State
* **`groups_admin.rs:103`**: `pub static ref GROUPS_CONFIG: GroupsConfig = GroupsConfig::new();` is public, exposing raw filesystem serialization paths and runtime profiles to any downstream crate.
* **`websocket.rs:17`**: `WsMessage` is marked `pub` despite being exclusively designed for internal, private framing of the websocket connection task.

#### Unrestricted Filesystem Path Leakage
* **`handlers/chat.rs:426`**: `"filepath": filepath` is serialized directly into the JSON response returned to the client, leaking private host paths (e.g. `/tmp/chat-transcript-...`) to unauthenticated web API requests.