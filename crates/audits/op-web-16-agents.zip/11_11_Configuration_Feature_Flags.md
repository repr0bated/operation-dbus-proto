### 1. Environmental Variable Reads (`std::env::var`)

*   `crates/op-web/src/email.rs:30`: Reads `SMTP_HOST` to resolve the mail server host.
*   `crates/op-web/src/email.rs:31`: Reads `SMTP_PORT` to configure the SMTP transport port.
*   `crates/op-web/src/email.rs:35`: Reads `SMTP_USER` for SMTP authentication.
*   `crates/op-web/src/email.rs:36`: Reads `SMTP_PASS` for SMTP authentication.
*   `crates/op-web/src/email.rs:37`: Reads `SMTP_FROM_EMAIL` to establish the sender identity.
*   `crates/op-web/src/email.rs:39`: Reads `SMTP_FROM_NAME` for the display name on SMTP envelopes.
*   `crates/op-web/src/email.rs:41`: Reads `BASE_URL` to construct verification magic links.
*   `crates/op-web/src/main.rs:36`: Reads `PORT` to bind the Axum TCP listener.
*   `crates/op-web/src/mcp_agents.rs:541`: Reads `OP_COGNITIVE_MCP_AGENT_CONFIG` to override the default cognitive agent JSON storage path.
*   `crates/op-web/src/privacy_container.rs:51`: Reads `PRIVACY_CONTAINER_IMAGE` to set the container image for Incus provisioning.
*   `crates/op-web/src/privacy_container.rs:53`: Reads `PRIVACY_CONTAINER_PREFIX` to assign naming prefixes to user containers.
*   `crates/op-web/src/privacy_container.rs:55`: Reads `PRIVACY_CONTAINER_DEVICE` to define the user network device attachment.
*   `crates/op-web/src/privacy_container.rs:57`: Reads `PRIVACY_CONTAINER_STORAGE_POOL` to specify the target pool on non-nic containers.
*   `crates/op-web/src/privacy_container.rs:61`: Reads `PRIVACY_CONTAINER_ATTACH_BRIDGED_NIC` to toggle direct interface bridging on container spin-up.
*   `crates/op-web/src/privacy_container.rs:109`: Reads `PRIVACY_CONTAINER_BRIDGE` to configure the OVS physical bridge attachment.
*   `crates/op-web/src/privacy_routes.rs:69`: Reads `PRIVACY_ROUTE_SHARED_SECRET` as salt for deterministic HKDF route ID generation.
*   `crates/op-web/src/privacy_routes.rs:107`: Reads `PRIVACY_ROUTE_INGRESS_PORT` to select the shared socket entry point interface.
*   `crates/op-web/src/privacy_routes.rs:109`: Reads `PRIVACY_ROUTE_NEXT_HOP` to establish the interface target for outbound tunnel traffic.
*   `crates/op-web/src/state.rs:46`: Reads `GOOGLE_OAUTH_CLIENT_ID` for Google Identity verification flows.
*   `crates/op-web/src/state.rs:47`: Reads `GOOGLE_OAUTH_CLIENT_SECRET` for authorization code exchanges.
*   `crates/op-web/src/state.rs:48`: Reads `GOOGLE_OAUTH_REDIRECT_URL` to route identity flows post-authorization.
*   `crates/op-web/src/state.rs:271`: Reads `OP_DBUS_GRPC_ADDR` to target the downstream system control plane gRPC channel.
*   `crates/op-web/src/state.rs:386`: Reads `OP_WEB_TOOL_SOURCE` to determine tool indexing strategy (standalone vs. remote).
*   `crates/op-web/src/state.rs:389`: Reads `OP_WEB_PULL_TOOLS_FROM_OP_DBUS` to toggle explicit remote HTTP tool indexing.
*   `crates/op-web/src/state.rs:395`: Reads `OP_WEB_REMOTE_TOOL_URL` to target remote HTTP tool discovery endpoints.
*   `crates/op-web/src/state.rs:401`: Reads `OP_DBUS_WEB_HOST` as host fallback for remote tool requests.
*   `crates/op-web/src/state.rs:402`: Reads `OP_DBUS_WEB_PORT` as port fallback for remote tool requests.
*   `crates/op-web/src/privacy_network.rs:42`: Reads `PRIVACY_BRIDGE_NAME` to specify Open vSwitch bridge initialization target.
*   `crates/op-web/src/privacy_network.rs:44`: Reads `PRIVACY_WGCF_TUNNEL` to identify host-level Cloudflare WARP egress.
*   `crates/op-web/src/privacy_network.rs:46`: Reads `PRIVACY_PORTS` to acquire list of internal interfaces requiring linking.
*   `crates/op-web/src/privacy_network.rs:54`: Reads `PRIVACY_MGMT_CIDR` to bind local gateway management networks.
*   `crates/op-web/src/privacy_network.rs:56`: Reads `PRIVACY_OPENFLOW_CONTROLLER` to target host-level OpenFlow daemons.
*   `crates/op-web/src/privacy_network.rs:58`: Reads `XRAY_INGRESS_IP` to probe the local privacy proxy.
*   `crates/op-web/src/privacy_network.rs:60`: Reads `PRIVACY_DATAPATH_TYPE` to establish network device execution configurations.
*   `crates/op-web/src/privacy_network.rs:62`: Reads `PRIVACY_FAIL_MODE` to set OVS controller disconnect fallback models.
*   `crates/op-web/src/wireguard.rs:30`: Reads `WG_INTERFACE` to identify active Wireguard client devices.
*   `crates/op-web/src/wireguard.rs:32`: Reads `WG_SERVER_PUBKEY` for routing packets through key exchanges.
*   `crates/op-web/src/wireguard.rs:33`: Reads `WG_SERVER_PUBLIC_KEY` as primary cryptographic key fallback.
*   `crates/op-web/src/wireguard.rs:34`: Reads `WIREGUARD_PUBLIC_KEY` as secondary fallback.
*   `crates/op-web/src/wireguard.rs:38`: Reads `WG_SERVER_ENDPOINT` to locate public host entry points.
*   `crates/op-web/src/wireguard.rs:39`: Reads `VPN_ENDPOINT` as address entry point fallback.
*   `crates/op-web/src/wireguard.rs:42`: Reads `WG_ALLOWED_IPS` to declare host interface routing boundaries.
*   `crates/op-web/src/wireguard.rs:43`: Reads `VPN_ALLOWED_IPS` as routing boundary fallback.
*   `crates/op-web/src/wireguard.rs:46`: Reads `WG_DNS` to enforce target name servers on connected profiles.
*   `crates/op-web/src/wireguard.rs:47`: Reads `VPN_DNS` as name server fallback.
*   `crates/op-web/src/bin/op-dbus.rs:29`: Reads `OP_DBUS_GRPC_LISTEN` to specify binding for the gRPC system bridge.
*   `crates/op-web/src/handlers/openclaw.rs:24`: Reads `OPENCLAW_BASE_URL` to route proxied assistant generation requests.
*   `crates/op-web/src/handlers/openclaw.rs:31`: Reads `OPENCLAW_DEFAULT_MODEL` to define system-wide gateway default models.
*   `crates/op-web/src/handlers/vpn.rs:119`: Reads `VPN_ENDPOINT` to formulate download configurations.
*   `crates/op-web/src/routes/admin.rs:240`: Reads `OP_SELF_REPO_PATH` to define internal filesystem code repositories.
*   `crates/op-web/src/routes/mod.rs:225`: Reads `OP_WEB_STATIC_DIR` to construct standard file directories.

---

### 2. Configuration Files & Storage Paths

*   `crates/op-web/src/groups_admin.rs:37`: `GROUPS_CONFIG_PATH = "/var/lib/op-dbus/tool-groups.json"` — Holds dynamic presets and enabled tool profiles.
*   `crates/op-web/src/mcp_agents.rs:30`: `DEFAULT_AGENT_CONFIG_PATH = "/var/lib/op-dbus/cognitive-mcp-agents.json"` — Manages activation state, capabilities, and pre-warm configurations for MCP agents.
*   `crates/op-web/src/state.rs:166`: `/var/lib/op-dbus/privacy-users.json` — Local flat-file user credentials database.
*   `crates/op-web/src/state.rs:211`: `/var/lib/op-dbus/state.db` — Target SQLite path for transactional execution logs.
*   `crates/op-web/src/state.rs:301`: `/etc/op-dbus/llm-model` — Persisted string representing current orchestrator generation model.
*   `crates/op-web/src/state.rs:302`: `/etc/op-dbus/llm-provider` — Persisted string representing selected LLM host target.
*   `crates/op-web/src/handlers/logs.rs:28`: `/var/log/op-web.log` — Log target source.
*   `crates/op-web/src/handlers/logs.rs:29`: `/var/log/op-dbus.log` — Control plane log target source.
*   `crates/op-web/src/handlers/logs.rs:30`: `/tmp/op-web.log` — Fallback temporary log target source.
*   `crates/op-web/src/system_prompt_loader.rs:14`: Looks for `LLM-SYSTEM-PROMPT-COMPLETE.txt` locally, in sibling folder paths, or at hardcoded path `/home/jeremy/git/gemini-op-dbus/LLM-SYSTEM-PROMPT-COMPLETE.txt` to reload system instructions.

---

### 3. Hardcoded Defaults

*   `crates/op-web/src/email.rs:30`: Host default: `"localhost"`.
*   `crates/op-web/src/email.rs:34`: Port default: `587`.
*   `crates/op-web/src/email.rs:38`: From-Address default: `"noreply@example.com"`.
*   `crates/op-web/src/email.rs:40`: Display-Name default: `"Privacy Router"`.
*   `crates/op-web/src/email.rs:42`: Host entry point default: `"http://localhost:8080"`.
*   `crates/op-web/src/groups_admin.rs:53`: Defaults to `"default"` profile containing only the `"respond"` and `"info"` tool groups with a `"minimal"` configuration preset.
*   `crates/op-web/src/lib.rs:51`: IP binding defaults to `"0.0.0.0"`.
*   `crates/op-web/src/lib.rs:52`: Port binding defaults to `8080`.
*   `crates/op-web/src/lib.rs:53`: Static file serving path defaults to `Some("static".to_string())`.
*   `crates/op-web/src/lib.rs:54`: Cross-Origin Resource Sharing (CORS) defaults to `true`.
*   `crates/op-web/src/lib.rs:55`: Compression defaults to `true`.
*   `crates/op-web/src/mcp_agents.rs:142`: Pre-warmed background cognitive agents list: `"memory"`, `"context-manager"`, `"sequential-thinking"`, `"rust-pro"`.
*   `crates/op-web/src/mcp_compact.rs:74`: Pagination page size limits default to `50` (max limit `100`).
*   `crates/op-web/src/mcp_compact.rs:92`: Keyword search matches default to `20`.
*   `crates/op-web/src/mcp_compact.rs:186`: SSE endpoint keepalive intervals default to `15` seconds.
*   `crates/op-web/src/privacy_container.rs:15`: Host base image: `"images:alpine/3.19"`.
*   `crates/op-web/src/privacy_container.rs:16`: Container naming default prefix: `"privacy-user-"`.
*   `crates/op-web/src/privacy_container.rs:17`: Connected target interface naming: `"privacy0"`.
*   `crates/op-web/src/privacy_openflow.rs:10`: Integration bridge default naming: `"ovsbr0"`.
*   `crates/op-web/src/privacy_openflow.rs:11`: Magic cookie flow prefix: `0x5052_0000_0000_0000` (privacy marker).
*   `crates/op-web/src/privacy_openflow.rs:12`: Magic cookie flow mask: `0xFFFF_0000_0000_0000`.
*   `crates/op-web/src/privacy_routes.rs:10`: Bridge listening socket name: `"ovsbr0-sock"`.
*   `crates/op-web/src/privacy_routes.rs:11`: Tunnel endpoint fallback device: `"priv_wg"`.
*   `crates/op-web/src/users.rs:105`: Default allocated bandwidth quota per user: `1 GiB` (`1024 * 1024 * 1024` bytes).
*   `crates/op-web/src/users.rs:117`: Allocation last-octet fallback counter begins at `2` (avoiding host/network interfaces at `.0` and `.1`).
*   `crates/op-web/src/wireguard.rs:40`: Fallback client VPN server entrypoint: `"148.113.204.83:51820"`.
*   `crates/op-web/src/wireguard.rs:44`: Allowed routing IPs list defaults to `"0.0.0.0/0, ::/0"`.
*   `crates/op-web/src/wireguard.rs:48`: Handshake domain name resolution server: `"10.200.0.1"`.
*   `crates/op-web/src/bin/op-dbus.rs:30`: gRPC control plane binds to `"10.200.0.2:50051"`.
*   `crates/op-web/src/handlers/openclaw.rs:19`: Proxied backend endpoint: `"http://127.0.0.1:18789"`.
*   `crates/op-web/src/handlers/openclaw.rs:20`: Target deployment routing key: `"openclaw:main"`.
*   `crates/op-web/src/handlers/openclaw.rs:21`: Proxy host IP: `"127.0.0.1"`.
*   `crates/op-web/src/handlers/openclaw.rs:82`: Ping status timeout: `5` seconds.
*   `crates/op-web/src/handlers/openclaw.rs:144`: Generation request connection timeout: `60` seconds.
*   `crates/op-web/src/handlers/openclaw.rs:228`: Model description list request connection timeout: `10` seconds.
*   `crates/op-web/src/handlers/vpn.rs:125`: Configured IP pool: `"10.100.0.0/24"`.
*   `crates/op-web/src/handlers/vpn.rs:126`: Domain resolution default: `"1.1.1.1"`.
*   `crates/op-web/src/routes/admin.rs:242`: Custom instructions path: `"/etc/op-dbus/custom-prompt.txt"`.
*   `crates/op-web/src/routes/mod.rs:237`: Root static directory fallback path: `"static"`.
*   `crates/op-web/src/orchestrator/process.rs:218`: Core orchestrator requests max tokens limit: `4096`.
*   `crates/op-web/src/orchestrator/process.rs:219`: Generation temperature default: `0.7`.
*   `crates/op-web/src/orchestrator/process.rs:231`: Pulse check thinking dispatch interval: `10` seconds.
*   `crates/op-web/src/orchestrator/process.rs:241`: LLM response collection timeout limit: `60` seconds.
*   `crates/op-web/src/orchestrator/process.rs:267`: Fallback prompt generation temperature: `0.4`.
*   `crates/op-web/src/orchestrator/process.rs:273`: Fallback recovery processing timeout: `45` seconds.

---

### 4. Cargo Features & Defaults

#### Workspace Cargo Features (`Cargo.toml`)
*   No package-specific Cargo features are declared inside `crates/op-web/Cargo.toml`.
*   The primary package `op-dbus` defines:
    *   `default = ["grpc"]`
    *   `grpc = []` — Toggles native gRPC capabilities and tonic dependencies across internal components.

---

### 5. Ruthless Security Audit (Unsafe, Panics, Blocking I/O, Clone Abuse)

#### Memory Corruption & Undefined Behavior (Unsafe Deserialization)
*   `crates/op-web/src/groups_admin.rs:45`: **CRITICAL RISK**
    ```rust
    unsafe { simd_json::from_str::<HashMap<String, EnabledGroups>>(&mut raw) }
    ```
    This bypasses validation string boundaries using an unsafe mutation parsing mechanism directly within a file loader. If `/var/lib/op-dbus/tool-groups.json` is modified maliciously or written partially, this will corrupt memory.
*   `crates/op-web/src/state_manager_client.rs:35`: **CRITICAL RISK**
    ```rust
    let query_state: QueryStateResponse = unsafe { simd_json::from_str(&mut state_json) }
    ```
    Performs unsafe parsing of state objects received from D-Bus payloads.
*   `crates/op-web/src/websocket.rs:97`: **CRITICAL RISK**
    ```rust
    let ws_msg: Result<WsMessage, _> = unsafe { simd_json::from_str(&mut raw) };
    ```
    Allows unsanitized, remote, unauthenticated network packages coming from WebSocket frames to be parsed as mutable strings via `unsafe`. This is a massive remote execution/panic vector.
*   `crates/op-web/src/handlers/websocket.rs:69`: **CRITICAL RISK**
    Identical unsafe remote JSON deserialization vulnerability on incoming WebSocket text payloads.
*   `crates/op-web/src/users.rs:134`: **CRITICAL RISK**
    ```rust
    let data: StoredData = unsafe { simd_json::from_str(&mut raw) }?;
    ```
    Unsafe flat-file database deserialization from disk.
*   `crates/op-web/src/orchestrator/parsing.rs:32`: **CRITICAL RISK**
    ```rust
    unsafe { simd_json::from_str(&mut raw) }
    ```
    Parses arguments extracted from LLM text responses using `unsafe`. An LLM-hallucinated syntax error or prompt injection string containing malformed JSON can trigger undefined behavior in the parser.
*   `crates/op-web/src/orchestrator/parsing.rs:69`: **CRITICAL RISK**
    Another unsafe parsing of regex matches out of Code blocks.
*   `crates/op-web/src/orchestrator/parsing.rs:101`: **CRITICAL RISK**
    Unsafe parsing inside general function fallback parser.
*   `crates/op-web/src/orchestrator/parsing.rs:125`: **CRITICAL RISK**
    Unsafe argument conversion fallback inside JSON-RPC parser.

#### Compiled Code Failure (Broken Route Implementations)
*   `crates/op-web/src/mcp_smart_router.rs:76-78`: **COMPILER BREAKING BUG**
    ```rust
    crate::mcp_compact::mcp_compact_message_handler(
        axum::extract::Json(serde_json::Value::Null)
    ).await.into_response()
    ```
    The function signature of `mcp_compact_message_handler` inside `mcp_compact.rs` is:
    ```rust
    pub async fn mcp_compact_message_handler(
        Extension(state): Extension<Arc<AppState>>,
        Json(request): Json<JsonRpcRequest>
    ) -> Response
    ```
    `mcp_smart_router.rs` invokes this with only one argument of type `Json<serde_json::Value>`, omitting the `Extension<Arc<AppState>>` completely. This will fail to compile.
*   `crates/op-web/src/mcp_smart_router.rs:86-88`: **COMPILER BREAKING BUG**
    Identical mismatch signature failure when invoking `mcp_agents_message_handler_stateless` from the smart router.

#### Denial of Service & Panics (`.unwrap()` & Indexing)
*   `crates/op-web/src/mcp_compact.rs:427`: **PANIC VECTOR**
    ```rust
    let def = self.tool_registry.get_definition(tool_name).await.unwrap();
    ```
    If `tool_name` exists inside the `tool_registry` index but its metadata lookup fails (or has been deregistered in parallel), this `.unwrap()` will panic, crashing the Axum worker task.
*   `crates/op-web/src/embedded_ui.rs:35`: **PANIC VECTOR**
    ```rust
    Response::builder()...body(Body::from(content.data.into_owned())).unwrap()
    ```
    If the response builder states are corrupted or headers are invalid, `.unwrap()` crashes the thread.
*   `crates/op-web/src/embedded_ui.rs:52`: `.unwrap()` on SPA fallback.
*   `crates/op-web/src/embedded_ui.rs:83`: `.unwrap()` on raw fallback HTML content builders.
*   `crates/op-web/src/mcp_smart_router.rs:59`: `crate::mcp::get_app_state()` — This helper function does not exist in `mcp.rs`. Trying to compile this file directly results in unresolved import errors.

#### Thread Pool Starvation (Blocking I/O in Async Run Loop)
*   `crates/op-web/src/mcp_agents.rs:548`: Uses blocking `std::fs::read(&path)` inside an async function. This will block the tokio multi-threaded scheduler thread while reading from slower disk filesystems.
*   `crates/op-web/src/mcp_agents.rs:569`: Uses blocking `std::fs::write(&path, body)` in an async path.
*   `crates/op-web/src/system_prompt_loader.rs:34`: Uses blocking `std::fs::read_to_string` inside `load_system_prompt()`, which is executed inside the main async agent loop in `process.rs:113` via `op_chat::generate_system_prompt()`. This blocks the thread pool of the async orchestrator.

#### Performance Degradation (Heap Alloc & Clone Abuse)
*   `crates/op-web/src/email.rs:117`: Clones SMTP credential strings (`self.config.smtp_user.clone()`, `self.config.smtp_pass.clone()`) on every magic link email sending request.
*   `crates/op-web/src/main.rs:33`: Explicitly clones `state` `Arc` pointer inside runtime initialization loops: `state.clone().start_event_bridge()`.
*   `crates/op-web/src/orchestrator/process.rs:120`: Deep copies system prompts (`core_prompt.clone()`) and system message arrays during turn iterations, generating extensive heap allocations.