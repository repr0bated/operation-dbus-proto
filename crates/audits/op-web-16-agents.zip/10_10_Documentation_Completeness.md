# Product Audit: op-web

## 1. Documentation Audit (Docs Role)

### Crate-Level Documentation (lib.rs)
* **Status**: Present, but contains structural gaps.
* **Analysis**: `crates/op-web/src/lib.rs` contains crate-level documentation `//!` outlining the unified web server architecture and a text-based ASCII route diagram. However, it lacks:
  * Complete crate-level usage or startup examples.
  * Explicit security warnings regarding the IP-based access zones and hardcoded bypass keys.
  * Documentation for key configuration invariants (e.g., environment variables required for WireGuard and container provisioning).

### Public Items Missing `///` Rustdoc (Sample of 10)
1. **`crates/op-web/src/lib.rs:36`**: `ServerConfig` fields (`host`, `port`, `static_dir`, `enable_cors`, `enable_compression`) are public but completely undocumented.
2. **`crates/op-web/src/email.rs:14`**: `EmailConfig` fields (`smtp_host`, `smtp_port`, `smtp_user`, `smtp_pass`, `from_email`, `from_name`, `base_url`) are public but completely undocumented.
3. **`crates/op-web/src/email.rs:43`**: Struct `EmailSender` is public but lacks documentation.
4. **`crates/op-web/src/email.rs:48`**: Constructor `EmailSender::new` is public but lacks documentation.
5. **`crates/op-web/src/groups_admin.rs:30`**: Struct `GroupsConfig` is public but lacks documentation.
6. **`crates/op-web/src/groups_admin.rs:36`**: Struct `EnabledGroups` and its fields (`groups`, `preset`) are public but undocumented.
7. **`crates/op-web/src/mcp.rs:31`**: Struct `SseBroadcaster` and its public methods (`new`, `broadcast`, `subscribe`) are completely undocumented.
8. **`crates/op-web/src/mcp_agents.rs:51`**: Struct `ManagedAgentInfo` and all its fields are public but undocumented.
9. **`crates/op-web/src/mcp_agents.rs:62`**: Struct `CognitiveRuntimeSnapshot` and all its fields are public but undocumented.
10. **`crates/op-web/src/state.rs:104`**: Struct `AppState` and all of its public fields (`orchestrator`, `tool_registry`, `agent_registry`, etc.) are completely undocumented.

### README.md Presence
* **Status**: **Absent**. No `README.md` is present in the `crates/op-web/` folder or the workspace root.

---

## 2. Compilation & Broken APIs Audit

### Severe Compilation Failures in `mcp_smart_router.rs`
The file `crates/op-web/src/mcp_smart_router.rs` is completely broken and will cause compilation to fail due to mismatched type signatures and non-existent functions:

* **`crates/op-web/src/mcp_smart_router.rs:77`**: 
  ```rust
  crate::mcp::mcp_sse_handler(State(crate::mcp::get_app_state()), headers).await
  ```
  * **Error 1**: There is no function `get_app_state()` inside `mcp.rs` or the `mcp` module.
  * **Error 2**: `mcp::mcp_sse_handler` in `mcp.rs:111` takes only one argument (`headers: HeaderMap`), not two. Passing `State` as the first argument is a signature mismatch.
* **`crates/op-web/src/mcp_smart_router.rs:83`**:
  ```rust
  crate::mcp_compact::mcp_compact_message_handler(
      axum::extract::Json(serde_json::Value::Null)
  ).await.into_response()
  ```
  * **Error 1**: `mcp_compact_message_handler` in `mcp_compact.rs:188` takes two arguments: `Extension<Arc<AppState>>` and `Json<JsonRpcRequest>`. It cannot be called with only one argument.
  * **Error 2**: The argument is passed as `serde_json::Value::Null`, but `mcp_compact` expects `op_web::mcp_compact::JsonRpcRequest`.
* **`crates/op-web/src/mcp_smart_router.rs:94`**:
  ```rust
  crate::mcp_agents::mcp_agents_message_handler_stateless(
      axum::extract::Json(serde_json::Value::Null)
  ).await.into_response()
  ```
  * **Error**: `mcp_agents_message_handler_stateless` in `mcp_agents.rs:451` expects `Json<JsonRpcRequest>`, not `serde_json::Value`.
* **`crates/op-web/src/mcp_smart_router.rs:100`**:
  ```rust
  crate::mcp::jsonrpc_handler(
      State(crate::mcp::get_app_state()),
      axum::extract::Json(serde_json::Value::Null)
  ).await.into_response()
  ```
  * **Error**: `jsonrpc_handler` in `mcp.rs:101` expects `Extension<Arc<AppState>>` and `Json<McpRequest>`. It is passed a non-existent state function and an incorrect JSON payload type.

---

## 3. Unsafe Code Audit

### Naked/Undocumented `unsafe` Deserialization with `simd_json`
Across almost all handlers, the crate performs in-place JSON parsing using `simd_json::from_str` wrapped in an `unsafe` block without any validation of the source string's lifetime or safety invariants. `simd_json` modifies the input buffer in-place, which can lead to undefined behavior or memory corruption if the string slice is reused or if memory boundaries are violated.

* **`crates/op-web/src/groups_admin.rs:59`**:
  ```rust
  unsafe { simd_json::from_str::<HashMap<String, EnabledGroups>>(&mut raw) }
  ```
* **`crates/op-web/src/state_manager_client.rs:32`**:
  ```rust
  unsafe { simd_json::from_str(&mut state_json) }
  ```
* **`crates/op-web/src/websocket.rs:104`**:
  ```rust
  let ws_msg: Result<WsMessage, _> = unsafe { simd_json::from_str(&mut raw) };
  ```
* **`crates/op-web/src/handlers/websocket.rs:81`**:
  ```rust
  let ws_msg: Result<WsMessage, _> = unsafe { simd_json::from_str(&mut raw) };
  ```
* **`crates/op-web/src/orchestrator/execution.rs:18`**:
  ```rust
  unsafe { simd_json::from_str(&mut raw) }.unwrap_or(json!({}))
  ```
* **`crates/op-web/src/orchestrator/parsing.rs:31`**:
  ```rust
  unsafe { simd_json::from_str(&mut raw) }
  ```
* **`crates/op-web/src/orchestrator/parsing.rs:80`**:
  ```rust
  unsafe { simd_json::from_str(&mut raw) }
  ```
* **`crates/op-web/src/orchestrator/parsing.rs:114`**:
  ```rust
  unsafe { simd_json::from_str(&mut raw) }
  ```
* **`crates/op-web/src/orchestrator/parsing.rs:125`**:
  ```rust
  unsafe { simd_json::from_str::<Value>(&mut raw) }
  ```
* **`crates/op-web/src/orchestrator/process.rs:170`**:
  ```rust
  unsafe { simd_json::from_str(&mut raw) }
  ```
* **`crates/op-web/src/users.rs:122`**:
  ```rust
  let data: StoredData = unsafe { simd_json::from_str(&mut raw) }?;
  ```

---

## 4. Unwrap & Expect (Panic Risks)

The following locations represent unhandled panic vectors that will crash the server thread or the entire process:

* **`crates/op-web/src/state.rs:153`**:
  ```rust
  .expect("Failed to create user store")
  ```
  If `/var/lib/op-dbus/privacy-users.json` is not writeable or its parent directory does not exist, the server crashes immediately during initialization.
* **`crates/op-web/src/state.rs:218`**:
  ```rust
  .expect("Failed to create in-memory state store")
  ```
  Crashes the application if SQLite in-memory instantiation fails.
* **`crates/op-web/src/state.rs:596`**:
  ```rust
  let mut lines = MuxedLines::new().expect("Failed to create MuxedLines");
  ```
  Crashes the background log-watching thread if the `linemux` inotify subsystem fails to initialize.
* **`crates/op-web/src/state.rs:658`**:
  ```rust
  let session_introspection = Arc::new(op_introspection::IntrospectionService::new());
  ```
  Inside initialization, this can panic if DBus connection parameters are unavailable.
* **`crates/op-web/src/server.rs:136`**:
  ```rust
  let governor_conf = GovernorConfigBuilder::default() ... .finish().unwrap();
  ```
  Panics during startup if the rate-limiter configuration bounds are invalid.
* **`crates/op-web/src/websocket.rs:53`**:
  ```rust
  ws_sender.send(Message::Text(simd_json::to_string(&welcome).unwrap())).await
  ```
  Panics the WebSocket connection task if serialization of the welcome struct fails.
* **`crates/op-web/src/handlers/auth_bridge.rs:105`**:
  ```rust
  .unwrap_or_else(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal error").into_response());
  ```
  Unwrap on builder patterns without proper error propagation.
* **`crates/op-web/src/bin/op-dbus.rs:30`**:
  ```rust
  let addr: std::net::SocketAddr = listen.parse().unwrap_or_else(|_| "10.200.0.2:50051".parse().unwrap());
  ```
  Nested `unwrap()` on socket address parsing. If both fail, the core system daemon panics.

---

## 5. Clone Abuse

Unnecessary memory allocations and overhead from cloning:

* **`crates/op-web/src/main.rs:34-35`**:
  ```rust
  state.clone().start_event_bridge();
  state.clone().start_system_monitor();
  ```
  `state` is an `Arc<AppState>`. Cloning the Arc is cheap, but chaining `state.clone()` successively on the main thread is redundant; references could be passed directly or used inside the tasks.
* **`crates/op-web/src/state.rs:511`**:
  ```rust
  "tool_name": self.name.clone(),
  ```
  Cloning `self.name` on every single remote tool execution payload creation instead of borrowing.
* **`crates/op-web/src/orchestrator/process.rs:125`**:
  ```rust
  let request = ChatRequest {
      messages: messages.clone(),
  ```
  In a multi-turn orchestration loop (up to 50 turns), the entire conversation history vector `messages` (which grows sequentially) is cloned deep on every single step.
* **`crates/op-web/src/mcp_agents.rs:520`**:
  ```rust
  request.id.clone()
  ```
  Cloning the `simd_json::OwnedValue` ID multiple times when building standard JSON-RPC responses.
* **`crates/op-web/src/users.rs:211`**:
  ```rust
  users_by_email.insert(user.email.clone(), user.id.clone());
  users.insert(user.id.clone(), user.clone());
  ```
  Heavy cloning of the entire `PrivacyUser` struct and strings during registration.

---

## 6. Public API Leakage & Hardcoded Credentials

* **`crates/op-web/src/middleware/security.rs:15`**:
  ```rust
  const BYPASS_API_KEYS: &[&str] = &[
      "4f8c2b5d-9a1e-4b7c-8d2f-3a6b5c9e4d1f", // Primary MCP access key
      "test-key-huggingface-2024",            // Hugging Face test key
  ];
  ```
  **Critical Security Risk**: Hardcoded security credentials in the source code. Anyone with access to the binary or code can bypass all network security zones to gain full `TrustedMesh` system access (root equivalent control over network and DBus).
* **`crates/op-web/src/email.rs:59-65`**:
  ```rust
  info!("🔗 MAGIC LINK (no SMTP configured):");
  info!("   To: {}", to_email);
  info!("   URL: {}", magic_url);
  info!("   Token: {}", token);
  ```
  **Token Leakage**: If SMTP is unconfigured, the magic login tokens are dumped in cleartext to the system log (syslog/journald). Any local unprivileged user or log aggregator can read these logs, hijack the authentication tokens, and download WireGuard configuration profiles.
* **`crates/op-web/src/handlers/chat.rs:434`**:
  ```rust
  let filepath = format!("/tmp/{}", filename);
  match tokio::fs::write(&filepath, &transcript).await {
  ```
  **Insecure File Path Write**: Writes conversation transcripts directly to `/tmp` with predictable user-supplied filenames. This is vulnerable to symlink attacks, arbitrary file overwrites, and local information disclosure.