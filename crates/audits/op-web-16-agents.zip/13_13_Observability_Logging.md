# Unified Web Server Observability & Security Audit

## 1. Trace / Log / Println! Counts

An audit of standard logging and console output macros across the codebase reveals the following metrics:

*   **`tracing::info!` / `info!`**: 67 occurrences
*   **`tracing::warn!` / `warn!`**: 23 occurrences
*   **`tracing::error!` / `error!`**: 41 occurrences
*   **`tracing::debug!` / `debug!`**: 11 occurrences
*   **`log::*` (standard `log` crate macros)**: 0 occurrences
*   **`println!` / `print!`**: 6 occurrences (confined strictly to the local mock/test delivery bypass inside the email sender).

### Key Localized Println! Detections
*   **`crates/op-web/src/email.rs:67-70`**: Emits the user's private authentication token and magic link credentials directly to stdout when SMTP is unconfigured. 
    ```rust
    println!("\n=== MAGIC LINK FOR TESTING ===");
    println!("Email: {}", to_email);
    println!("Link: {}", magic_url);
    println!("==============================\n");
    ```
    *Architectural Danger:* In production, if environmental configuration errors prevent the SMTP subsystem from resolving, private tokens are dumped in plain text to the container stdout, leaking system secrets directly into systemd/Incus logs.

---

## 2. Metric Collection Detections

The codebase does not natively pull in or publish telemetry via standard crates such as `prometheus` or `metrics`. Instead, the system relies on ad-hoc, manual metric harvesting across three distinct boundaries:

### A. Ad-hoc OS and System Metric Harvesting
*   **`crates/op-web/src/state.rs:242`**: The core system monitor utilizes `sysinfo` to poll hardware states every 2 seconds, serializing raw metrics and broadcasting them as SSE packets over event type `"system_stats"`.
    ```rust
    let memory_total_mb = sys.total_memory() / 1024 / 1024;
    let memory_used_mb = sys.used_memory() / 1024 / 1024;
    let cpu_usage = sys.global_cpu_info().cpu_usage();
    ```
*   **`crates/op-web/src/handlers/dashboard.rs:59-90`**: Direct filesystem scraping of `/proc/loadavg` and `/proc/meminfo` is utilized to gather platform telemetry. This bypasses standard system collectors, risking parsing panics if formatting differs between kernel versions.

### B. Command Execution Metrics
*   **`crates/op-web/src/handlers/dashboard.rs:49`** and **`crates/op-web/src/handlers/vpn.rs:24`**: Telemetry for active WireGuard peers and VPN tunnels is collected by executing shell utilities (`wg show wg0 peers` and `wg show wg0 dump`) inside synchronous commands.
    *Architectural Danger:* Spawning shell processes on high-frequency API hits (`/api/dashboard/metrics`) is extremely expensive and causes thread starvation.

---

## 3. Error Handling and Context Analysis

The codebase exhibits a split architecture regarding error propagation. Domain-specific, low-level modules utilize `anyhow::Context` for structural tracking, while the API handlers discard rich error contexts in favor of raw strings.

### A. Context Propagation Successes
The system infrastructure layer uses `anyhow::Result` along with `.context()` and `.with_context()` to trace systemic failures:
*   **`crates/op-web/src/state_manager_client.rs:37`**: Captures payload parsing failures during DBus state synchronization.
*   **`crates/op-web/src/state_manager_client.rs:56`**: Attaches context to serialized contract mutations.
*   **`crates/op-web/src/privacy_routes.rs:80`**: Detects missing cryptographic secret variables.
*   **`crates/op-web/src/privacy_network.rs:77`**: Attaches context to OVSDB bridge creation failures.

### B. Anti-Pattern: Context Erasure in API Handlers
API handlers routinely discard typed errors and rich contexts, converting them to plain string results:
*   **`crates/op-web/src/handlers/agents.rs:57`**:
    ```rust
    Err(e) => Json(json!({ "error": e.to_string(), "success": false }))
    ```
*   **`crates/op-web/src/handlers/chat.rs:88`**:
    ```rust
    Err(e) => Json(ChatResponse { ... error: Some(e.to_string()) ... })
    ```
*   **`crates/op-web/src/handlers/privacy.rs:169`**: Discards underlying failures when registering new WireGuard users, exposing only generic failure strings to callers.

### C. `thiserror` Absence
Though declared as a dependency in `Cargo.toml`, `thiserror` is not implemented in any of the audited source files. The codebase relies entirely on dynamic `anyhow::Error` instantiation, making programmatically matching and recovering from specific error classes (e.g., connection dropouts vs. validation issues) impossible.

---

## 4. Technical Debt, Safety Violations, and API Leakage

This section details severe security and structural issues discovered during the audit.

### A. Severe Unsafe Code Violations (`simd_json`)
`simd-json` is a highly optimized, mutable JSON parser. It requires an exclusive mutable reference (`&mut`) because it mutates the input slice to perform zero-copy deserialization. The audited code contains multiple critical safety violations:

*   **`crates/op-web/src/groups_admin.rs:43`**:
    ```rust
    unsafe { simd_json::from_str::<HashMap<String, EnabledGroups>>(&mut raw) }
    ```
*   **`crates/op-web/src/state_manager_client.rs:36`**:
    ```rust
    unsafe { simd_json::from_str(&mut state_json) }
    ```
*   **`crates/op-web/src/websocket.rs:111`**:
    ```rust
    let ws_msg: Result<WsMessage, _> = unsafe { simd_json::from_str(&mut raw) };
    ```
*   **`crates/op-web/src/handlers/websocket.rs:75`**:
    ```rust
    let ws_msg: Result<WsMessage, _> = unsafe { simd_json::from_str(&mut raw) };
    ```

#### The Bug
`simd_json::from_str` is marked `unsafe` because it mutates the backing buffer of the string *while* returning zero-copy references tied to the input string's lifetime. 
Using `unsafe { simd_json::from_str(...) }` without documenting safety invariants or verifying that the buffer is uniquely owned, correctly aligned, and free of aliasing is a massive safety hazard. If `raw` contains malformed bytes, or if string references escape inappropriately, this will cause memory corruption, segmentation faults, or buffer overflows.

### B. Arbitrary Panics (Unwrap Abuse)
The server contains panic hazards during runtime setup where non-exceptional errors trigger immediate process aborts:

*   **`crates/op-web/src/server.rs:127`**:
    ```rust
    let governor_conf = GovernorConfigBuilder::default()
        .per_second(rate_limit_per_sec)
        .burst_size(self.config.rate_limit.burst_size as u32)
        .finish()
        .unwrap(); // PANIC RISK
    ```
    If rate limiter limits are set dynamically or overflow standard u32 bounds, the server will panic and crash on startup.
*   **`crates/op-web/src/handlers/openclaw.rs:94`**, **`L141`**, **`L194`**, **`L214`**:
    ```rust
    let client = Client::builder().timeout(Duration::from_secs(5)).build().unwrap(); // PANIC RISK
    ```
    Instantiating high-frequency HTTP clients with raw `.unwrap()` on every request handler hit will crash the worker threads if the OS runs out of file descriptors.

### C. Clone Abuse and Allocation Bloat
*   **`crates/op-web/src/groups_admin.rs:42`**:
    ```rust
    let mut raw = content.clone(); // Allocates copies of massive JSON configurations
    ```
    This duplication is repeated on every load to satisfy `simd_json`'s mutability requirement. This defeats the purpose of zero-copy parsing.
*   **`crates/op-web/src/orchestrator/execution.rs:71`**:
    ```rust
    "execute_tool" => {
        let tool_name = args.get("tool_name").and_then(|v| v.as_str()).unwrap_or("");
        let tool_args = args.get("arguments").cloned().unwrap_or(json!({})); // Clones nested JSON Value trees
        return Box::pin(self.execute_tool(tool_name, tool_args)).await;
    }
    ```
    Recursively cloning JSON structural nodes inside the core execution loop causes significant heap thrashing under heavy LLM usage.

### D. Global State Mutation and Thread Locking Risks
Global shared state variables are exposed directly via lazy static instances using coarse locks:

*   **`crates/op-web/src/groups_admin.rs:107`**:
    ```rust
    lazy_static::lazy_static! {
        pub static ref GROUPS_CONFIG: GroupsConfig = GroupsConfig::new();
    }
    ```
    This exposes global `RwLock` wrappers over tool groups. High-frequency API calls requesting the current profile block writers from saving modifications, leading to lock starvation and latency spikes.
*   **`crates/op-web/src/mcp_agents.rs:315`**:
    ```rust
    lazy_static::lazy_static! {
        static ref GLOBAL_AGENTS_STATE: Arc<AgentsMcpState> = Arc::new(AgentsMcpState::new());
    }
    ```
    Exposing the critical agent state globally bypasses dependency injection. This makes unit testing impossible and introduces data race conditions if state changes during test execution.

---

## 5. Summary of Recommended Remedies

1.  **Eliminate Unsafe `simd_json` Deserialization**: Replace dangerous `unsafe { simd_json::from_str(...) }` blocks with standard, safe parsers such as `serde_json::from_str`, or use `simd_json::from_slice` after converting inputs to mutable byte vectors.
2.  **Clean up Panic Hazards**: Replace all `.unwrap()` calls in `server.rs` and `handlers/openclaw.rs` with proper error propagation (`?` or `and_then`).
3.  **Implement Structured Logging**: Transition unstructured string-erased handler errors (`e.to_string()`) to a structured, typed error enum using `thiserror` to preserve observability context.
4.  **Enforce Dependency Injection**: Refactor the global `lazy_static` configurations (`GROUPS_CONFIG`, `GLOBAL_AGENTS_STATE`) out of the codebase. Instead, pass these configuration caches within the `AppState` struct to ensure thread safety and simplify test mocking.