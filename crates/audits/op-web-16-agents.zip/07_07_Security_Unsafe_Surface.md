# Security Audit Report: op-web

## 1. Unsafe Block Audit

All discovered `unsafe` blocks are listed below. Every block represents an undocumented call to `simd_json::from_str` or `simd_json::from_slice`. **Crucially, not a single unsafe block contains the required `// SAFETY:` comment.** 

*   `crates/op-web/src/groups_admin.rs:46`
    ```rust
    if let Ok(saved) = unsafe { simd_json::from_str::<HashMap<String, EnabledGroups>>(&mut raw) }
    ```
    *   **Flag:** `// SAFETY:` comment is **MISSING**. 
    *   **Risk:** `simd_json` in-place parsing mutates the source string. If `raw` is reused or does not outlive the deserialized structures, it will lead to undefined behavior.

*   `crates/op-web/src/state_manager_client.rs:33`
    ```rust
    let query_state: QueryStateResponse = unsafe { simd_json::from_str(&mut state_json) }
    ```
    *   **Flag:** `// SAFETY:` comment is **MISSING**.
    *   **Risk:** Deserializes raw D-Bus JSON-RPC payloads in-place. If the returned payload is modified concurrently or dropped before `query_state`, memory corruption occurs.

*   `crates/op-web/src/websocket.rs:81`
    ```rust
    let ws_msg: Result<WsMessage, _> = unsafe { simd_json::from_str(&mut raw) };
    ```
    *   **Flag:** `// SAFETY:` comment is **MISSING**.
    *   **Risk:** Directly parses untrusted WebSocket text messages in-place without safety assertions.

*   `crates/op-web/src/users.rs:92`
    ```rust
    let data: StoredData = unsafe { simd_json::from_str(&mut raw) }?;
    ```
    *   **Flag:** `// SAFETY:` comment is **MISSING**.
    *   **Risk:** Decodes the persistent database file `privacy-users.json` in-place. Any truncation or formatting corruption on disk can trigger memory safety issues during parsing.

*   `crates/op-web/src/handlers/websocket.rs:62`
    ```rust
    let ws_msg: Result<WsMessage, _> = unsafe { simd_json::from_str(&mut raw) };
    ```
    *   **Flag:** `// SAFETY:` comment is **MISSING**.
    *   **Risk:** Identical vulnerability to the other WebSocket handler, parsing WebSocket frames in-place with zero validation.

*   `crates/op-web/src/orchestrator/execution.rs:69`
    ```rust
    unsafe { simd_json::from_str(&mut raw) }.unwrap_or(json!({}))
    ```
    *   **Flag:** `// SAFETY:` comment is **MISSING**.
    *   **Risk:** Parses direct command line orchestration arguments in-place.

*   `crates/op-web/src/orchestrator/parsing.rs:31`
    ```rust
    if let Ok(parsed) = unsafe { simd_json::from_str(&mut raw) } {
    ```
    *   **Flag:** `// SAFETY:` comment is **MISSING**.
    *   **Risk:** Extracting tool calls from XML tags parsed in-place.

*   `crates/op-web/src/orchestrator/parsing.rs:90`
    ```rust
    if let Ok(parsed) = unsafe { simd_json::from_str(&mut raw) } {
    ```
    *   **Flag:** `// SAFETY:` comment is **MISSING**.
    *   **Risk:** Parses inline tool call regex matches in-place.

*   `crates/op-web/src/orchestrator/parsing.rs:119`
    ```rust
    unsafe { simd_json::from_str(&mut raw) }.unwrap_or(json!({}))
    ```
    *   **Flag:** `// SAFETY:` comment is **MISSING**.
    *   **Risk:** Decodes arguments string from upstream model response structure in-place.

*   `crates/op-web/src/orchestrator/parsing.rs:137`
    ```rust
    if let Ok(parsed) = unsafe { simd_json::from_str::<Value>(&mut raw) } {
    ```
    *   **Flag:** `// SAFETY:` comment is **MISSING**.
    *   **Risk:** Fallback parser that decodes JSON tool call blocks embedded in assistant Markdown content in-place.

---

## 2. Command, Process, and Shell-Words Usage

*   **`Command::new` / `std::process` Count:** **7 occurrences**
    *   `crates/op-web/src/wireguard.rs:81`: `Command::new("wg").args(["show", interface, "public-key"])`
    *   `crates/op-web/src/handlers/dashboard.rs:38`: `Command::new("wg").args(&["show", "wg0", "peers"])`
    *   `crates/op-web/src/handlers/logs.rs:32`: `Command::new("tail").args(&["-n", "50", log_path])`
    *   `crates/op-web/src/handlers/mail.rs:21`: `Command::new("incus").args(&["exec", "crd-astral", "--", "systemctl", "is-active", "maddy"])`
    *   `crates/op-web/src/handlers/vpn.rs:41`: `Command::new("wg").args(&["show", interface])`
    *   `crates/op-web/src/handlers/vpn.rs:55`: `Command::new("wg").args(&["show", interface, "dump"])`
    *   `crates/op-web/src/handlers/vpn.rs:118`: `Command::new("wg").args(&["show", interface, "public-key"])`
    *   *(Note: `crates/op-web/src/handlers/status.rs:230` also spawns `doas dinitctl list` via `tokio::process::Command`)*
*   **`shell-words` Count:** **0 occurrences** (imported in workspace dependency tree but not directly called in `op-web` files).

---

## 3. Hardcoded Secrets, IPs, and Environment Variable Reads

### Hardcoded Secrets
*   `crates/op-web/src/middleware/security.rs:15`
    ```rust
    "4f8c2b5d-9a1e-4b7c-8d2f-3a6b5c9e4d1f" // Primary MCP access key
    ```
*   `crates/op-web/src/middleware/security.rs:16`
    ```rust
    "test-key-huggingface-2024"            // Hugging Face test key
    ```

### Hardcoded IPs / Private Subnets
*   `crates/op-web/src/wireguard.rs:60`: `"148.113.204.83:51820"` (VPN server default endpoint)
*   `crates/op-web/src/wireguard.rs:68`: `"10.200.0.1"` (Default DNS server)
*   `crates/op-web/src/handlers/vpn.rs:125`: `"148.113.204.83:51820"` (Duplicate hardcoded remote endpoint)
*   `crates/op-web/src/privacy_network.rs:24`: `"10.200.0.1/24"` (Management network default CIDR)
*   `crates/op-web/src/privacy_network.rs:25`: `"10.200.0.1:6653"` (Default OpenFlow Controller IP)
*   `crates/op-web/src/privacy_network.rs:63`: `"10.200.0.1"` (Xray default bind)
*   `crates/op-web/src/state.rs:236`: `"http://10.200.0.2:50051"` (Default gRPC endpoint)
*   `crates/op-web/src/bin/op-dbus.rs:25`: `"10.200.0.2:50051"` (gRPC default listen binding)

### Environment Variable Reads (`std::env::var`)
*   `crates/op-web/src/email.rs:31`: `"SMTP_HOST"`
*   `crates/op-web/src/email.rs:32`: `"SMTP_PORT"`
*   `crates/op-web/src/email.rs:36`: `"SMTP_USER"`
*   `crates/op-web/src/email.rs:37`: `"SMTP_PASS"`
*   `crates/op-web/src/email.rs:38`: `"SMTP_FROM_EMAIL"`
*   `crates/op-web/src/email.rs:40`: `"SMTP_FROM_NAME"`
*   `crates/op-web/src/email.rs:42`: `"BASE_URL"`
*   `crates/op-web/src/main.rs:34`: `"PORT"`
*   `crates/op-web/src/mcp_agents.rs:735`: `"OP_COGNITIVE_MCP_AGENT_CONFIG"`
*   `crates/op-web/src/privacy_container.rs:53`: `"PRIVACY_CONTAINER_IMAGE"`
*   `crates/op-web/src/privacy_container.rs:55`: `"PRIVACY_CONTAINER_PREFIX"`
*   `crates/op-web/src/privacy_container.rs:57`: `"PRIVACY_CONTAINER_DEVICE"`
*   `crates/op-web/src/privacy_container.rs:59`: `"PRIVACY_CONTAINER_STORAGE_POOL"`
*   `crates/op-web/src/privacy_container.rs:61`: `"PRIVACY_CONTAINER_ATTACH_BRIDGED_NIC"`
*   `crates/op-web/src/privacy_container.rs:126`: `"PRIVACY_CONTAINER_BRIDGE"`
*   `crates/op-web/src/privacy_routes.rs:71`: `"PRIVACY_ROUTE_SHARED_SECRET"`
*   `crates/op-web/src/privacy_routes.rs:115`: `"PRIVACY_ROUTE_INGRESS_PORT"`
*   `crates/op-web/src/privacy_routes.rs:117`: `"PRIVACY_ROUTE_NEXT_HOP"`
*   `crates/op-web/src/privacy_network.rs:50`: `"PRIVACY_BRIDGE_NAME"`
*   `crates/op-web/src/privacy_network.rs:51`: `"PRIVACY_WGCF_TUNNEL"`
*   `crates/op-web/src/privacy_network.rs:54`: `"PRIVACY_PORTS"`
*   `crates/op-web/src/privacy_network.rs:59`: `"PRIVACY_MGMT_CIDR"`
*   `crates/op-web/src/privacy_network.rs:61`: `"PRIVACY_OPENFLOW_CONTROLLER"`
*   `crates/op-web/src/privacy_network.rs:63`: `"XRAY_INGRESS_IP"`
*   `crates/op-web/src/privacy_network.rs:65`: `"PRIVACY_DATAPATH_TYPE"`
*   `crates/op-web/src/privacy_network.rs:67`: `"PRIVACY_FAIL_MODE"`
*   `crates/op-web/src/state.rs:51`: `"GOOGLE_OAUTH_CLIENT_ID"`
*   `crates/op-web/src/state.rs:52`: `"GOOGLE_OAUTH_CLIENT_SECRET"`
*   `crates/op-web/src/state.rs:53`: `"GOOGLE_OAUTH_REDIRECT_URL"`
*   `crates/op-web/src/state.rs:236`: `"OP_DBUS_GRPC_ADDR"`
*   `crates/op-web/src/state.rs:383`: `"OP_WEB_TOOL_SOURCE"`
*   `crates/op-web/src/state.rs:386`: `"OP_WEB_PULL_TOOLS_FROM_OP_DBUS"`
*   `crates/op-web/src/state.rs:392`: `"OP_WEB_REMOTE_TOOL_URL"`
*   `crates/op-web/src/state.rs:399`: `"OP_DBUS_WEB_HOST"`
*   `crates/op-web/src/state.rs:400`: `"OP_DBUS_WEB_PORT"`
*   `crates/op-web/src/wireguard.rs:47`: `"WG_INTERFACE"`
*   `crates/op-web/src/wireguard.rs:49`: `"WG_SERVER_PUBKEY"` / `"WG_SERVER_PUBLIC_KEY"` / `"WIREGUARD_PUBLIC_KEY"`
*   `crates/op-web/src/wireguard.rs:57`: `"WG_SERVER_ENDPOINT"` / `"VPN_ENDPOINT"`
*   `crates/op-web/src/wireguard.rs:61`: `"WG_ALLOWED_IPS"` / `"VPN_ALLOWED_IPS"`
*   `crates/op-web/src/wireguard.rs:65`: `"WG_DNS"` / `"VPN_DNS"`
*   `crates/op-web/src/bin/op-dbus.rs:24`: `"OP_DBUS_GRPC_LISTEN"`
*   `crates/op-web/src/handlers/openclaw.rs:19`: `"OPENCLAW_BASE_URL"`
*   `crates/op-web/src/handlers/openclaw.rs:26`: `"OPENCLAW_DEFAULT_MODEL"`

---

## 4. Unwraps, Panic Risks, and Clone Abuse

### Panic Vectors & Unwrap Abuse
*   `crates/op-web/src/server.rs:156`
    ```rust
    let governor_conf = GovernorConfigBuilder::default().per_second(rate_limit_per_sec).burst_size(...).finish().unwrap();
    ```
    *   **Risk:** Panics on launch if rate limit configuration math invariants are violated.
*   `crates/op-web/src/state.rs:175`
    ```rust
    UserStore::new("/var/lib/op-dbus/privacy-users.json").await.expect("Failed to create user store")
    ```
    *   **Risk:** Panics if the target directory doesn't exist or is read-only.
*   `crates/op-web/src/state.rs:228`
    ```rust
    SqliteStore::new(":memory:").await.expect("Failed to create in-memory state store")
    ```
    *   **Risk:** Panics if the fallback in-memory database configuration fails.
*   `crates/op-web/src/handlers/websocket.rs:45`, `:55`, `:96`, `:104`, `:118`, `:126`
    *   **Risk:** Repetitive use of `.unwrap()` on raw `simd_json::to_string(&welcome)` / `simd_json::to_string(&pong)`. If serializing payload variants encounters issues, it crashes the active WebSocket connection handler.
*   `crates/op-web/src/handlers/openclaw.rs:110`, `:156`, `:194`
    *   **Risk:** Unwrapping HTTP response states or configuration strings in direct gateway proxies.
*   `crates/op-web/src/handlers/privacy.rs:588`, `:589`, `:591`
    *   **Risk:** Call to `.unwrap()` on OAuth URL initializers.

### Clone Abuse (Heavy / Unnecessary Clones)
*   `crates/op-web/src/main.rs:31-32`
    ```rust
    state.clone().start_event_bridge();
    state.clone().start_system_monitor();
    ```
    *   **Impact:** Redundant clones of the shared state Arc instead of passing by reference.
*   `crates/op-web/src/mcp_compact.rs:413`
    ```rust
    let arguments = args.get("arguments").cloned().unwrap_or(json!({}));
    ```
    *   **Impact:** Unnecessary heap allocation cloned before immediate consumption.
*   `crates/op-web/src/websocket.rs:73-75`
    *   **Impact:** Heavy cloning of thread-shared variables `state_clone`, `session_clone`, and `session_tx_clone` inside loop closures.

### Public API / Environment Leakage
*   `crates/op-web/src/system_prompt_loader.rs:18-19`
    ```rust
    "/home/jeremy/git/gemini-op-dbus/LLM-SYSTEM-PROMPT-COMPLETE.txt",
    "/home/jeremy/op-dbus-v2/LLM-SYSTEM-PROMPT-COMPLETE.txt"
    ```
    *   **Leak:** Hardcoded local home directory paths (`/home/jeremy/...`) leaked in public system prompt fallback routines.
*   `crates/op-web/src/mcp_discovery.rs:21`
    ```rust
    let host = headers.get("host").and_then(|v| v.to_str().ok()).unwrap_or("op-dbus.ghostbridge.tech:3001");
    ```
    *   **Leak:** Production DNS endpoint (`op-dbus.ghostbridge.tech`) hardcoded directly inside fallback headers.