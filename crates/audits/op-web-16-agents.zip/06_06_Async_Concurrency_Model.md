### Async & Concurrency Metrics

* **`async fn` count**: 178 declarations
* **`tokio::spawn` count**: 11 occurrences
* **`spawn_blocking` count**: 0 occurrences (Critical architectural issue: no CPU-heavy or blocking I/O is offloaded to the blocking thread pool).

---

### Send/Sync Bounds on Public Traits

There are **no custom public trait definitions** inside this crate. However, Send/Sync bounds are enforced on external dynamically dispatched trait objects:
* `crates/op-web/src/mcp_agents.rs:150`: `running: HashMap<String, Arc<dyn Agent + Send + Sync>>` — Forces custom agents to implement `Send + Sync`.
* `crates/op-web/src/state.rs:113`: `pub state_store: Arc<dyn StateStore>` — Implicitly requires `Send + Sync` on the state store implementation.

---

### Critical Audit Findings

#### 1. Blocking Calls in Async Contexts (Executor Thread Starvation)
Synchronous file system access and process execution (`std::process::Command`, `std::fs`, `Path::exists`) are executed directly on the tokio reactor thread without `spawn_blocking` or async alternatives:

* **`crates/op-web/src/mcp_agents.rs:409`**: `save_agent_config(&applied)?;` inside the async `set_cognitive_agents` function blocks the thread during JSON serialization and file writing.
* **`crates/op-web/src/privacy_network.rs:83`, `98`, `113`, `122`**: `Path::new(...).exists()` blocks the async execution loop while probing interface directories in `/sys`.
* **`crates/op-web/src/users.rs:83`**: `Path::new(&self.storage_path).exists()` blocks the thread within `async fn load`.
* **`crates/op-web/src/handlers/dashboard.rs:43`**: `Command::new("wg").output()` executes a blocking system command synchronously inside an async handler.
* **`crates/op-web/src/handlers/dashboard.rs:60`, `72`**: Uses `std::fs::read_to_string` on `/proc/loadavg` and `/proc/meminfo` synchronously, causing performance degradation under load.
* **`crates/op-web/src/handlers/logs.rs:31`**: Uses `Command::new("tail").output()` in a synchronous loop inside `async fn logs_handler`.
* **`crates/op-web/src/handlers/status.rs:91`**: `sys.refresh_all()` is a heavy synchronous polling function executed directly inside `status_handler`.
* **`crates/op-web/src/handlers/vpn.rs:36`, `47`, `105`**: Executes synchronous `Command::new("wg")` subprocesses on every VPN status/config request.
* **`crates/op-web/src/handlers/mail.rs:22`**: Spawns a synchronous `Command::new("incus")` execution on the hot path of `mail_status_handler`.

#### 2. Panicking `.unwrap()` and `.expect()` Usage
* **`crates/op-web/src/server.rs:113`**: `.unwrap()` on `GovernorConfigBuilder::default()...finish()` will crash the entire server at startup if parameters are invalid.
* **`crates/op-web/src/websocket.rs:70`**: `.unwrap()` on `simd_json::to_string(&welcome)` will panic the connection task if welcome message serialization fails.
* **`crates/op-web/src/websocket.rs:104`, `131`, `132`**: Multiple `.unwrap()` calls on socket response serialization can panic active WebSocket sessions.
* **`crates/op-web/src/handlers/websocket.rs:48`, `82`, `98`, `104`, `119`, `125`**: Duplicate unwrap-on-serialize logic throughout the secondary websocket handler.
* **`crates/op-web/src/orchestrator/execution.rs:183`**: `.unwrap()` on `self.tool_registry.get_definition(tool_name).await` will panic the model workflow if a tool is retrieved but its schema registration is inconsistent.
* **`crates/op-web/src/handlers/openclaw.rs:70`, `140`, `221`**: `Client::builder().build().unwrap()` will panic the router if the platform's TLS configuration fails.
* **`crates/op-web/src/handlers/privacy.rs:551`, `552`, `554`, `608`, `609`, `611`**: High-risk `.unwrap()` on oauth2 URL parsing. If configuration variables contain invalid formats, the endpoint will panic.
* **`crates/op-web/src/state.rs:216`, `240`**: `.expect()` used during fallback instantiation. If file system write permissions fail on `/var/lib/op-dbus/`, the server panics rather than gracefully handling errors.
* **`crates/op-web/src/bin/op-dbus.rs:28`**: `.unwrap()` nested inside `unwrap_or_else` on port parsing.

#### 3. Unsafe Blocks (Simd-JSON Inplace Modification risks)
`simd-json` requires a mutable slice because it modifies the string in-place. The crate wraps these operations in `unsafe`, but there is zero validation that the input buffers are not reused or aliased.
* **`crates/op-web/src/groups_admin.rs:51`**: `unsafe { simd_json::from_str(...) }`
* **`crates/op-web/src/state_manager_client.rs:35`**: `unsafe { simd_json::from_str(...) }`
* **`crates/op-web/src/websocket.rs:100`**: `unsafe { simd_json::from_str(...) }`
* **`crates/op-web/src/handlers/websocket.rs:61`**: `unsafe { simd_json::from_str(...) }`
* **`crates/op-web/src/orchestrator/parsing.rs:31`, `80`, `104`, `113`**: `unsafe { simd_json::from_str(...) }`

#### 4. Memory and Clone Abuse
* **`crates/op-web/src/groups_admin.rs:49`**: `let mut raw = content.clone();` clones the entire loaded JSON string buffer. Since `content` is consumed immediately and never used again, this allocation is entirely redundant.
* **`crates/op-web/src/state.rs:31-32`**: `state.clone().start_event_bridge()` and `state.clone().start_system_monitor()` explicitly clone the `Arc<AppState>` when the receiver's `self: Arc<Self>` type automatically clones or takes ownership.
* **`crates/op-web/src/mcp_compact.rs:491`**: `Some(res.clone())` clones the inner `OwnedValue` array/object structure unnecessarily before storing.

#### 5. Public API Leakage
* **`crates/op-web/src/state.rs:43`**: `pub struct UserApiCredentials` exposes sensitive cleartext provider keys (`gemini_api_key`, `anthropic_api_key`, `openai_api_key`) in its public fields. These keys are transitively leaked through standard serialization and exposed in logs or diagnostics if the struct is ever printed.