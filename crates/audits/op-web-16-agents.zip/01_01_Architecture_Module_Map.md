# Architecture & Module Audit: `op-web`

---

## 1. Overview
The `op-web` crate is a unified web server for the `op-dbus-v2` control plane. It consolidates multiple network protocols and host-management interfaces into a single Axum-based server. Its responsibilities span serving a compiled React SPA, bidirectional WebSocket communication, Server-Sent Events (SSE) stream, Model Context Protocol (MCP) handlers (Compact, Agentic, Standard), gRPC bridging, and a WireGuard-based per-user Privacy Router provisioning system. 

While highly consolidated, the codebase contains severe compilation-blocking type mismatches, missing struct fields, duplicate router implementations, and catastrophic security gaps where privileged OS operations are exposed without authentication.

---

## 2. Module Tree

```text
crates/op-web/src/
├── bin/
│   └── op-dbus.rs (Bin target: op-dbus)
├── handlers/
│   ├── mod.rs (Submodule registry)
│   ├── agents.rs
│   ├── auth_bridge.rs (MISSING from mod.rs registration)
│   ├── chat.rs
│   ├── dashboard.rs
│   ├── health.rs
│   ├── llm.rs
│   ├── logs.rs
│   ├── mail.rs
│   ├── mcp.rs
│   ├── openclaw.rs
│   ├── privacy.rs
│   ├── status.rs
│   ├── tools.rs
│   ├── users.rs
│   └── vpn.rs
├── middleware/
│   ├── mod.rs
│   └── security.rs
├── orchestrator/
│   ├── mod.rs (Submodule registry)
│   ├── anti_hallucination.rs (Rule engine)
│   ├── execution.rs
│   ├── formatting.rs
│   ├── parsing.rs
│   ├── process.rs
│   └── tools.rs
├── routes/
│   ├── mod.rs (Submodule registry)
│   ├── admin.rs
│   ├── chat.rs
│   └── llm.rs
├── email.rs (SMTP sending via lettre)
├── embedded_ui.rs (rust-embed UI compiler)
├── groups_admin.rs (Tool picker replacement UI)
├── lib.rs (Library entrypoint)
├── main.rs (Bin target: op-web-server)
├── mcp.rs (Legacy/Standard MCP router)
├── mcp_agents.rs (Cognitive Agent MCP)
├── mcp_compact.rs (Context-saving Meta-MCP)
├── mcp_discovery.rs (/.well-known discovery)
├── mcp_smart_router.rs (Header-based capability router)
├── privacy_container.rs (Incus container orchestrator)
├── privacy_network.rs (OVS bridge manager)
├── privacy_openflow.rs (OpenFlow rule engine)
├── privacy_routes.rs (WireGuard route derivation)
├── router.rs (Split-brain duplicate router)
├── server.rs (Axum engine & Rate-limiting)
├── sse.rs (SSE Event dispatch)
├── state.rs (Global AppState)
├── state_manager_client.rs (zbus state client)
├── system_prompt_loader.rs (Hardcoded prompt parser)
├── users.rs (User registry storage)
├── websocket.rs (WebSocket controller)
└── wireguard.rs (Wg configuration gen)
```

---

## 3. Entry Points

*   **Library Target (`src/lib.rs`)**: Exposes top-level configuration, embedded UI static handlers, unified orchestrator instances, and the global shared state struct `AppState`.
*   **Main Binary Target (`src/main.rs`)**: Builds the `op-web-server` executable. It initializes global trace subscribers, instantiates `AppState`, spawns the gRPC state update/event bridge, and boots the HTTP server on a configurable port.
*   **OS Daemon gRPC Target (`src/bin/op-dbus.rs`)**: Serves the gRPC schema engine on `10.200.0.2:50051`. This allows Incus containers and local plugins to interact with OVSDB and system events through a deterministic control plane.

---

## 4. Unsafe Code & Safety Violations

The crate bypasses Rust's safety guarantees by using `unsafe` blocks for `simd-json` parsing. `simd-json` requires a mutable reference to the underlying byte slice/string because it performs in-place modification (null-termination and string unescaping) of the input buffer. However, wrapping these invocations in raw, unchecked `unsafe` blocks introduces potential undefined behavior if string slices are reused, or if alignment and boundary conditions are violated.

*   **`crates/op-web/src/groups_admin.rs:44`**:
    ```rust
    unsafe { simd_json::from_str::<HashMap<String, EnabledGroups>>(&mut raw) }
    ```
    An unchecked `unsafe` block is used to parse the tool-group configuration without validating buffer safety.
*   **`crates/op-web/src/state_manager_client.rs:38`**:
    ```rust
    let query_state: QueryStateResponse = unsafe { simd_json::from_str(&mut state_json) }
    ```
    Unsafe block wraps D-Bus string payload parsing. This presents a panic or memory corruptive surface if the D-Bus interface outputs malformed or truncated string packets.
*   **`crates/op-web/src/users.rs:104`**:
    ```rust
    let data: StoredData = unsafe { simd_json::from_str(&mut raw) }?;
    ```
    Bypasses safe deserialization checks for user database files loaded directly from `/var/lib/op-dbus/`.
*   **`crates/op-web/src/orchestrator/execution.rs:41`**:
    ```rust
    unsafe { simd_json::from_str(&mut raw) }.unwrap_or(json!({}))
    ```
    Unsafe parsing of arbitrary, untrusted CLI/agent parameters.
*   **`crates/op-web/src/orchestrator/parsing.rs:24`**, **`crates/op-web/src/orchestrator/parsing.rs:69`**, **`crates/op-web/src/orchestrator/parsing.rs:93`**:
    ```rust
    unsafe { simd_json::from_str(&mut raw) }
    ```
    Multiple instances of unsafe `simd_json` string parsing used on natural language LLM outputs. LLMs can easily inject malformed escapes or unicode sequences, risking memory unsafety in the parser.

---

## 5. `unwrap()` Abuse & Panic Risks

The codebase uses `.unwrap()` and `.expect()` in critical paths, making the server prone to panics.

*   **`crates/op-web/src/state.rs:175`**:
    ```rust
    UserStore::new("/var/lib/op-dbus/privacy-users.json")
        .await
        .expect("Failed to create user store")
    ```
    Crashes the server on startup if `/var/lib/op-dbus/` is non-writable, missing, or has incorrect permissions.
*   **`crates/op-web/src/state.rs:220`**:
    ```rust
    SqliteStore::new(":memory:")
        .await
        .expect("Failed to create in-memory state store")
    ```
    Crashes the application if SQLite fails to allocate its in-memory database context.
*   **`crates/op-web/src/server.rs:125`**:
    ```rust
    let governor_conf = GovernorConfigBuilder::default()
        .per_second(rate_limit_per_sec)
        .burst_size(self.config.rate_limit.burst_size as u32)
        .finish()
        .unwrap();
    ```
    A crash risk if the rate-limit configuration has invalid parameters (e.g. `rate_limit_per_sec` is zero).
*   **`crates/op-web/src/handlers/logs.rs:124`**:
    ```rust
    let mut lines = MuxedLines::new().expect("Failed to create MuxedLines");
    ```
    If the kernel limit for `inotify` watches is reached, `MuxedLines::new()` returns an `Err`, causing the entire thread context to crash.
*   **`crates/op-web/src/embedded_ui.rs:44`**, **`crates/op-web/src/embedded_ui.rs:58`**, **`crates/op-web/src/embedded_ui.rs:86`**:
    ```rust
    .body(Body::from(content.data.into_owned())).unwrap()
    ```
    Repeated `.unwrap()` calls on Axum HTTP response builders. Any header construction failure triggers an unrecoverable panic.

---

## 6. Clone Abuse & Performance Bottlenecks

The code contains excessive cloning of heavy structures in inner loops, state accessors, and routing paths.

*   **`crates/op-web/src/groups_admin.rs:251`**:
    ```rust
    Html(GROUPS_ADMIN_HTML.to_string())
    ```
    Clones a massive static HTML template string into a new allocation on *every single request* to `/groups-admin`.
*   **`crates/op-web/src/mcp_agents.rs:334`**:
    ```rust
    arguments.as_object().map(|obj| {
        obj.iter()
            .map(|(k, v)| (k.clone(), v.clone()))
            .collect::<HashMap<String, Value>>()
    })
    ```
    Deep clones every single nested key-value pair of tool arguments on every tool execution.
*   **`crates/op-web/src/handlers/openclaw.rs:114`**:
    ```rust
    let client = Client::builder().timeout(Duration::from_secs(60)).build().unwrap();
    ```
    Instantiates a brand new `reqwest::Client` (which internally builds a new connection pool and thread context) on *every single incoming chat request*. Clients must be reused.
*   **`crates/op-web/src/handlers/privacy.rs:414`**:
    ```rust
    &provisioned_user.wg_private_key_encrypted, // This is the actual private key for now
    ```
    WireGuard private keys are kept in unencrypted plaintext throughout memory allocations and cloned frequently across state-mapping contexts.

---

## 7. Public API & Security Gaps

*   **Catastrophic Vulnerability: Unauthenticated Direct Tool Execution (`crates/op-web/src/handlers/tools.rs:37`, `48`)**:
    ```rust
    pub async fn execute_tool_handler(...)
    pub async fn execute_named_tool_handler(...)
    ```
    The endpoints `/api/tool` and `/api/tools/:name/execute` allow clients to execute *any* tool registered in the system (including `shell_exec`, `file_write`, and container orchestration commands). However:
    1.  `routes/mod.rs` applies only `ip_security_middleware` to these endpoints.
    2.  `ip_security_middleware` (in `crates/op-web/src/middleware/security.rs:94`) is purely diagnostic: it tags requests with an `AccessZone` extension but **never blocks them**.
    3.  `execute_tool_handler` and `execute_named_tool_handler` **completely ignore** the attached `AccessZone` extension and execute the requested tool with root-level context.
    4.  **Result**: An unauthenticated attacker from any IP address can execute arbitrary shell commands on the host by making a POST request to `/api/tool`.

*   **Absolute Local Path Leak (`crates/op-web/src/system_prompt_loader.rs:18-19`)**:
    ```rust
    "/home/jeremy/git/gemini-op-dbus/LLM-SYSTEM-PROMPT-COMPLETE.txt",
    "/home/jeremy/op-dbus-v2/LLM-SYSTEM-PROMPT-COMPLETE.txt",
    ```
    Hardcoded development directory paths leak local user structures into the public repository.

*   **API Key Bypass Logic Leak (`crates/op-web/src/middleware/security.rs:14`)**:
    ```rust
    const BYPASS_API_KEYS: &[&str] = &[
        "4f8c2b5d-9a1e-4b7c-8d2f-3a6b5c9e4d1f", // Primary MCP access key
        "test-key-huggingface-2024",            // Hugging Face test key
    ];
    ```
    Hardcoded security bypass keys in production codebases allow complete IP zone escalation to `TrustedMesh` (full host access) for anyone using these leaked strings.

*   **Static Mutex Memory Leak (`crates/op-web/src/handlers/privacy.rs:126`)**:
    ```rust
    static LAST_SIGNUP: tokio::sync::Mutex<Option<std::collections::HashMap<String, std::time::Instant>>> = ...
    ```
    Using an unmanaged static `HashMap` inside a mutex to track signups creates a slow memory leak over time if the server runs indefinitely under public scanner traffic.

---

## 8. Structural Defects & Compilation Failures

The crate contains structural defects and unresolved inconsistencies that prevent it from compiling.

### A. Nonexistent Method Call in `mcp_smart_router.rs`
In `crates/op-web/src/mcp_smart_router.rs:95` and `122`:
```rust
crate::mcp::mcp_sse_handler(State(crate::mcp::get_app_state()), headers).await
```
*   **The Issue**: There is no `get_app_state()` function declared in `crates/op-web/src/mcp.rs`.
*   **Result**: Immediate compilation failure.

### B. Severe Type Mismatch in `mcp_smart_router.rs`
In `crates/op-web/src/mcp_smart_router.rs:104`:
```rust
crate::mcp_compact::mcp_compact_message_handler(
    axum::extract::Json(serde_json::Value::Null)
).await
```
*   **The Issue**: `mcp_compact::mcp_compact_message_handler` expects a `simd_json` `OwnedValue` wrapper (`JsonRpcRequest`), not a `serde_json::Value`. More importantly, it requires an `Extension<Arc<AppState>>` as its first parameter:
    ```rust
    pub async fn mcp_compact_message_handler(
        Extension(state): Extension<Arc<AppState>>,
        Json(request): Json<JsonRpcRequest>,
    ) -> Response
    ```
*   **Result**: Compilation failure (incorrect number of arguments; type mismatch).

### C. Missing Field on `AppState` used by `auth_bridge.rs`
In `crates/op-web/src/handlers/auth_bridge.rs:77`, `85`, `114`, `126`:
```rust
let bridge = &state.auth_bridge;
```
*   **The Issue**: `state::AppState` has no `auth_bridge` field. The state struct is missing this field entirely.
*   **Result**: Compilation failure.

### D. Dead Code: Missing Module Registration
The file `crates/op-web/src/handlers/auth_bridge.rs` exists, but its module path is never registered in `crates/op-web/src/handlers/mod.rs`.
*   **Result**: Dead code file; router endpoints defined inside are unreachable.

### E. Split-Brain Duplications
1.  **Duplicate Web Service Routers**: `crates/op-web/src/router.rs` defines a router with `create_router(...)`, while `crates/op-web/src/routes/mod.rs` also defines `create_router(...)`.
2.  **Duplicate WebSocket Handlers**: `crates/op-web/src/websocket.rs` defines a complete WebSocket handler and message loop, while `crates/op-web/src/handlers/websocket.rs` redefines the identical logic under a different module prefix. This results in divergent maintenance paths and unexpected runtime behavior.