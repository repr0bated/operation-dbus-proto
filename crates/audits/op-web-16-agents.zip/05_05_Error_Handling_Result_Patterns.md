# op-web Error Handling & Architectural Audit

## 1. Error Handling Metrics

| Metric | Count (Approximate) | Description / Notes |
| :--- | :--- | :--- |
| **`.unwrap()`** | **26** | Mostly present in WebSocket serialization fallback, OAuth builder initialization, and utility parsing. |
| **`.expect()`** | **4** | Found in state initialization fallbacks and file-watching initialization. |
| **`.unwrap_or()`** / `_else` / `_default` | **134** | Heavy reliance on fallback-based configuration loading, environment parsing, and JSON field extraction. |
| **`?` Operator** | **61** | Predominantly utilized in core database/DBus sync flows, routes, and `Result`-yielding setup logic. |
| **`todo!()`** | **0** | Missing active code invocations (only conceptual "TODO" comments exist in metrics/logs). |
| **`unimplemented!()`** | **0** | No active macro occurrences found. |
| **`panic!()`** | **0** | No active macro occurrences found. |

---

## 2. Unwrapped Panic Points (First 5 Cites)

### Finding 1: Fallback Address Parsing Panic
* **File & Line**: `crates/op-web/src/bin/op-dbus.rs:29`
* **Code Context**:
  ```rust
  let listen =
      std::env::var("OP_DBUS_GRPC_LISTEN").unwrap_or_else(|_| "10.200.0.2:50051".to_string());
  let addr: std::net::SocketAddr = listen
      .parse()
      .unwrap_or_else(|_| "10.200.0.2:50051".parse().unwrap());
  ```
* **Critique**: If the fallback IP/port string `"10.200.0.2:50051"` fails to parse for any target environment reason (such as compilation with a restricted standard library or weird network configuration), the entire gRPC server crashes immediately during launch due to a nested `.unwrap()`.

### Finding 2: WebSocket Welcome Message Serialization Panic
* **File & Line**: `crates/op-web/src/websocket.rs:60`
* **Code Context**:
  ```rust
  let welcome = WsMessage::System {
      message: format!(
          "Connected to op-dbus server. Session: {}\nType 'help' for commands.",
          &session_id[..8]
      ),
  };
  if let Err(e) = ws_sender
      .send(Message::Text(simd_json::to_string(&welcome).unwrap()))
      .await
  ```
* **Critique**: `simd_json::to_string` is assumed to never fail because `welcome` is a structured enum. However, internal serialization failures under highly optimized SIMD instructions can happen. Panicking a connection loop thread because of serialization is an anti-pattern.

### Finding 3: WebSocket Pong Keepalive Serialization Panic
* **File & Line**: `crates/op-web/src/websocket.rs:89`
* **Code Context**:
  ```rust
  Ok(WsMessage::Ping) => {
      let pong = WsMessage::Pong;
      let _ = session_tx_clone
          .send(simd_json::to_string(&pong).unwrap())
          .await;
      continue;
  }
  ```
* **Critique**: Just as in Finding 2, forcing a thread panic on a basic ping-pong keepalive message because of structured enum serialization limits robustness.

### Finding 4: WebSocket Orchestrator Response Serialization Panic
* **File & Line**: `crates/op-web/src/websocket.rs:126`
* **Code Context**:
  ```rust
  let response = WsMessage::Response {
      success: result.success,
      message: result.message,
      tools_executed: result.tools_executed,
  };
  let _ = session_tx_clone
      .send(simd_json::to_string(&response).unwrap())
      .await;
  ```
* **Critique**: This serialization panic shuts down the connection management loop of a client session simply because a tool returned data that caused an unforeseen formatting issue.

### Finding 5: WebSocket Error Output Serialization Panic
* **File & Line**: `crates/op-web/src/websocket.rs:132`
* **Code Context**:
  ```rust
  Err(e) => {
      let error = WsMessage::Error {
          message: e.to_string(),
      };
      let _ = session_tx_clone
          .send(simd_json::to_string(&error).unwrap())
          .await;
  }
  ```
* **Critique**: If the error context itself contains invalid characters or causes serialization errors, trying to serialize the error payload will trigger a panic. This masks the underlying execution error.

---

## 3. Architectural Audit: Unsafe, Clones, and Public API Leakage

### Unsafe Block Abuse on Untrusted Inputs
* **Cites**: 
  * `crates/op-web/src/groups_admin.rs:45`
  * `crates/op-web/src/state_manager_client.rs:29`
  * `crates/op-web/src/websocket.rs:79`
  * `crates/op-web/src/handlers/websocket.rs:49`
  * `crates/op-web/src/orchestrator/execution.rs:56`
  * `crates/op-web/src/orchestrator/parsing.rs:30`
  * `crates/op-web/src/orchestrator/parsing.rs:71`
  * `crates/op-web/src/orchestrator/parsing.rs:101`
  * `crates/op-web/src/orchestrator/parsing.rs:117`
  * `crates/op-web/src/orchestrator/process.rs:281`
* **Analysis**: `simd_json::from_str` and `simd_json::from_slice` are wrapped in raw `unsafe` blocks across multiple request handlers. `simd_json` requires that input strings are mutable (which they are here, using `&mut raw`), but passing arbitrary, unvalidated raw payloads from WebSockets or HTTP headers directly into optimized SIMD parsers with `unsafe` is highly dangerous. Undefined behavior, memory alignment issues, or segfaults can be triggered by maliciously crafted JSON inputs from attackers.

### Clone Abuse
* **Cites**: 
  * `crates/op-web/src/state.rs:112` / `state.rs:113`
  * `crates/op-web/src/orchestrator/process.rs:120` / `process.rs:232`
  * `crates/op-web/src/mcp_agents.rs:198` / `mcp_agents.rs:234`
* **Analysis**: Deep copies of large structured arrays (like registered tool lists, active model definitions, and agent configs) are performed continuously. Passing `state.clone()` around rather than utilizing explicit lifetime references or `Arc` slices creates substantial allocations in hot path request loops. Massive JSON `Value` structures are recursively cloned in the formatting and parsing stages, causing garbage collection pressure on memory structures.

### Public API Leakage
* **Cites**: 
  * `crates/op-web/src/email.rs:12`: `EmailConfig` fields are entirely `pub`.
  * `crates/op-web/src/state.rs:66`: `AppState` fields are entirely `pub`, exposing database pools, gRPC connections, and configuration variables directly.
  * `crates/op-web/src/users.rs:15`: `PrivacyUser` fields are entirely `pub`, exposing encrypted private keys `wg_private_key_encrypted` and allocated IPs directly.
* **Analysis**: Exposing deep internals and raw configurations directly to foreign modules violates encapsulation. For example, any module referencing `AppState` can mutate or read the `csrf_tokens` map or directly command the raw `grpc_client` to bypass access checks. Encrypted WireGuard keys and metadata should be hidden behind clean getter/setter APIs rather than exposed via public struct fields.

---

## 4. Result vs Panic Recommendations

The system frequently utilizes panicking fallbacks (`.unwrap()`, `.expect()`) inside core infrastructure components. A web control plane must survive network failures, parser errors, and remote bridge disconnections without bringing down the system.

### Recommendations:
1. **Eliminate All Unwraps in Serialization**:
   Replace `simd_json::to_string(&val).unwrap()` with proper error mapping, falling back to a hardcoded safe static error string:
   ```rust
   // Replace this:
   let payload = simd_json::to_string(&msg).unwrap();
   
   // With this:
   let payload = simd_json::to_string(&msg).unwrap_or_else(|_| r#"{"type":"error","message":"internal serialization failure"}"#.to_string());
   ```

2. **Refactor Launch Diagnostics to Safe Results**:
   Remove `.expect()` and `.unwrap()` from `state.rs` and `op-dbus.rs` initialization steps. Bubble initialization errors up to `main` and shut down gracefully with descriptive error logs:
   ```rust
   // Replace this:
   let store = SqliteStore::new(path).await.expect("Failed to create state store");
   
   // With this:
   let store = SqliteStore::new(path).await.context("Failed to initialize Sqlite State Store")?;
   ```

3. **Migrate `unsafe simd_json` to Safe Variants**:
   Instead of using `unsafe { simd_json::from_str(&mut raw) }`, migrate to the safe API or use `serde_json` for processing untrusted client input. The security risk of memory corruption from malformed client input far outweighs the marginal SIMD parsing speedup in standard request-response cycles.