### 1. Critical Compilation Failures & Structural Type Mismatches

*   **`crates/op-web/src/handlers/auth_bridge.rs:70`**, **`78`**, **`107`**: `state.auth_bridge` is accessed, but `auth_bridge` is completely missing from the `AppState` struct defined in `crates/op-web/src/state.rs`. This results in an immediate compile-time error.
*   **`crates/op-web/src/mcp_smart_router.rs:89`**, **`99`**, **`107`**: Calls to non-existent function `crate::mcp::get_app_state()`. The module `crates/op-web/src/mcp.rs` contains no such function, causing compilation failure.
*   **`crates/op-web/src/mcp_smart_router.rs:92`**, **`102`**, **`110`**: Uses `serde_json::Value::Null` to pass into handlers, but the handlers expect `simd_json::OwnedValue` or specific structures like `JsonRpcRequest`. Furthermore, `serde_json` is not listed as a direct dependency in `crates/op-web/Cargo.toml`, violating workspace dependency hygiene and breaking the build.

---

### 2. Critical Security Vulnerabilities (Hardcoded Backdoor)

*   **`crates/op-web/src/middleware/security.rs:10`**: Administrative bypass API keys are hardcoded into the source code (`"4f8c2b5d-9a1e-4b7c-8d2f-3a6b5c9e4d1f"`, `"test-key-huggingface-2024"`). Any remote attacker presenting these keys in the `X-API-Key`, `Authorization`, or `x-op-mcp-token` headers bypasses all IP firewall restrictions and is instantly elevated to `TrustedMesh` clearance.
*   **`crates/op-web/src/middleware/security.rs:126`**: If a bypass key is shorter than 8 characters, the slicing operation `&key[..8]` will panic and crash the worker thread processing the request. While the hardcoded keys are currently longer, any future addition of a shorter key will introduce a remote denial-of-service vector.

---

### 3. Unsafe Block Violations (Undocumented `simd-json` Mutation)

*   **`crates/op-web/src/groups_admin.rs:53`**
*   **`crates/op-web/src/state_manager_client.rs:30`**
*   **`crates/op-web/src/websocket.rs:81`**
*   **`crates/op-web/src/users.rs:82`**
*   **`crates/op-web/src/handlers/websocket.rs:70`**
*   **`crates/op-web/src/orchestrator/execution.rs:55`**
*   **`crates/op-web/src/orchestrator/parsing.rs:31`**
*   **`crates/op-web/src/orchestrator/parsing.rs:68`**
*   **`crates/op-web/src/orchestrator/parsing.rs:104`**
*   **`crates/op-web/src/orchestrator/parsing.rs:115`**
*   **`crates/op-web/src/orchestrator/process.rs:207`**

The codebase is saturated with `unsafe` blocks wrapping `simd_json::from_str(&mut raw)`. There is not a single safety comment (`// SAFETY: ...`) explaining why these operations are safe. 

`simd_json::from_str` performs in-place destructive mutations of the input string slice. Reusing the modified string, holding active references to deserialized elements past the lifetime of the mutated buffer, or passing strings that do not respect `simd-json`'s strict padding requirements (which can result in out-of-bounds reads) constitutes a massive undefined behavior (UB) and memory corruption risk.

---

### 4. Panic Risks & Unwraps/Expects

*   **`crates/op-web/src/server.rs:126`**: Calling `.unwrap()` on `GovernorConfigBuilder::finish()`. If the configuration parameters (such as `requests_per_minute`) are loaded dynamically or configured incorrectly (e.g., set to `0`), this will panic on startup and terminate the server process.
*   **`crates/op-web/src/handlers/logs.rs:126`**: Calling `.expect("Failed to create MuxedLines")` inside an active async handler. Under systems with exhausted `inotify` watches or non-Linux targets where inotify is unavailable, this panics and instantly crashes the entire server process.
*   **`crates/op-web/src/state.rs:196`**: Employs `.expect("Failed to create user store")` during application startup, which will immediately terminate the application if the directory `/var/lib/op-dbus/` is read-only or unwriteable.
*   **`crates/op-web/src/websocket.rs:53`** and **`crates/op-web/src/handlers/websocket.rs:53`**: Employs `.unwrap()` on JSON string serialization. If the struct invariants are ever violated, serialization fails and panics the active connection task.
*   **`crates/op-web/src/bin/op-dbus.rs:27`**: Nested `.unwrap()` on fallback address parsing: `.unwrap_or_else(|_| "10.200.0.2:50051".parse().unwrap())`.
*   **`crates/op-web/src/handlers/openclaw.rs:89`**, **`131`**, **`207`**: `reqwest::Client::builder().build().unwrap()` is invoked inside request handlers. Any failure in network driver interfaces or system configuration will cause thread panics.

---

### 5. Tokio Reactor Thread Blocking (Sync I/O in Async Context)

*   **`crates/op-web/src/mcp_agents.rs:131`**: Invokes `save_agent_config` synchronously within async state initialization.
*   **`crates/op-web/src/mcp_agents.rs:414`**: Performs synchronous blocking read `std::fs::read(&path)` inside an async path.
*   **`crates/op-web/src/mcp_agents.rs:424`**: Performs blocking `std::fs::write` inside `save_agent_config` which is awaited across async tasks, starving the Tokio thread pool.
*   **`crates/op-web/src/mcp_agents.rs:426`**: Performs blocking `std::fs::create_dir_all` in an async context.
*   **`crates/op-web/src/system_prompt_loader.rs:37`**: Performs blocking `std::fs::read_to_string` to load system prompts on startup.

---

### 6. Performance & Clone Abuse

*   **`crates/op-web/src/groups_admin.rs:52`**: Performs `let mut raw = content.clone();` on every file load, duplicating massive JSON strings unnecessarily before parse.
*   **`crates/op-web/src/mcp.rs:330`**: Clones arguments value: `params.get("arguments").cloned()`, triggering deep allocation copies of the JSON payload.
*   **`crates/op-web/src/mcp_agents.rs:339`**: Deep clones the entire JSON arguments object `arguments` on every single incoming tool call.
*   **`crates/op-web/src/mcp_compact.rs:207`**, **`367`**: Clones `arguments` dynamically on metadata tool execution paths, adding heavy garbage collection pressure.