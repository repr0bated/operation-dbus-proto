# License Audit & Architect Code Review

## 1. License Analysis

### License Extraction
* **File**: `crates/op-web/Cargo.toml`
* **License**: `Apache-2.0` (derived via `license.workspace = true` which points to `Cargo.toml` workspace package metadata: `license = "Apache-2.0"`).

### GPL-Incompatible Dependencies
Scanning `Cargo.lock`, the following dependencies present GPL-compatibility risks:
* **`openssl` / `openssl-sys`** (Cargo.lock:833, 856): Dual-licensed under `Apache-2.0` or custom OpenSSL licenses. The older OpenSSL license contains advertising clauses that are fundamentally incompatible with the GPL (specifically GPLv2).
* **`ring`** (Cargo.lock:951): Licensed under a combination of ISC, MIT, and OpenSSL-like licenses. The cryptographic assembly derived from BoringSSL/OpenSSL contains restrictive license clauses that cause friction with strict GPLv2 compliance.
* **`aws-lc-rs` / `aws-lc-sys`** (Cargo.lock:64, 71): Links with AWS-LC. It is dual-licensed under Apache-2.0 and ISC, but incorporates OpenSSL code. Some strict copyleft compliance audits flag its cryptographic restrictions as GPL-incompatible.
* **`cozo`** (Cargo.lock:199): Licensed under `MPL-2.0` (Mozilla Public License 2.0). While MPL-2.0 is weak copyleft and permits combining with GPL software under Section 3.3, it requires strict file-level separation and specific notice provisions.

### Copyright Headers
* **Result**: **No copyright headers** exist in any of the provided source files inside `crates/op-web`. There are zero copyright assertions or SPDX identifier comments in the headers of any `.rs` files. This is a severe compliance gap for an Apache-2.0 workspace.

---

## 2. Fatal Compilation Errors & API Mismatches

The codebase suffers from multiple severe architectural inconsistencies that prevent it from compiling.

### `auth_bridge` Missing from `AppState`
* **File**: `crates/op-web/src/handlers/auth_bridge.rs:55, 63, 76, 114`
* **Finding**: The handlers attempt to access `state.auth_bridge` (e.g., `let bridge = &state.auth_bridge;`). However, `AppState` defined in `crates/op-web/src/state.rs:69` has **no such field** as `auth_bridge`. This completely breaks compilation.

### Missing `get_app_state` and Incompatible Handler Signature
* **File**: `crates/op-web/src/mcp_smart_router.rs:92, 96, 119`
* **Finding**: The code calls `crate::mcp::get_app_state()`. No such function exists in `crates/op-web/src/mcp.rs`. 
* **Finding**: It attempts to invoke `crate::mcp::mcp_sse_handler(State(...), headers)` and `crate::mcp::jsonrpc_handler(State(...), Json(...))`. However, the actual signatures of those functions in `mcp.rs:136, 128` do not accept `State` wrappers in that position (they extract `Extension<Arc<AppState>>`).

### Missing `ws_handler` in WebSocket Modules
* **File**: `crates/op-web/src/server.rs:12, 114`
* **Finding**: `server.rs` imports `crate::websocket::ws_handler` and mounts it on `/ws`. However, `crates/op-web/src/websocket.rs` only defines `websocket_handler` and `handle_socket`. The name `ws_handler` is undefined, causing a compilation failure.

---

## 3. High-Severity Security Vulnerabilities

### Arbitrary File Overwrite via Path Traversal
* **File**: `crates/op-web/src/handlers/chat.rs:427`
* **Finding**:
  ```rust
  let filepath = format!("/tmp/{}", filename);
  match tokio::fs::write(&filepath, &transcript).await { ... }
  ```
  The `filename` parameter is extracted directly from the JSON request payload (`params.get("filename")`) without any sanitization. A malicious user can provide a filename containing path traversal sequences (e.g., `../../etc/cron.d/malicious_job` or `../../etc/shadow`), allowing them to write arbitrary content to any writable file on the system.

### Privilege Escalation via Insecure Shell execution of `doas`
* **File**: `crates/op-web/src/handlers/status.rs:192`
* **Finding**:
  ```rust
  let out = tokio::process::Command::new("doas")
      .arg("dinitctl")
      .arg("list")
      .output()
      .await;
  ```
  Shelling out to `doas` (a `sudo` alternative) inside a web server context is an anti-pattern. If the server process is compromised, or if any input parameters are eventually refactored to pass user-controlled arguments, this presents a trivial privilege escalation path.

---

## 4. Unsafe Code Audit

### Unsafe deserialization with `simd_json`
* **File**: `crates/op-web/src/groups_admin.rs:44`
* **File**: `crates/op-web/src/state_manager_client.rs:30`
* **File**: `crates/op-web/src/websocket.rs:76`
* **File**: `crates/op-web/src/handlers/websocket.rs:68`
* **Finding**: `unsafe { simd_json::from_str(...) }` is used repeatedly. `simd-json` requires the input string to be mutable and have specific padded allocations. Calling `from_str` unsafely on arbitrarily sized strings can lead to Undefined Behavior (UB), memory corruption, or segmentation faults if the string's backing buffer does not meet the alignment and padding requirements of SIMD architectures.

---

## 5. Panic & Robustness Risks (`unwrap` / `expect` Abuse)

The server relies on panics for control flow during initialization and request handling instead of proper error propagation.

### `expect` Panics in Fallback Configurations
* **File**: `crates/op-web/src/state.rs:164`
* **Finding**: `.expect("Failed to create user store")` will crash the entire server at startup if `/var/lib/op-dbus/privacy-users.json` is unreadable or if parent directories cannot be created.
* **File**: `crates/op-web/src/state.rs:191`
* **Finding**: `.expect("Failed to create in-memory state store")` triggers a panic during startup if the fallback memory database allocation fails.

### Unhandled Panics in Route Setup & Requests
* **File**: `crates/op-web/src/server.rs:134`
* **Finding**: `GovernorConfigBuilder::default()...finish().unwrap()` will crash the process if the rate-limiting configuration values are structurally invalid.
* **File**: `crates/op-web/src/handlers/openclaw.rs:92, 132, 210`
* **Finding**: `Client::builder().timeout(...).build().unwrap()` will panic if the underlying TLS backend fails to initialize. This should be initialized once at startup and stored in `AppState`.
* **File**: `crates/op-web/src/handlers/websocket.rs:85, 100, 114`
* **Finding**: `simd_json::to_string(&response).unwrap()` and `simd_json::to_string(&pong).unwrap()` are called inside the WebSocket loop. If any structure cannot be serialized, the entire client connection task panics.

---

## 6. Memory Allocation & Clone Abuse

### Redundant Cloning of Huge Strings and JSON Structures
* **File**: `crates/op-web/src/groups_admin.rs:41`
* **Finding**: `let mut raw = content.clone();` clones the entire raw text of the config file before parsing it.
* **File**: `crates/op-web/src/privacy_container.rs:53`
* **Finding**: `let mut raw = content.clone();` clones the DBus state string redundantly.
* **File**: `crates/op-web/src/mcp_agents.rs:318`
* **Finding**: `obj.iter().map(|(k, v)| (k.clone(), v.clone())).collect::<HashMap<String, Value>>()` executes deep clones of every single key and value in the JSON object map on every single tool execution.
* **File**: `crates/op-web/src/state.rs:116`
* **Finding**: `chat_manager.switch_model(model.clone())` clones the model name string unnecessarily.

---

## 7. Encapsulation & Public API Leakage

### Raw Internal Lock Expositions
* **File**: `crates/op-web/src/groups_admin.rs:27, 29`
* **Finding**:
  ```rust
  pub struct GroupsConfig {
      profiles: RwLock<HashMap<String, EnabledGroups>>,
      trusted_networks: RwLock<Vec<String>>,
  }
  ```
  The fields of `GroupsConfig` are private but they expose a raw `RwLock` internally. However, in:
* **File**: `crates/op-web/src/state.rs:107`
* **Finding**: `pub agent_registry: Arc<RwLock<AgentRegistry>>,`
  Exposing an asynchronous `RwLock` directly in the public fields of `AppState` allows any external module to lock the state indefinitely, causing deadlocks or high latency across unrelated handlers.

### Public State Leaks
* **File**: `crates/op-web/src/state.rs:120, 128`
* **Finding**: `pub conversations: Arc<RwLock<HashMap<String, Vec<ChatMessage>>>>` and `pub csrf_tokens: Arc<RwLock<HashMap<String, String>>>` are leaked as public mutable fields on `AppState`. This bypasses any encapsulation rules, permitting arbitrary modification of active user sessions by any component.