# Error

```
Error code: 502 - {'error': {'message': 'status: PermissionDenied, message: "Lightning dunning decision is deny for project: projects/1028225448721", details: [], metadata: MetadataMap { headers: {"grpc-server-stats-bin": "AAA+C9wBAAAAAA", "endpoint-load-metrics-bin": "MSB7K12KAuM/OSB7K12KAtM/SVH+QElAM9c/", "content-type": "application/grpc", "grpc-accept-encoding": "identity, deflate, gzip", "content-length": "0", "date": "Tue, 26 May 2026 11:49:51 GMT", "alt-svc": "h3=\\":443\\"; ma=2592000,h3-29=\\":443\\"; ma=2592000"} }'}}
```