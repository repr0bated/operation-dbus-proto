# Error

```
Error code: 502 - {'error': {'message': 'status: PermissionDenied, message: "Lightning dunning decision is deny for project: projects/1028225448721", details: [], metadata: MetadataMap { headers: {"grpc-server-stats-bin": "AACfhMgBAAAAAA", "endpoint-load-metrics-bin": "MalieXToru8/Od2R7reiLeY/SQe6fTP5w9k/", "content-type": "application/grpc", "grpc-accept-encoding": "identity, deflate, gzip", "content-length": "0", "date": "Tue, 26 May 2026 11:49:57 GMT", "alt-svc": "h3=\\":443\\"; ma=2592000,h3-29=\\":443\\"; ma=2592000"} }'}}
```