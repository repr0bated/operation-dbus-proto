# Error

```
Error code: 502 - {'error': {'message': 'status: PermissionDenied, message: "Lightning dunning decision is deny for project: projects/1028225448721", details: [], metadata: MetadataMap { headers: {"grpc-server-stats-bin": "AAD4d+0BAAAAAA", "endpoint-load-metrics-bin": "MeOXcLmLAgNAOeOXcLmLAtM/Sf9ao67ynt8/", "content-type": "application/grpc", "grpc-accept-encoding": "identity, deflate, gzip", "content-length": "0", "date": "Tue, 26 May 2026 11:49:18 GMT", "alt-svc": "h3=\\":443\\"; ma=2592000,h3-29=\\":443\\"; ma=2592000"} }'}}
```