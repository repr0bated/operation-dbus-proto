### Integration Architecture Analysis

#### 1. Workspace Grep for `use op-agents::`
Crates within the workspace consume `op-agents` through its public routing, registry, and service layers. The primary integration patterns found in the workspace include:
*   `op-http` / `op-web` mounting the axum router:
    ```rust
    use op_agents::router::{create_router, AgentsState};
    ```
*   `op-tools` / `op-chat` orchestrating agent tasks and tool definitions:
    ```rust
    use op_agents::{create_agent, dbus_service};
    use op_agents::agent_catalog::builtin_agent_descriptors;
    ```
*   `op-mcp` exposing agent capabilities via Model Context Protocol (MCP):
    ```rust
    use op_agents::agent_catalog::builtin_agent_descriptors;
    ```

#### 2. Workspace Crate Dependencies from root `Cargo.toml`
The root `Cargo.toml` defines a workspace comprising the following member crates relevant to the agent execution boundary:
*   `crates/op-core` (Base traits, bus types, and D-Bus primitives)
*   `crates/op-http` (Shared HTTP server wrapper and routing traits)
*   `crates/op-chat` (Main LLM orchestration and chat loop)
*   `crates/op-mcp` (Model Context Protocol server)
*   `crates/op-agents` (The target crate containing registries, sandboxes, and catalog)

#### 3. Entry Points (D-Bus, HTTP, gRPC)
*   **D-Bus Entry Points**:
    *   **Single Agent Launcher**: `crates/op-agents/src/bin/dbus-agent.rs` registers a chosen agent on `org.dbusmcp.Agent.{AgentType}` at object path `/org/dbusmcp/Agent/{AgentType}` on either the Session or System bus.
    *   **Systemd Agent Manager**: `crates/op-agents/src/bin/dbus-agent-manager.rs` launches critical background orchestration and language agents at boot.
    *   **Standard Interface**: `crates/op-agents/src/dbus_service.rs` exposes `org.dbusmcp.Agent` with methods `Execute`, `RunOperation`, and metadata properties.
*   **HTTP Entry Points**:
    *   **axum Router**: `crates/op-agents/src/router.rs` defines endpoints mounted at `/api/agents`:
        *   `GET /` (List active agent instances)
        *   `POST /` (Spawn new agent instance)
        *   `GET /health` (Service health status)
        *   `GET /types` (Retrieve supported agent types)
        *   `GET /:id` (Retrieve status of a specific instance)
        *   `DELETE /:id` (Kill an agent instance)
*   **gRPC Entry Points**:
    *   No direct gRPC servers are implemented within `op-agents`. Inter-process gRPC communication is delegated to the `op-grpc-bridge` crate, which translates incoming gRPC requests into local D-Bus calls targeting `org.dbusmcp.Agent`.

---

### Critical Security Vulnerabilities

#### [VULNERABILITY] Path Traversal Bypass via Symlinks
*   **File**: `crates/op-agents/src/security/validation.rs:67`
*   **Description**: The `validate_path` function attempts to prevent directory traversal attacks by checking if the input string contains `".."`, and verifying if the parsed path starts with one of the allowed base directories (such as `/home` or `/tmp`). However, it fails to canonicalize the path *prior* to this prefix check. An attacker can create a symlink inside an allowed directory (e.g., `/tmp/malicious_symlink -> /etc`) and pass `/tmp/malicious_symlink/passwd` as the target. Since the path syntactically starts with `/tmp` and does not contain `".."`, it will bypass validation, allowing arbitrary file read/write across the entire filesystem.
*   **Remediation**: Always resolve symlinks using `std::fs::canonicalize` on the base path and target file before performing any prefix matching or security validations.

#### [VULNERABILITY] Unresolved Child Processes (Zombie Process Leak)
*   **File**: `crates/op-agents/src/agent_registry.rs:319`
*   **Description**: In `kill_agent`, the registry terminates a running agent by calling `handle.process.kill().await`. However, it does not await the exit status of the terminated process via `.wait()` or `.try_wait()`. In Unix systems, terminating a child process without reaping its exit status leaves it in the process table as a zombie (`defunct`) process. Over time, repeated spawning and killing of agents will exhaust the operating system's process ID (PID) space, causing a system-wide denial of service.
*   **Remediation**: Ensure that all calls to `kill()` are immediately followed by awaiting the process handle's completion:
    ```rust
    let _ = handle.process.kill().await;
    let _ = handle.process.wait().await;
    ```

#### [VULNERABILITY] Process Leak on Sandbox Execution Timeout
*   **File**: `crates/op-agents/src/security/sandbox.rs:252`
*   **Description**: When a sandboxed execution times out, the `SandboxExecutor` calls `child.kill().await` to terminate the rogue command. Much like the registry's process management, it neglects to reap the child process. The terminated command becomes a zombie process, leaking system resources.
*   **Remediation**: Reap the process inside the timeout handler block:
    ```rust
    let _ = child.kill().await;
    let _ = child.wait().await;
    ```

---

### Safety & Robustness Defects

#### [PANIC] Floating Point Comparison Panic in Sorting
*   **File**: `crates/op-agents/src/agents/orchestration/memory.rs:314`
*   **Description**: The semantic search implementation sorts matches by score using `scored.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap());`. If any score evaluates to `NaN` (which can occur due to corrupted database weights or unexpected float divisions), `partial_cmp` returns `None`. Calling `.unwrap()` on `None` causes an immediate runtime panic, crashing the memory agent.
*   **Remediation**: Use safe float comparison or fallback ordering:
    ```rust
    scored.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap_or(std::cmp::Ordering::Equal));
    ```

#### [PANIC] Unchecked Serialization Panic in D-Bus Response
*   **File**: `crates/op-agents/src/agents/orchestration/sequential_thinking.rs:40`
*   **Description**: The sequential thinking agent serializes its diagnostic step tree with `simd_json::to_string_pretty(&steps).unwrap()`. If the internal JSON representation encounters an edge case that fails to serialize, the D-Bus service thread will panic, crashing the entire background launcher.
*   **Remediation**: Propagate the serialization result cleanly or use a safe fallback:
    ```rust
    simd_json::to_string_pretty(&steps).map_err(|e| format!("Serialization failure: {}", e))
    ```

#### [CONCURRENCY] Global Registry Poisoning on Panic
*   **File**: `crates/op-agents/src/unified/registry.rs:44` & `crates/op-agents/src/unified/registry.rs:54`
*   **Description**: The `UnifiedAgentRegistry` manages lazy loading of agents using a standard library `std::sync::RwLock` guarded by `.unwrap()`. If an agent panics during initialization or execution while holding the lock, the lock becomes poisoned. Any subsequent read or write attempt by other threads on the global agent registry will panic, causing cascading service failures across the entire system.
*   **Remediation**: Use `tokio::sync::RwLock` which does not suffer from lock poisoning, or handle lock poisoning gracefully:
    ```rust
    let agents = self.agents.read().unwrap_or_else(|poisoned| poisoned.into_inner());
    ```

#### [UNSAFE] Raw Unsafe `simd_json` Deserialization of Untrusted Input
*   **File**: `crates/op-agents/src/dbus_service.rs:136`
*   **Description**: The D-Bus execution interface accepts arbitrary task strings from the bus and parses them using `unsafe { simd_json::from_str(&mut task_json_mut) }`. `simd_json` requires strict memory alignment and padding guarantees when using `unsafe` parsing on mutable strings. Passing malformed or unpadded payloads via D-Bus can trigger undefined behavior, memory corruption, or remote code execution.
*   **Remediation**: Use the safe, non-destructive parsing APIs of `simd-json` or `serde_json` for untrusted external inputs.

---

### Performance & Allocation Overhead

#### [CLONE] Massive String Allocation in Catalog Build
*   **File**: `crates/op-agents/src/agent_catalog.rs:60` to `crates/op-agents/src/agent_catalog.rs:135`
*   **Description**: The catalog initialization clones the `"catalog"` `agent_id` string over 60 times to construct individual boxed agent traits. Because these identifiers are static and never mutated, this introduces unnecessary heap allocations and garbage collection overhead.
*   **Remediation**: Use an `Arc<str>` or pass a static string slice `&'static str` to the agent constructors instead of owning an allocated `String` per instance.

#### [CLONE] Redundant Payload Cloning
*   **File**: `crates/op-agents/src/dbus_service.rs:135`
*   **Description**: The task execution pipeline copies the entire string representation of the incoming task: `let mut task_json_mut = task_json.to_string();`. Because `task_json` is already passed by value as an owned `String`, this allocation is completely redundant.
*   **Remediation**: Eliminate the copy and make the parameter mutable directly:
    ```rust
    async fn execute(&self, mut task_json: String) -> Result<String, zbus::fdo::Error>
    ```

---

### Public API & Encapsulation Leakage

#### [LEAK] Public Leak of Raw Process Handles
*   **File**: `crates/op-agents/src/agent_registry.rs:142`
*   **Description**: The public struct `AgentHandle` exposes the raw `tokio::process::Child` process handle as a public field (`pub process`). This allows external consumer crates to mutate, wait on, or kill the process directly. This bypasses the registry's instance status monitoring, leading to desynchronization between the process state and the registered database records.
*   **Remediation**: Keep the child process private and expose restricted, safe control methods (such as `terminate()` or `status()`) on the `AgentHandle`.

#### [LEAK] Security Boundary Duplication and Drift
*   **File**: `crates/op-agents/src/agents/base.rs:144` & `crates/op-agents/src/security/validation.rs:9`
*   **Description**: The crate defines identical security constants (`FORBIDDEN_CHARS`, `MAX_PATH_LENGTH`, `MAX_ARGS_LENGTH`) in both `crates/op-agents/src/agents/base::validation` and `crates/op-agents/src/security::validation`. Exposing two divergent validation implementations publicly invites validation drift where one agent uses a stale security subset while others use a secure profile.
*   **Remediation**: Consolidate all validation functions and constant constraints into the central `crates/op-agents/src/security/validation.rs` module and make the base validation module re-export them.