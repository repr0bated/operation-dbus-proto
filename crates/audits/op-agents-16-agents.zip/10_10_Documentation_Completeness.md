# Crate-Level Documentation Audit

## Crate-Level Docs
*   **File**: `crates/op-agents/src/lib.rs:1`
*   **Status**: Present, but extremely minimal. It contains only a brief three-line description of the crate's purpose. Given the complex security, process management, and D-Bus integration in this crate, the lack of architecture diagrams, security boundaries, and D-Bus interface specifications at the crate root is a significant documentation gap.

## Public Items Without Rustdoc
There are **over 150** public structs, fields, traits, methods, and functions lacking `///` rustdoc comments across this crate. Below is a sample of 10 highly critical public items completely missing documentation:

1.  `crates/op-agents/src/agent_catalog.rs:52` — `pub agent_type: String` (and all other fields of `AgentDescriptor`)
2.  `crates/op-agents/src/agent_registry.rs:16` — `pub struct AgentSpec` (and all of its fields, which control critical system permissions like `requires_root` and `capabilities`)
3.  `crates/op-agents/src/agent_registry.rs:55` — `pub enum RestartPolicy`
4.  `crates/op-agents/src/agent_registry.rs:116` — `pub struct AgentHandle`
5.  `crates/op-agents/src/agent_registry.rs:123` — `pub struct ProcessAgentFactory`
6.  `crates/op-agents/src/agent_registry.rs:155` — `pub struct AgentRegistry`
7.  `crates/op-agents/src/dbus_service.rs:48` — `pub struct DbusAgentService`
8.  `crates/op-agents/src/router.rs:20` — `pub struct AgentsState`
9.  `crates/op-agents/src/router.rs:64` — `pub struct AgentsServiceRouter`
10. `crates/op-agents/src/agents/base.rs:125` — `pub struct AgentContext` (and all of its fields)

## README.md Presence
*   **Status**: Absent. There is no `README.md` file in `crates/op-agents/`. A crate performing arbitrary process execution and host-level system administration via D-Bus must have a prominent `README.md` describing its threat model, deployment prerequisites, and sandboxing architecture.

---

# Technical Audit & Vulnerability Report

## 1. Critical Security Vulnerabilities

### Flawed Path Validation Leading to Directory Traversal
*   **File**: `crates/op-agents/src/agents/base.rs:182`
*   **Vulnerability**: The validation function `validate_path` checks if a user-supplied path string starts with one of the allowed directories (e.g., `/tmp`, `/home`, `/opt`):
    ```rust
    let is_allowed = allowed_dirs.iter().any(|dir| path.starts_with(dir));
    ```
    Because this function does not canonicalize the path (using `std::fs::canonicalize`) and does not forbid `..` traversal sequences (unlike the separate validation module in `crates/op-agents/src/security/validation.rs`), an attacker can easily bypass the directory restriction.
*   **Exploit**: A path such as `"/tmp/../../etc/passwd"` contains no forbidden characters from `FORBIDDEN_CHARS`, starts with `"/tmp"`, and is therefore accepted as valid. This path is subsequently passed directly to file-reading or analysis tools (such as `rg`, `tokei`, `tail`, or `sqlite3`) across almost all agents.
*   **Impact**: Arbitrary file read and data leakage of host system files (e.g., `/etc/passwd`, private keys, database files) by any agent processing a path.

### Argument Injection / Arbitrary Command Execution via Git Diff
*   **File**: `crates/op-agents/src/agents/analysis/code_reviewer.rs:64`
*   **Vulnerability**: The `git_diff` method splits the user-controlled `args` string by whitespace and passes the resulting substrings directly as arguments to `git diff`:
    ```rust
    if let Some(a) = args {
        validation::validate_args(a)?;
        for arg in a.split_whitespace() {
            cmd.arg(arg);
        }
    }
    ```
    While `validate_args` checks for forbidden characters like `;` and `&`, it does not restrict flags starting with `-`.
*   **Exploit**: An attacker can provide an argument string like `"--ext-diff=sh"`. When Git executes the diff command, it interprets this flag as an instruction to use `sh` as an external diff engine, executing it on the host system.
*   **Impact**: Full host-level arbitrary code execution, bypassing all logical sandboxing boundaries.

### Complete Absence of Sandbox Enforcement in Production Agents
*   **File**: `crates/op-agents/src/agents/analysis/code_reviewer.rs:20` (and all other files in `src/agents/`)
*   **Vulnerability**: Although `crates/op-agents/src/security/sandbox.rs` defines a robust `SandboxExecutor` with timeout, memory, and process limits, the actual agent implementations completely ignore it. They invoke `std::process::Command` directly on the host system.
*   **Impact**: No resource limits (CPU, memory, disk, processes) are enforced. A malicious or runaway task can easily trigger an Out-Of-Memory (OOM) panic, consume 100% of host CPU, or write arbitrary amounts of garbage to the disk, causing a permanent Denial of Service (DoS) of the control plane.

---

## 2. Unsafe and Soundness Issues

### Abuse of Unlabeled `unsafe` Blocks for JSON Deserialization
*   **Files**:
    *   `crates/op-agents/src/agent_registry.rs:218`
    *   `crates/op-agents/src/dbus_service.rs:136`
    *   `crates/op-agents/src/agents/orchestration/memory.rs:132`
    *   `crates/op-agents/src/agents/orchestration/memory.rs:206`
    *   `crates/op-agents/src/security/validation.rs:163`
*   **Issue**: The codebase repeatedly uses `unsafe { simd_json::from_str(...) }` without any `// SAFETY:` comments explaining why the operations are safe. `simd_json`'s in-place modification of strings can lead to undefined behavior (UB) if alignment, padding, or mutability invariants of the underlying string slices are violated. 

### Floating-Point Partial Comparison Panic
*   **File**: `crates/op-agents/src/agents/orchestration/memory.rs:363`
*   **Vulnerability**:
    ```rust
    scored.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap());
    ```
    The `unwrap()` call on the result of `partial_cmp` assumes that floats can always be ordered. If any calculated score is `NaN` (which can happen under float operations or division), `partial_cmp` returns `None`, and the thread will immediately panic.
*   **Fix**: Use `unwrap_or(std::cmp::Ordering::Equal)` instead.

### Manual JSON Construction leading to Deserialization Exploits
*   **File**: `crates/op-agents/src/agents/orchestration/memory.rs:173`
*   **Vulnerability**: The memory agent serializes database entries to disk by manually interpolating strings:
    ```rust
    let entry_json = format!(
        "\"{}\":{{\"value\":\"{}\",\"memory_type\":\"{}\",\"tags\":[{}],\"created_at\":{},\"updated_at\":{},\"access_count\":{},\"last_accessed\":{}{}}}",
        key, entry.value, memory_type_str, tags_json, entry.created_at, ...
    );
    ```
    If `key` or `entry.value` contains double quotes (`"`) or backslashes (`\`), the generated output becomes corrupt, invalid JSON. When this corrupted JSON is read from disk on startup, the unsafe `simd_json::from_str` parser can experience undefined behavior, memory corruption, or crash.
*   **Fix**: Always use structured serialization like `serde_json::to_string` or `simd_json` wrappers instead of manual string formatting.

---

## 3. Concurrency & Resource Issues (Clone & Allocation Abuse)

### Massive Heap Allocation and Clone Abuse in Catalog
*   **File**: `crates/op-agents/src/agent_catalog.rs:59-158`
*   **Issue**: Inside `builtin_agent_descriptors`, the code instantiates over 70 agents. To do so, it clones `agent_id` (a `String`) on every single line:
    ```rust
    let agent_id = "catalog".to_string();
    let agents: Vec<Box<dyn AgentTrait>> = vec![
        Box::new(BashProAgent::new(agent_id.clone())),
        Box::new(CProAgent::new(agent_id.clone())),
        // ... Repeated 70+ times
    ```
    This results in 70+ unnecessary heap allocations for a static identifier.
*   **Fix**: Change `new` to accept `&str` or use an `Arc<str>`.

### Startup Race Condition and Deadlock Hazard in Registry
*   **File**: `crates/op-agents/src/agent_registry.rs:179`
*   **Vulnerability**: In `AgentRegistry::new()`, a tokio task is spawned to perform an asynchronous write lock and register the default factory:
    ```rust
    let factories = registry.factories.clone();
    tokio::spawn(async move {
        let mut factories = factories.write().await;
        factories.push(default_factory);
    });
    ```
    Because `new()` is a synchronous function, the constructor returns *before* this background task is guaranteed to run. If an external caller immediately invokes `spawn_agent` on the returned registry, the `factories` list will be empty, causing the spawn to fail immediately.
*   **Fix**: Initialize the registry fields with the default factory directly in the constructor vector without spawning a task.

---

## 4. Public API Leakage & Code Quality

### Leaking Host-Level Process Handles in Public Structs
*   **File**: `crates/op-agents/src/agent_registry.rs:118`
*   **Issue**: `AgentHandle` exposes raw `tokio::process::Child` handles directly as `pub` fields:
    ```rust
    pub struct AgentHandle {
        pub id: String,
        pub process: tokio::process::Child,
        pub spec: AgentSpec,
    }
    ```
    This leaks the implementation detail that agents are run as local OS subprocesses. If the backend is refactored to run agents within microVMs or containers, this public API breaks. Furthermore, any external consumer can mutate, wait on, or kill this process handle without the registry's knowledge, desynchronizing the registry's status tracking.

### Compilation Failure in Unified Agent Trait
*   **File**: `crates/op-agents/src/unified/agent_trait.rs:75` (and line 92)
*   **Issue**: The `AgentRequest` and `AgentResponse` structs use `Value` as a type (e.g., `pub args: Value`). However, `Value` is never imported or aliased in this file; only `simd_json::OwnedValue` is imported on line 10. This causes a compilation error out-of-the-box.
*   **Fix**: Add `use simd_json::OwnedValue as Value;` at the top of the file.