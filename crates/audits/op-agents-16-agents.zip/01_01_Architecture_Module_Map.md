# Overview

The `op-agents` crate provides a catalog of domain-specific AI assistant agents, a dynamic agent registry, and a D-Bus service wrapper that exposes these agents to the control plane. 

Architecturally, the crate is undergoing an active transition. It contains two parallel agent architectures:
1. **The Classic Architecture** (`src/agents/`): Hardcoded agents implementing the `AgentTrait` (defined in `src/agents/base.rs`), with prompts and specifications managed externally or hardcoded in boilerplate templates.
2. **The Unified Architecture** (`src/unified/`): A cleaner design that merges prompts directly into Rust structs using the `UnifiedAgent` trait, separating them into `ExecutionAgent` (sandboxed), `PersonaAgent` (LLM-only), and `OrchestrationAgent` (work-flow coordinators).

---

# Module Tree

The following tree represents the physical file structure and internal module hierarchy.

```text
crates/op-agents/src/
├── lib.rs (Library Root)
├── agent_catalog.rs
├── agent_registry.rs
├── dbus_service.rs
├── router.rs
├── agents/ (Classic Agents Directory)
│   ├── base.rs (Classic AgentTrait)
│   ├── mod.rs
│   ├── aiml/
│   │   ├── ai_engineer.rs
│   │   ├── data_engineer.rs
│   │   ├── data_scientist.rs
│   │   ├── ml_engineer.rs
│   │   ├── mlops_engineer.rs
│   │   ├── prompt_engineer.rs
│   │   └── mod.rs
│   ├── analysis/
│   │   ├── code_reviewer.rs
│   │   ├── debugger.rs
│   │   ├── performance.rs
│   │   ├── security_auditor.rs
│   │   └── mod.rs
│   ├── architecture/
│   │   ├── backend_architect.rs
│   │   ├── frontend_developer.rs
│   │   ├── graphql_architect.rs
│   │   └── mod.rs
│   ├── business/
│   │   ├── business_analyst.rs
│   │   ├── customer_support.rs
│   │   ├── hr_pro.rs
│   │   ├── legal_advisor.rs
│   │   ├── payment_integration.rs
│   │   ├── sales_automator.rs
│   │   └── mod.rs
│   ├── content/
│   │   ├── api_documenter.rs
│   │   ├── docs_architect.rs
│   │   ├── mermaid_expert.rs
│   │   ├── tutorial_engineer.rs
│   │   └── mod.rs
│   ├── database/
│   │   ├── database_architect.rs
│   │   ├── database_optimizer.rs
│   │   ├── sql_pro.rs
│   │   └── mod.rs
│   ├── infrastructure/
│   │   ├── cloud.rs
│   │   ├── deployment.rs
│   │   ├── kubernetes.rs
│   │   ├── network.rs
│   │   ├── terraform.rs
│   │   └── mod.rs
│   ├── language/
│   │   ├── bash_pro.rs
│   │   ├── c_pro.rs
│   │   ├── cpp_pro.rs
│   │   ├── csharp_pro.rs
│   │   ├── elixir_pro.rs
│   │   ├── golang_pro.rs
│   │   ├── java_pro.rs
│   │   ├── javascript_pro.rs
│   │   ├── julia_pro.rs
│   │   ├── php_pro.rs
│   │   ├── python_pro.rs
│   │   ├── ruby_pro.rs
│   │   ├── rust_pro.rs
│   │   ├── scala_pro.rs
│   │   ├── typescript_pro.rs
│   │   └── mod.rs
│   ├── mobile/
│   │   ├── flutter_expert.rs
│   │   ├── ios_developer.rs
│   │   ├── mobile_developer.rs
│   │   └── mod.rs
│   ├── operations/
│   │   ├── devops_troubleshooter.rs
│   │   ├── incident_responder.rs
│   │   ├── test_automator.rs
│   │   └── mod.rs
│   ├── orchestration/
│   │   ├── context_manager.rs
│   │   ├── dx_optimizer.rs
│   │   ├── mem0_wrapper.rs
│   │   ├── memory.rs (Cognitive memory storage)
│   │   ├── sequential_thinking.rs
│   │   ├── tdd_orchestrator.rs
│   │   └── mod.rs
│   ├── security/
│   │   ├── backend_security_coder.rs
│   │   ├── frontend_security_coder.rs
│   │   ├── mobile_security_coder.rs
│   │   └── mod.rs
│   ├── seo/
│   │   ├── content_marketer.rs
│   │   ├── search_specialist.rs
│   │   ├── seo_content_writer.rs
│   │   ├── seo_keyword_strategist.rs
│   │   ├── seo_meta_optimizer.rs
│   │   └── mod.rs
│   ├── specialty/
│   │   ├── arm_cortex_expert.rs
│   │   ├── snowball_developer.rs
│   │   ├── error_detective.rs
│   │   ├── hybrid_cloud_architect.rs
│   │   ├── legacy_modernizer.rs
│   │   ├── observability_engineer.rs
│   │   ├── quant_analyst.rs
│   │   ├── ui_ux_designer.rs
│   │   ├── unity_developer.rs
│   │   └── mod.rs
│   ├── system/
│   │   └── mod.rs (Dangling module declaration)
│   └── webframeworks/
│       ├── django_pro.rs
│       ├── fastapi_pro.rs
│       ├── temporal_python_pro.rs
│       └── mod.rs
├── security/ (Security & Sandboxing)
│   ├── mod.rs
│   ├── profiles.rs
│   ├── sandbox.rs
│   └── validation.rs
├── generator/ (Dangling directory; parsing & templates)
│   ├── mod.rs
│   ├── md_parser.rs
│   └── template.rs
└── unified/ (Dangling directory; Unified Agent Pattern)
    ├── mod.rs
    ├── agent_trait.rs
    ├── prompts.rs
    ├── registry.rs
    ├── execution/
    │   ├── base.rs
    │   ├── golang.rs
    │   ├── javascript.rs
    │   ├── mod.rs
    │   ├── python.rs
    │   ├── rust.rs
    │   └── shell.rs
    ├── orchestration/
    │   ├── base.rs
    │   ├── code_review_orchestrator.rs
    │   ├── tdd_orchestrator.rs
    │   └── mod.rs
    └── persona/
        ├── architecture_experts.rs
        ├── base.rs
        ├── framework_experts.rs
        ├── operations_experts.rs
        └── mod.rs
```

---

# Entry Points

## Library Target
* **`crates/op-agents/src/lib.rs`**: Main library entry point. Declares `agent_catalog`, `agent_registry`, `agents`, `dbus_service`, `router`, and `security` as public modules. It re-exports key catalog, status, and trait structures, and defines the `create_agent` factory.

## Binary Targets
* **`crates/op-agents/src/bin/dbus-agent.rs`**: Universal launcher executable. Initializes tracing, parses command line flags (such as `--system` and `--list`), instantiates a target agent from the catalog, and hosts it as a dedicated D-Bus service on either the System or Session bus.
* **`crates/op-agents/src/bin/dbus-agent-manager.rs`**: Daemon binary intended to run under systemd. Automatically boots and monitors a prioritized set of critical orchestration, language, and ops agents.

---

# Notes & Architectural Audit

## 1. Unsafe Usage of `simd-json` Parsing
`simd-json` requires mutable access to input buffers to perform fast, in-place string manipulation (such as inserting null-terminators). However, multiple locations wrap this deserialization in raw `unsafe` blocks without ensuring that the underlying buffer operations are memory-safe, or validate constraints before mutation.

* **`crates/op-agents/src/agent_registry.rs:263`**:
  ```rust
  let specs: Vec<AgentSpec> = unsafe { simd_json::from_str(&mut content) }
  ```
* **`crates/op-agents/src/dbus_service.rs:135`**:
  ```rust
  let task: AgentTask = unsafe { simd_json::from_str(&mut task_json_mut) }
  ```
* **`crates/op-agents/src/security/validation.rs:152`**:
  ```rust
  unsafe { simd_json::from_str(&mut json_mut) ... }
  ```
* **`crates/op-agents/src/agents/orchestration/memory.rs:113`**:
  ```rust
  let value: simd_json::OwnedValue = unsafe { simd_json::from_str(&mut content_mut).unwrap_or_default() };
  ```
* **`crates/op-agents/src/agents/orchestration/memory.rs:182`**:
  ```rust
  let old_cache: HashMap<String, String> = unsafe { simd_json::from_str(&mut content_mut).unwrap_or_default() };
  ```

**Risk**: If any malformed JSON payload bypasses validation or contains invalid UTF-8 sequences, passing it to `simd_json`'s unsafe parsing can trigger undefined behavior, memory corruption, or process crashes.

## 2. Unchecked `unwrap()` on Poisoned Locks & Floats
* **`crates/op-agents/src/unified/registry.rs:34`** and **`crates/op-agents/src/unified/registry.rs:43`**:
  ```rust
  let agents = self.agents.read().unwrap();
  let mut agents = self.agents.write().unwrap();
  ```
  **Risk**: Calling `.unwrap()` directly on `RwLock` read/write acquisitions introduces panic propagation. If any thread panics while holding the lock, the lock gets poisoned, causing all subsequent threads to panic and taking down the entire `dbus-agent-manager` process.
* **`crates/op-agents/src/agents/orchestration/memory.rs:328`**:
  ```rust
  scored.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap());
  ```
  **Risk**: Float-based comparisons can yield `None` if NaN values leak into the scoring vector. This `.unwrap()` will panic immediately, triggering a denial-of-service vector in the cognitive memory subsystem.

## 3. Excessive `clone()` and Redundant Allocations
* **`crates/op-agents/src/agent_catalog.rs:51-125`**:
  ```rust
  Box::new(BashProAgent::new(agent_id.clone())),
  // Repeat ~70 times
  ```
  **Risk**: Instantiating all ~70 descriptors requires copying the same `agent_id` string on every single element. When descriptors are queried frequently (such as through HTTP endpoints or CLI discovery), this causes intense heap allocation thrashing.
* **`crates/op-agents/src/dbus_service.rs:134`**:
  ```rust
  let mut task_json_mut = task_json.to_string();
  ```
  **Risk**: Converts an already owned `task_json: String` into *another* owned `String` via `to_string()`, doubling memory allocation overhead for no architectural reason.

## 4. Public API Leakage & Encapsulation Violations
* **`crates/op-agents/src/unified/execution/base.rs:16-25`**:
  ```rust
  pub struct ExecutionAgent {
      pub id: String,
      pub name: String,
      pub description: String,
      pub language: String,
      pub system_prompt: String,
      pub knowledge: String,
      pub security_profile: SecurityProfile,
      pub operations: Vec<String>,
  }
  ```
  **Risk**: Every field of the unified base executor is fully public. Any external consumer can mutate the `security_profile` or inject unauthorized commands into `allowed_commands` at runtime, completely bypassing the sandbox execution checks.
* **`crates/op-agents/src/unified/persona/base.rs:12-21`**: All fields of `PersonaAgent` are exposed as `pub`.
* **`crates/op-agents/src/unified/orchestration/base.rs:24-31`**: All fields of `OrchestrationAgent` are exposed as `pub`.
* **`crates/op-agents/src/agents/base.rs:114-123`**: All fields of `AgentContext` are public.

## 5. Dangling Code and Dead Modules
* **`crates/op-agents/src/generator/`** and **`crates/op-agents/src/unified/`**:
  Both directories contain significant architectural logic but are completely omitted from the module declarations in `src/lib.rs`. They are unreachable by library consumers, resulting in large amounts of compiled dead-code unless executed directly via non-standard build pipelines.