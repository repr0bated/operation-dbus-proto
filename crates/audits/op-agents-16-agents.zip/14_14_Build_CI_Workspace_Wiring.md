### 1. Critical Security Vulnerabilities

#### 1.1 Path Traversal and Directory Escape in Base Validation
* **File:** `crates/op-agents/src/agents/base.rs:232`
* **Vulnerability:** The `validation::validate_path` function used by almost all legacy agents (such as `CodeReviewerAgent`, `DebuggerAgent`, `ApiDocumenterAgent`, etc.) fails to detect path traversal attempts (e.g., using `..`) and contains a broken prefix validation logic.
* **Impact:** 
  1. **No traversal check:** Since `FORBIDDEN_CHARS` does not contain `.`, any path like `/tmp/../etc/passwd` is accepted.
  2. **Broken prefix checking:** `path.starts_with(dir)` is a raw string comparison. If `/tmp` is allowed, `/tmp_compromised` will also be allowed because `"/tmp_compromised".starts_with("/tmp")` returns `true`.
  3. Combined, an attacker can pass `/tmp/../../../etc/passwd` to bypass the directory restriction entirely and read/write any file on the system that the agent has permissions to access.

#### 1.2 Dead Sandboxing Code causing Host Shell Escape
* **File:** `crates/op-agents/src/agents/base.rs:163`
* **Vulnerability:** Although a secure `SandboxExecutor` is defined in `crates/op-agents/src/security/sandbox.rs`, the `AgentContext` and `SandboxExecutor` are never integrated into any active agent implementation.
* **Impact:** Every single domain agent (e.g., `CodeReviewerAgent`, `DebuggerAgent`, `PerformanceEngineerAgent`, `SecurityAuditorAgent`, `DatabaseArchitectAgent`, `SqlProAgent`, and all language-pro agents) executes commands by spawning `std::process::Command` directly on the host machine. There are no resource limits, no namespaces, no containerization, and no timeouts enforced, completely defeating the purpose of the security module.

#### 1.3 Insecure Hardcoded Temporary File and Code Injection
* **File:** `crates/op-agents/src/unified/execution/python.rs:36`
* **Vulnerability:** The Python executor writes code to execute to a hardcoded path: `let temp_file = "/tmp/python_exec.py";`.
* **Impact:** 
  1. **Race Conditions:** Concurrent requests to the Python execution agent will overwrite this single file, leading to execution corruption.
  2. **Symlink Attacks / Privilege Escalation:** Any local unprivileged user can pre-create `/tmp/python_exec.py` as a symlink pointing to a sensitive file (e.g., `/home/user/.ssh/authorized_keys`), causing the agent to overwrite it when executing Python code.

#### 1.4 Unchecked Argument Injection in Shell Executor
* **File:** `crates/op-agents/src/unified/execution/shell.rs:75`
* **Vulnerability:** The `ShellExecutor` validates whether the base binary (e.g., `cat`) is whitelisted, but it does *not* validate the arguments passed to that binary.
* **Impact:** An attacker can request the operation `exec` with the command `cat /etc/passwd`. Because `cat` is whitelisted, the agent executes it, completely bypassing the file-system boundaries of `allowed_read_paths`.

---

### 2. Architectural & Performance Bottlenecks

#### 2.1 Astronomical Allocation & Clone Abuse in Catalog Initialization
* **File:** `crates/op-agents/src/agent_catalog.rs:71`
* **Defect:** `builtin_agent_descriptors()` instantiates over 70 complex agent structures (allocating dozens of strings, `Box` pointers, and cloning `agent_id` 70 times) solely to extract their `name`, `description`, and `operations`, and then immediately drops them.
* **Impact:** Calling the catalog endpoint results in massive heap thrashing, garbage collection pressure, and CPU overhead. This metadata should be statically defined or lazily loaded via zero-cost traits without requiring full struct instantiations.

#### 2.2 Redundant Round-Trip JSON Serialization
* **File:** `crates/op-agents/src/dbus_service.rs:188`
* **Defect:** The `run_operation` method serializes an `AgentTask` to a JSON String only to immediately pass it to `self.execute`, which deserializes it back into an `AgentTask` using `simd_json`.
* **Impact:** Incurring double-serialization overhead for every single direct operation call over D-Bus.

#### 2.3 Broken Multi-Threaded Startup Race Condition
* **File:** `crates/op-agents/src/agent_registry.rs:199`
* **Defect:** In `AgentRegistry::new()`, the default `ProcessAgentFactory` is pushed to the factories list inside a spawned tokio task:
  ```rust
  tokio::spawn(async move {
      let mut factories = factories.write().await;
      factories.push(default_factory);
  });
  ```
* **Impact:** Since `new()` is synchronous but the push is asynchronous, there is a race condition. If an agent spawn request arrives immediately after registry creation, it will fail because the factories list is empty.

#### 2.4 Time-of-Check to Time-of-Use (TOCTOU) Race in Agent Spawning
* **File:** `crates/op-agents/src/agent_registry.rs:305`
* **Defect:** The check for maximum instances is performed under a read lock:
  ```rust
  let instances = self.instances.read().await;
  let current_count = ...
  drop(instances);
  ```
  The lock is dropped before the handle and instance records are created under a write lock.
* **Impact:** Under high concurrency, multiple requests can pass the limit check simultaneously, spawning more agent processes than allowed by `max_instances`.

---

### 3. Safety & Resource Leaks

#### 3.1 Orphaned Process Leaks on Timeout
* **File:** `crates/op-agents/src/unified/execution/base.rs:69`
* **Defect:** The `execute_command` function uses `tokio::time::timeout` on `cmd.output()`.
* **Impact:** When the timeout expires, the future is cancelled, but the underlying child process spawned by `tokio::process::Command` is *not* terminated. The process continues executing in the background, leaking memory, CPU, and file descriptors until it eventually becomes a zombie process.

#### 3.2 Unsafe `simd_json` Usage Without Safety Justification
* **File:** `crates/op-agents/src/agent_registry.rs:254`
* **File:** `crates/op-agents/src/dbus_service.rs:163`
* **File:** `crates/op-agents/src/generator/template.rs:417`
* **Defect:** Multiple occurrences of `unsafe { simd_json::from_str(...) }` are present throughout the codebase without any `// SAFETY:` comments or verification invariants.
* **Impact:** Violates Rust safety guidelines. If input buffers are modified concurrently or contain invalid data in ways `simd_json` does not expect, it can lead to undefined behavior.

#### 3.3 Redundant Nested `RwLock` Wrapping (Double-Locking)
* **File:** `crates/op-agents/src/router.rs:20`
* **Defect:** `AgentsState` wraps `AgentRegistry` in an `Arc<RwLock<AgentRegistry>>`. However, `AgentRegistry` internally already wraps all of its fields (`specs`, `instances`, `factories`, `handles`) in `Arc<RwLock<...>>`.
* **Impact:** Extreme lock contention, degraded performance, and risk of deadlocks due to nested lock acquisitions across thread boundaries.

#### 3.4 Unusable Global Registry Modifiability
* **File:** `crates/op-agents/src/unified/registry.rs:136`
* **Defect:** The `GLOBAL_REGISTRY` is exposed as a static `Lazy<UnifiedAgentRegistry>`:
  ```rust
  pub static GLOBAL_REGISTRY: Lazy<UnifiedAgentRegistry> = Lazy::new(UnifiedAgentRegistry::new);
  ```
  However, `register(&mut self, ...)` requires a mutable reference.
* **Impact:** It is impossible to register any custom agents to the global registry at runtime because the static reference cannot be mutably borrowed, rendering the extensibility of the registry pattern broken.