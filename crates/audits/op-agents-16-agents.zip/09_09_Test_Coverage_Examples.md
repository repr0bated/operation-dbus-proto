# Test Suite Audit

## 1. Test Functions Summary
* **Total Test Functions Found:** 26
* **Integration Tests in `tests/`:** 0 (All tests are defined as unit tests within `src/` modules)

## 2. Representative Tests
* **`crates/op-agents/src/dbus_service.rs:444`** (`test_to_pascal_case`) - Validates the conversion helper that translates kebab-case agent identifiers into PascalCase for standard D-Bus interface registration.
* **`crates/op-agents/src/lib.rs:235`** (`test_create_agent`) - Validates the unified factory mechanism (`create_agent`) used to resolve and instantiate concrete `AgentTrait` boxed objects dynamically.
* **`crates/op-agents/src/security/sandbox.rs:301`** (`test_sandbox_allowed_command`) - Asserts that the sandboxed command executor successfully validates and runs commands matching the security profile whitelist.

---

# Ruthless Systems Architect Audit

### 1. `unsafe` Block Audits

* **`crates/op-agents/src/agent_registry.rs:252`**
  ```rust
  let specs: Vec<AgentSpec> = unsafe { simd_json::from_str(&mut content) }
  ```
  * **Issue:** Demands mutable borrowing of `content` and uses `unsafe` directly on unvalidated input. If `content` comes from an untrusted local config file, any potential bug in `simd-json`'s string-parsing could lead to memory corruption. 
  * **Remedy:** Isolate the unsafe JSON parsing inside a well-tested internal helper or fallback to the safe `serde_json` parser for configuration file loads, as performance is not critical during initial startup.

* **`crates/op-agents/src/dbus_service.rs:133`**
  ```rust
  let task: AgentTask = unsafe { simd_json::from_str(&mut task_json_mut) }
  ```
  * **Critical Risk:** This deserializes task JSON received *directly* from D-Bus IPC method calls (`org.dbusmcp.Agent.Execute`). D-Bus methods can be called by other processes (local or sandboxed users). Passing unvalidated IPC payloads straight to `unsafe simd_json::from_str` is a serious security risk that could allow local privilege escalation or remote execution inside the agent manager.
  * **Remedy:** Replace this with a safe deserialization boundary. Always use safe parsers like `serde_json::from_str` or `simd_json::serde::from_str` (if safe alternatives exist in the selected workspace profile) on untrusted boundary entries.

* **`crates/op-agents/src/security/validation.rs:172`**
  ```rust
  unsafe { simd_json::from_str(&mut json_mut) }
  ```
  * **Issue:** The validation module itself uses an `unsafe` JSON parser to perform *input validation*. If the validation layer contains memory safety hazards, the entire security sandbox can be bypassed.
  * **Remedy:** Use a safe JSON parser to ensure the validation code is robust.

---

### 2. `unwrap` & Panic Hazards

* **`crates/op-agents/src/agents/orchestration/memory.rs:319`**
  ```rust
  scored.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap());
  ```
  * **Critical Panic Hazard:** Compares floats (`f32` scores) and calls `.unwrap()`. If any computed score is `NaN` (due to float math errors or missing values), the comparator returns `None`, causing `.unwrap()` to panic. This will crash the entire persistent memory agent process.
  * **Remedy:** Use `partial_cmp().unwrap_or(std::cmp::Ordering::Equal)` or filter out `NaN` elements prior to sorting.

* **`crates/op-agents/src/security/validation.rs:200`**
  ```rust
  name.chars().find(|c| !c.is_alphanumeric() && *c != '_').unwrap()
  ```
  * **Issue:** Panics if the input validation logic is slightly modified or incorrectly used, as it assumes a forbidden character *must* exist because of the preceding outer check.
  * **Remedy:** Safely handle the pattern match or use `.unwrap_or('_')` to prevent any panics.

---

### 3. Allocation and Clone Abuse

* **`crates/op-agents/src/agent_catalog.rs:51` & `lib.rs:50-131`**
  ```rust
  let agent_id = "catalog".to_string();
  // ...
  Box::new(BashProAgent::new(agent_id.clone())),
  Box::new(CProAgent::new(agent_id.clone())),
  // Repeat ~75 times
  ```
  * **Performance Issue:** Allocation hot-path during registry construction. Clones the `agent_id` string ~75 times. Since `agent_id` is constant throughout catalog construction, this is completely redundant.
  * **Remedy:** Change the constructors of all concrete agents to accept `Arc<str>` or `&str`, or structure the catalog to avoid cloning owned strings for every registered type.

* **`crates/op-agents/src/dbus_service.rs:128`**
  ```rust
  let mut task_json_mut = task_json.to_string();
  ```
  * **Issue:** `task_json` is already passed by value as an owned `String`. Calling `.to_string()` duplicates the entire allocation for no reason, simply because `simd_json::from_str` needs a mutable buffer.
  * **Remedy:** Remove the `.to_string()` clone and make the parameter mutable: `async fn execute(&self, mut task_json: String)`.

---

### 4. Public API Leakage

* **`crates/op-agents/src/agent_registry.rs:114`**
  ```rust
  pub struct AgentHandle {
      pub id: String,
      pub process: tokio::process::Child,
      pub spec: AgentSpec,
  }
  ```
  * **Design Issue:** Leaks the raw `tokio::process::Child` handle in the public API. Consumers can kill, wait on, or manipulate the process handle out of sync with the `AgentRegistry`'s internal tracking maps, leading to broken states, orphaned processes, and race conditions.
  * **Remedy:** Make `process` a private field. Expose specific safe, coordinated methods on `AgentHandle` (e.g., `id()`, `kill()`, `wait()`).

* **`crates/op-agents/src/router.rs:21`**
  ```rust
  pub struct AgentsState {
      pub registry: Arc<RwLock<AgentRegistry>>,
  }
  ```
  * **Design Issue:** Exposes the raw, lockable `AgentRegistry` field directly. This allows any endpoint or consumer holding the state to bypass the router handlers and mutate specifications, spawn processes, or kill agents without proper audit logs.
  * **Remedy:** Make `registry` private and wrap the required operations in clean methods on `AgentsState`.

* **`crates/op-agents/src/unified/execution/base.rs:15` & `orchestration/base.rs:25`**
  * **Issue:** Structural encapsulation is completely broken in the new `unified` agent model. Structs like `ExecutionAgent` and `OrchestrationAgent` define all fields as `pub`, exposing internal configuration states directly to modifications.
  * **Remedy:** Implement private fields and expose accessor methods. Use builder patterns to enforce immutable state boundaries after construction.