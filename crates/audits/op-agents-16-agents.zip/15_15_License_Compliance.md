### 1. License & Dependency Audit

#### License Extraction
* **Crate License**: `Apache-2.0` (Inherited from workspace in `Cargo.toml:34` via `crates/op-agents/Cargo.toml:6`).

#### GPL-Incompatible Dependencies
* **Scan Results (`Cargo.lock`)**: No GPL-only (GPL-2.0/GPL-3.0) or AGPL dependencies are declared in the workspace. 
* **Copyleft Warning**: `cozo` (version `0.7.6`) is compiled with `storage-sled`. `cozo` is licensed under `MPL-2.0` (Mozilla Public License 2.0). While MPL-2.0 is weakly copyleft and compatible with Apache-2.0 projects when kept in separate files, any modifications to the Cozo library source code itself must be disclosed under the MPL-2.0.

#### Copyright Headers Status
* **Compliance Gap**: Zero files in `crates/op-agents` contain copyright or SPDX license identifier headers (e.g., `// SPDX-License-Identifier: Apache-2.0` or `// Copyright (c) 2025 OP-DBUS Contributors`).

---

### 2. Unsafe Code Audit

#### `simd_json::from_str` Raw Unsafe Abuse
The codebase repeatedly invokes `simd_json::from_str` inside `unsafe` blocks with mutable string references without asserting alignment, non-null status, or verifying the initialization state of the source string.
* **`crates/op-agents/src/agent_registry.rs:346`**:
  ```rust
  let specs: Vec<AgentSpec> = unsafe { simd_json::from_str(&mut content) }
  ```
* **`crates/op-agents/src/dbus_service.rs:135`**:
  ```rust
  let task: AgentTask = unsafe { simd_json::from_str(&mut task_json_mut) }
  ```
* **`crates/op-agents/src/agents/orchestration/memory.rs:163`**:
  ```rust
  let value: simd_json::OwnedValue = unsafe { simd_json::from_str(&mut content_mut).unwrap_or_default() };
  ```
* **`crates/op-agents/src/agents/orchestration/memory.rs:242`**:
  ```rust
  let old_cache: HashMap<String, String> = unsafe { simd_json::from_str(&mut content_mut).unwrap_or_default() };
  ```
* **`crates/op-agents/src/security/validation.rs:159`**:
  ```rust
  unsafe { simd_json::from_str(&mut json_mut) }
  ```
  * **Critique**: `simd_json` requires the input buffer to have specific padding (usually `simd_json::SIMDJSON_PADDING` bytes) and alignment. Simply calling `to_string()` on a `String` and casting to `unsafe { simd_json::from_str(&mut str) }` can cause undefined behavior if the compiler optimizes the allocation's tail padding away. 
  * **Remediation**: Use `simd_json::serde::from_str` or `simd_json::from_slice` which handle boundary conditions safely, or use `simd_json::to_padded_bin` to guarantee the required structural padding.

---

### 3. Critical Security & Sandboxing Flaws

#### Critical Path Traversal Vulnerability (Bypassable Sanitizer)
* **`crates/op-agents/src/agents/base.rs:165`**:
  ```rust
  pub fn validate_path(path: &str, allowed_dirs: &[&str]) -> Result<String, String> {
      ...
      let is_allowed = allowed_dirs.iter().any(|dir| path.starts_with(dir));
      if !is_allowed { ... }
      Ok(path.to_string())
  }
  ```
  * **Critique**: This is a critical security vulnerability. It validates the path using a raw string prefix check (`path.starts_with(dir)`) without checking for path traversal components (`..`) or resolving/canonicalizing symlinks.
  * **Exploit**: An attacker can supply `"/tmp/../../etc/passwd"`. Because `"/tmp/../../etc/passwd".starts_with("/tmp")` evaluates to `true`, the path is accepted. When passed to a downstream command (like `git`, `tail`, or `clang`), the OS resolves the path to `/etc/passwd`, allowing complete sandbox escape.
  * **Sandbox Bypass Cascade**: 23 different production agents import this insecure validation module (e.g., `CodeReviewerAgent`, `SqlProAgent`, `BashProAgent`, `RustProAgent`) instead of the safer sanitizer located in `crates/op-agents/src/security/validation.rs:104`.

#### Argument Injection in Git Commands
* **`crates/op-agents/src/agents/analysis/code_reviewer.rs:65-67`**:
  ```rust
  if let Some(a) = args {
      validation::validate_args(a)?;
      for arg in a.split_whitespace() {
          cmd.arg(arg);
      }
  }
  ```
  * **Critique**: `args` is validated using `validate_args` (which only checks for a basic blacklist of shell characters like `;` and `$`), split by whitespace, and passed directly to `git diff`.
  * **Exploit**: A user can pass `args = "--no-index /etc/passwd /dev/null"`. This changes the behavior of `git diff` to act as an arbitrary file reader, completely bypassing directory restrictions and the git repository boundary.
  * **Remediation**: Avoid splitting unvalidated strings into command arguments. Arguments must be validated against strict whitelists of flags or matched against safe schemas.

---

### 4. Unwrap & Panic Analysis

#### Unwrapped Serializer Panics
* **`crates/op-agents/src/agents/orchestration/sequential_thinking.rs:43`**:
  ```rust
  Ok(simd_json::to_string_pretty(&steps).unwrap())
  ```
  * **Critique**: `to_string_pretty` is unwrapped. If serialization fails (e.g., resource exhaustion or structural nesting depth limits exceeded), the entire agent process panics and dies, causing D-Bus service termination.
  * **Remediation**: Bubble up the error: `simd_json::to_string_pretty(&steps).map_err(|e| e.to_string())`.

#### Unwrapped Option Search
* **`crates/op-agents/src/security/validation.rs:223`**:
  ```rust
  name.chars().find(|c| !c.is_alphanumeric() && *c != '_').unwrap()
  ```
  * **Critique**: Assumes that `find` will always succeed because the prior `if !name.chars().all(...)` check failed. If there is an encoding or multi-byte character boundary edge case in `all` vs `find`, this will panic.
  * **Remediation**: Replace with `.ok_or(ValidationError::ForbiddenCharacter(...))` or a safe fallback.

---

### 5. Clone Abuse & Performance Bottlenecks

#### O(N²) String Cloning on Startup
* **`crates/op-agents/src/agent_catalog.rs:56-125`**:
  ```rust
  Box::new(BashProAgent::new(agent_id.clone())),
  Box::new(CProAgent::new(agent_id.clone())),
  ... [70+ lines of identical clones]
  ```
  * **Critique**: To construct the list of built-in agent descriptors, this function allocates and instantiates **every single stateful agent** inside a `Vec<Box<dyn AgentTrait>>`, cloning the `agent_id` string for each one. This is highly inefficient; descriptors are static metadata and should be fetched from static references without instantiating heavy trait objects.

#### Gratuitous String Reallocations in DBus Services
* **`crates/op-agents/src/dbus_service.rs:131`**:
  ```rust
  let mut task_json_mut = task_json.to_string();
  ```
  * **Critique**: `task_json` is already an owned `String`. Calling `to_string()` on it creates a completely redundant heap allocation and string copy solely because `simd_json::from_str` requires a mutable reference.
  * **Remediation**: Pass `&mut task_json` directly instead of allocating a duplicate.

---

### 6. Public API Leakage & Encapsulation Breaks

#### Raw Child Process Leakage
* **`crates/op-agents/src/agent_registry.rs:141`**:
  ```rust
  pub struct AgentHandle {
      pub id: String,
      pub process: tokio::process::Child,
      pub spec: AgentSpec,
  }
  ```
  * **Critique**: The `process` field exposes the raw `tokio::process::Child` instance directly to any consumer of `AgentHandle`. External callers can kill, wait on, or steal the stdout of the child process, which desynchronizes the registry state and corrupts instance tracking maps.
  * **Remediation**: Keep `process` private and expose safe, managed methods like `kill()` or `status()` on `AgentHandle`.

#### Shared State Lock Leakage
* **`crates/op-agents/src/router.rs:23`**:
  ```rust
  pub struct AgentsState {
      pub registry: Arc<RwLock<AgentRegistry>>,
  }
  ```
  * **Critique**: Exposing the raw `RwLock<AgentRegistry>` allows HTTP handlers or external callers to arbitrarily lock the registry in write mode indefinitely, creating denial-of-service vectors for the rest of the control plane.
  * **Remediation**: Encapsulate the registry inside `AgentsState` and expose specific thread-safe, non-blocking atomic transaction methods.

---

### 7. Concurrency, Blocking IO, and Deadlock Risks

#### Thread Pool Starvation (Synchronous OS Command Execution)
* **`crates/op-agents/src/agents/analysis/code_reviewer.rs:49`**:
  ```rust
  let output = cmd.output().map_err(|e| format!("Failed: {}", e))?;
  ```
  * **Critique**: This occurs across **all** analysis, development, and system agents (e.g., `CodeReviewerAgent`, `DebuggerAgent`, `SqlProAgent`, `RustProAgent`). They invoke synchronous blocking `std::process::Command::output()` directly on the Tokio runtime thread pool. Because these commands can run heavy operations (like `cargo build` or `semgrep`), they block the executor thread completely, starving the Tokio event loop and freezing all parallel operations.
  * **Remediation**: Use `tokio::process::Command` instead of `std::process::Command` to perform fully asynchronous, non-blocking process executions.

#### Non-Atomic File Overwrites on Async Threads
* **`crates/op-agents/src/agents/orchestration/memory.rs:114`**:
  ```rust
  fs::write(&self.memory_path, content).map_err(|e| e.to_string())?;
  ```
  * **Critique**: The `MemoryAgent` writes serialized cognitive memories directly to the file system using synchronous `std::fs::write`. This blocks the thread pool and is non-atomic. If the process is killed or loses power during the write, `memory_cognitive.json` will be partially written and corrupted.
  * **Remediation**: Write to a temporary file in the same directory (e.g., `memory_cognitive.json.tmp`) and use `std::fs::rename` to atomically replace the target file. Utilize `tokio::fs` to prevent thread blocking.