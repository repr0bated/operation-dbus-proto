# Rust Systems Audit: op-agents

## 1. Executive Summary & Core Metrics

### Synchronization & Smart Pointers
* **`Arc`**: 22 occurrences
* **`Rc`**: 0 occurrences
* **`RefCell`**: 0 occurrences
* **`RwLock`**: 20 occurrences
* **`Mutex`**: 1 occurrence
* **`OnceCell`**: 0 occurrences (Note: `once_cell::sync::Lazy` is used in the global registry)

### `.clone()` Metrics (matched via `\.clone\s*\(`)
* **Total `.clone()` calls**: 114 occurrences.
* **Primary Offender**: `crates/op-agents/src/agent_catalog.rs` containing **73** redundant clones of the same `agent_id` string during static registration.

---

## 2. Structs with Interior Mutability

The following structs/enums utilize interior mutability patterns (e.g., locking mechanisms or reference counting) for thread-safe state modification or lazy instantiation:

| Struct/Enum | Location | Mutability Mechanism |
| :--- | :--- | :--- |
| `AgentRegistry` | `crates/op-agents/src/agent_registry.rs:170` | `Arc<RwLock<HashMap<...>>>` |
| `DbusAgentService` | `crates/op-agents/src/dbus_service.rs:56` | `Arc<RwLock<Box<dyn AgentTrait>>>` |
| `AgentsState` | `crates/op-agents/src/router.rs:18` | `Arc<RwLock<AgentRegistry>>` |
| `ContextManagerAgent` | `crates/op-agents/src/agents/orchestration/context_manager.rs:12` | `Arc<RwLock<HashMap<String, String>>>` |
| `Mem0WrapperAgent` | `crates/op-agents/src/agents/orchestration/mem0_wrapper.rs:35` | `Mutex<Mem0State>` |
| `MemoryAgent` | `crates/op-agents/src/agents/orchestration/memory.rs:70` | `Arc<RwLock<HashMap<String, MemoryEntry>>>` |
| `UnifiedAgentRegistry` | `crates/op-agents/src/unified/registry.rs:14` | `RwLock<HashMap<String, Arc<dyn UnifiedAgent>>>` |

---

## 3. Large Structs (>5 Fields)

The following structs exceed 5 fields and represent high-overhead data layouts that should be passed by reference or optimized:

* **`AgentSpec`** (12 fields)
  * *Location*: `crates/op-agents/src/agent_registry.rs:18`
  * *Layout*: Contains heavy heap-allocated collections (`String`, `Vec<String>`, `HashMap<String, String>`).
* **`AgentInstance`** (7 fields)
  * *Location*: `crates/op-agents/src/agent_registry.rs:85`
  * *Layout*: Combines string metadata with timestamps and status enums.
* **`MemoryEntry`** (10 fields)
  * *Location*: `crates/op-agents/src/agents/orchestration/memory.rs:16`
  * *Layout*: Combines vector embeddings (`Option<Vec<f32>>`), string payloads, tags, and timestamps.
* **`AgentDefinition`** (9 fields)
  * *Location*: `crates/op-agents/src/generator/md_parser.rs:14`
  * *Layout*: Holds parsed markdown documentation parts as heap-allocated strings/vectors.
* **`AgentTemplate`** (8 fields)
  * *Location*: `crates/op-agents/src/generator/template.rs:12`
  * *Layout*: Generative struct holding string representations and whitelists.
* **`AgentOperation`** (6 fields)
  * *Location*: `crates/op-agents/src/generator/template.rs:43`
  * *Layout*: Structural metadata for generated agent operations.
* **`SecurityConfig`** (13 fields)
  * *Location*: `crates/op-agents/src/security/profiles.rs:36`
  * *Layout*: Heavily populated security constraints, directories, and whitelists.
* **`SandboxResult`** (6 fields)
  * *Location*: `crates/op-agents/src/security/sandbox.rs:49`
  * *Layout*: Sandboxed execution logs and metrics.
* **`ExecutionAgent`** (8 fields)
  * *Location*: `crates/op-agents/src/unified/execution/base.rs:14`
  * *Layout*: Backing struct for system code/command execution agents.
* **`OrchestrationAgent`** (6 fields)
  * *Location*: `crates/op-agents/src/unified/orchestration/base.rs:18`
  * *Layout*: Workflow-coordinating state engine.
* **`PersonaAgent`** (8 fields)
  * *Location*: `crates/op-agents/src/unified/persona/base.rs:12`
  * *Layout*: Backing state for persona-based LLM system prompts.

---

## 4. Critical Technical & Security Violations

### 4.1 Unsafe `simd_json` Deserialization Abuse
Throughout the codebase, `simd_json::from_str` is used inside raw `unsafe` blocks without ensuring the underlying safety invariants:
* `crates/op-agents/src/agent_registry.rs:224`
* `crates/op-agents/src/dbus_service.rs:111`
* `crates/op-agents/src/agents/orchestration/memory.rs:110`
* `crates/op-agents/src/agents/orchestration/memory.rs:192`

**Critique**: `simd_json` is highly optimized but requires the input string to be mutable, padded, and valid UTF-8. Using raw `unsafe` blocks here without asserting constraints or sanitizing inputs is extremely dangerous. If an invalid or unpadded string is passed from D-Bus or file streams, this results in **Undefined Behavior (UB) / Segfaults**. 

### 4.2 Panic Risks and Incorrect Float Sorting
* **`crates/op-agents/src/agents/orchestration/memory.rs:301`**
```rust
scored.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap());
```
**Critique**: Floating-point comparison can return `None` (e.g., if any calculated score results in `NaN`). Calling `.unwrap()` on the output of `partial_cmp` is a major anti-pattern. If a `NaN` score is produced, the application will **instantly panic and crash** the memory service. Use `.sort_by(|a, b| b.2.total_cmp(&a.2))` instead.

### 4.3 Lock Starvation & Sync/Async Primitive Mismatch
Synchronous locking primitives from the standard library are mixed with Tokio's async execution context:
* `crates/op-agents/src/agents/orchestration/context_manager.rs:12`
* `crates/op-agents/src/agents/orchestration/memory.rs:70`

**Critique**: These files use `std::sync::RwLock` instead of `tokio::sync::RwLock`. While standard library locks are acceptable if never held across `.await` points, any accidental yield or long-running block will block the entire OS thread, causing starvation of the Tokio reactor pool. This should be refactored to use Tokio's non-blocking locks or synchronous scopes should be explicitly constrained.

### 4.4 Severe Clone Churn & Heap Allocations
* **`crates/op-agents/src/agent_catalog.rs:47` to `143`**
```rust
Box::new(BashProAgent::new(agent_id.clone())),
Box::new(CProAgent::new(agent_id.clone())),
... [Repeated 73 times]
```
**Critique**: This is egregious clone abuse. A single `agent_id` is cloned 73 times to populate static vectors. The underlying Agent structures should be designed to accept an `Arc<str>` or share a reference to a static string, avoiding thousands of unnecessary string heap allocations upon service startup.

### 4.5 Public API Leakage
* **`crates/op-agents/src/lib.rs:25`**
Concrete implementation modules (e.g., `aiml`, `analysis`, `architecture`, `business`) are globally exported alongside the unified architecture modules.

**Critique**: This creates massive API leakage, exposing internal implementation details and concrete structs (e.g., `AIEngineerAgent`, `DataScientistAgent`) directly to consumers. It violates encapsulation and heavily couples outside crates to the individual concrete implementations instead of abstracting them behind the `UnifiedAgent` or `AgentTrait` interfaces. Use restricted visibility (`pub(crate)`) for concrete agent modules.