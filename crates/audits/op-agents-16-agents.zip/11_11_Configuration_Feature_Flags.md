### 1. Environment Variable Reads (`std::env::var`)

*   **crates/op-agents/src/agents/orchestration/mem0_wrapper.rs:56**: Reads `PYTHON_PATH` environment variable to configure the Python interpreter path, defaulting to `"/usr/bin/python3"`.
*   **crates/op-agents/src/agents/orchestration/mem0_wrapper.rs:58**: Reads `MEM0_DIR` environment variable to determine the storage directory, defaulting to `"/var/lib/op-dbus/.mem0"`.
*   **crates/op-agents/src/bin/dbus-agent-manager.rs:205**: Reads `DBUS_AGENT_SESSION` to decide whether to register on the session bus or the system bus.

---

### 2. Configuration Files & Hardcoded Paths

*   **crates/op-agents/src/agent_registry.rs:163**: Parses configuration files dynamically using `simd_json::from_str` within `load_specs_from_file`.
*   **crates/op-agents/src/agents/orchestration/memory.rs:88**: Hardcoded absolute path `/var/lib/op-dbus/memory_cognitive.json` for cognitive memory persistence.
*   **crates/op-agents/src/agents/orchestration/memory.rs:91**: Hardcoded absolute path `/var/lib/op-dbus/memory.json` used to migrate old key-value store configurations.
*   **crates/op-agents/src/agents/orchestration/mem0_wrapper.rs:59**: Hardcoded path `/var/lib/op-dbus/.mem0` used as fallback for local database storage when `MEM0_DIR` is not set.

---

### 3. Cargo Features & Default Features

*   **crates/op-agents/Cargo.toml**: No features or default features are declared in this crate's manifest. It relies entirely on workspace dependencies.
*   **Cargo.toml**: The workspace root manifest defines:
    ```toml
    [features]
    default = ["grpc"]
    grpc = []
    ```

---

### 4. Hardcoded Defaults

*   **crates/op-agents/src/agent_registry.rs:90**: Hardcoded `default_max_instances` defaults to `5` for any registered agent spec.
*   **crates/op-agents/src/agents/base.rs:253**: `MAX_PATH_LENGTH` is hardcoded to `4096`.
*   **crates/op-agents/src/agents/base.rs:254**: `MAX_ARGS_LENGTH` is hardcoded to `256`.
*   **crates/op-agents/src/agents/analysis/debugger.rs:29**: Hardcoded fallback limit of `"100"` lines for log reading operations.
*   **crates/op-agents/src/agents/analysis/debugger.rs:46**: Hardcoded limit of `-n 100` for systemd journal analysis.
*   **crates/op-agents/src/agents/analysis/performance.rs:25**: Hardcoded execution intervals for `vmstat 1 5`.
*   **crates/op-agents/src/agents/analysis/performance.rs:36**: Hardcoded arguments for device metric analysis: `iostat -x 1 3`.
*   **crates/op-agents/src/agents/content/docs_architect.rs:34**: Hardcoded file read size limit of `100000` bytes before truncation.
*   **crates/op-agents/src/agents/content/tutorial_engineer.rs:43**: Hardcoded comment extraction limit of `50` lines.
*   **crates/op-agents/src/agents/infrastructure/kubernetes.rs:66**: Hardcoded log tail limit of `--tail=100` for Pod analytics.
*   **crates/op-agents/src/agents/language/rust_pro.rs:189**: Hardcoded clippy escalation parameters: `"--"`, `"-D"`, `"warnings"`.
*   **crates/op-agents/src/generator/md_parser.rs:88**: Hardcoded default target model is `"sonnet"`.
*   **crates/op-agents/src/security/profiles.rs:95**: Hardcoded execution timeout defaults to `60` seconds.
*   **crates/op-agents/src/security/profiles.rs:98**: Hardcoded execution memory limit defaults to `512` megabytes.
*   **crates/op-agents/src/security/profiles.rs:101**: Hardcoded execution stdout/stderr size limit defaults to `1_000_000` bytes.
*   **crates/op-agents/src/security/profiles.rs:104**: Hardcoded maximum concurrent operations per agent defaults to `1`.
*   **crates/op-agents/src/security/profiles.rs:114**: Hardcoded paths allowed for reading (`/home`, `/tmp`) and explicitly blocked (`/etc`, `/root`, `/var/lib`, `/sys`, `/proc`).
*   **crates/op-agents/src/security/validation.rs:13**: Hardcoded execution input sanity checks: `MAX_PATH_LENGTH = 4096`, `MAX_COMMAND_LENGTH = 256`, `MAX_ARGS_LENGTH = 4096`, `MAX_INPUT_LENGTH = 1_000_000`.
*   **crates/op-agents/src/security/sandbox.rs:33**: Hardcoded `ResourceLimits` defaults (60s execution timeout, 512MB memory limit, 1MB output allocation, max 10 processes).
*   **crates/op-agents/src/security/sandbox.rs:118**: Hardcoded sandbox standard environment variables overrides: `PATH="/usr/local/bin:/usr/bin:/bin"`, `HOME="/tmp"`, `LANG="C.UTF-8"`.

---

### 5. Security & Robustness Audit

#### Unsafe Code Abuse
*   **crates/op-agents/src/agent_registry.rs:167**: `unsafe { simd_json::from_str(&mut content) }` is used to parse dynamic configuration files. `simd-json` requires mutation in place, but this is unsafe if the string slice's lifetime or alignment is violated.
*   **crates/op-agents/src/dbus_service.rs:135**: `unsafe { simd_json::from_str(&mut task_json_mut) }` parses tasks directly from untrusted D-Bus payloads.
*   **crates/op-agents/src/agents/orchestration/memory.rs:119**: `unsafe { simd_json::from_str(&mut content_mut).unwrap_or_default() }` parses cognitive memory data from the local state file.
*   **crates/op-agents/src/agents/orchestration/memory.rs:188**: `unsafe { simd_json::from_str(&mut content_mut).unwrap_or_default() }` migrates key-value store history.
*   **crates/op-agents/src/generator/template.rs:563**: `unsafe { simd_json::from_str(&mut task_json) }` generated into compiled template code.
*   **crates/op-agents/src/security/validation.rs:175**: `unsafe { simd_json::from_str(&mut json_mut) }` used in generalized input parsing.

#### Unwrap & Panic Risks
*   **crates/op-agents/src/unified/registry.rs:42**: `self.agents.read().unwrap()` will panic if any preceding task panics while holding the lock (lock poisoning).
*   **crates/op-agents/src/unified/registry.rs:52**: `self.agents.write().unwrap()` will panic on lock poisoning.
*   **crates/op-agents/src/bin/dbus-agent-manager.rs:200**: `.add_directive("op_agents=info".parse().unwrap())` will crash the launcher binary if the filter directive is malformed.
*   **crates/op-agents/src/generator/md_parser.rs:114**: `captures.get(1).unwrap().as_str()` will panic if the regex returns successfully but fails to capture group index `1`.
*   **crates/op-agents/src/generator/md_parser.rs:115**: `captures.get(2).unwrap().as_str()` has the same panic risk for capture index `2`.

#### Clone Abuse (Excessive Allocations)
*   **crates/op-agents/src/agent_catalog.rs:57-128**: Excessive cloning of `agent_id` (cloned over 70 times sequentially) to populate the vector of built-in descriptors inside `builtin_agent_descriptors()`. Passing `&str` or utilizing `Arc<str>` is required.
*   **crates/op-agents/src/agent_registry.rs:265**: `specs.get(agent_type)...clone()` clones a heavy `AgentSpec` struct containing maps and lists on every agent spawn.
*   **crates/op-agents/src/dbus_service.rs:134**: `task_json.to_string()` performs an unnecessary allocation copy of the dynamic payload string.

#### Public API Leakage & Bugs
*   **crates/op-agents/src/unified/execution/base.rs:43**: **Compilation Failure Bug**. Attempts to load `include_str!("../../prompts.rs")`. Because `base.rs` is at `crates/op-agents/src/unified/execution/base.rs`, this path resolves to `crates/op-agents/src/prompts.rs`. However, the prompts module resides at `crates/op-agents/src/unified/prompts.rs`. This will break compilation during code generation because the path should be `../prompts.rs`.
*   **crates/op-agents/src/unified/agent_trait.rs:48**: **Compilation Failure Bug**. The struct fields declare `pub args: Value` and `pub data: Value` (at line 69), but `Value` is never defined or aliased in this file's scope. It imports `use simd_json::OwnedValue;` but fails to bind it to `Value`.
*   **crates/op-agents/src/unified/execution/base.rs:28**: Public struct `ExecutionAgent` directly exposes the inner `pub security_profile: SecurityProfile`, allowing external crates to bypass the execution abstraction and manipulate sandbox constraints directly.