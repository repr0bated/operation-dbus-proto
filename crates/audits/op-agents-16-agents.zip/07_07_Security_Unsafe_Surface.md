# Security Audit Report: `op-agents`

## 1. Unsafe Block Audit

All `unsafe {` blocks discovered in the audited files are listed below. Every single instance **fails** to provide a `// SAFETY:` comment justifying the safety invariants of the operation.

| File & Line | Context | `// SAFETY:` Comment | Status |
| :--- | :--- | :--- | :--- |
| `crates/op-agents/src/agent_registry.rs:312` | `let specs: Vec<AgentSpec> = unsafe { simd_json::from_str(&mut content) }` | **Missing** | 🚨 **CRITICAL FLAGGED** |
| `crates/op-agents/src/dbus_service.rs:126` | `let task: AgentTask = unsafe { simd_json::from_str(&mut task_json_mut) }.map_err(...)` | **Missing** | 🚨 **CRITICAL FLAGGED** |
| `crates/op-agents/src/agents/orchestration/memory.rs:141` | `let value: simd_json::OwnedValue = unsafe { simd_json::from_str(&mut content_mut).unwrap_or_default() };` | **Missing** | 🚨 **CRITICAL FLAGGED** |
| `crates/op-agents/src/agents/orchestration/memory.rs:232` | `let old_cache: HashMap<String, String> = unsafe { simd_json::from_str(&mut content_mut).unwrap_or_default() };` | **Missing** | 🚨 **CRITICAL FLAGGED** |
| `crates/op-agents/src/security/validation.rs:182` | `unsafe { simd_json::from_str(&mut json_mut).map_err(...) }` | **Missing** | 🚨 **CRITICAL FLAGGED** |
| `crates/op-agents/src/generator/template.rs:442` | `let task: {struct_name}Task = match unsafe {{ simd_json::from_str(&mut task_json) }} {{` | **Missing** (Generated) | 🚨 **CRITICAL FLAGGED** |

---

## 2. Telemetry and Process Command Counts

A total of **137** command/process utility primitives are utilized in the codebase. Individual component counts are as follows:

*   **`Command::new`**: **104** occurrences
    *   *Examples*: Spawning diagnostic commands (`ip`, `ss`, `free`), orchestrating builds (`cargo`, `go`, `dotnet`, `g++`), and sandboxing (`tokio::process::Command` in `sandbox.rs` and `execution/base.rs`).
*   **`std::process`**: **32** occurrences (all resolved as `use std::process::Command;` or `use std::process::Stdio;` imports).
*   **`shell-words`**: **1** occurrence
    *   *Citations*: `crates/op-agents/src/security/validation.rs:167` (`shell_words::split(args)`)

---

## 3. Hardcoded Configurations, Secrets, and Env Reads

*   **Hardcoded Private Paths / Resource Configs**:
    *   `crates/op-agents/src/agents/orchestration/mem0_wrapper.rs:47`: Hardcoded cache fallback directory `/var/lib/op-dbus/.mem0`.
    *   `crates/op-agents/src/agents/orchestration/memory.rs:46`: Hardcoded absolute storage location `/var/lib/op-dbus/memory_cognitive.json`.
    *   `crates/op-agents/src/agents/orchestration/memory.rs:49`: Hardcoded absolute storage migration path `/var/lib/op-dbus/memory.json`.
*   **Environment Variable Reads (`std::env::var`)**:
    *   `crates/op-agents/src/agents/orchestration/mem0_wrapper.rs:44`: `std::env::var("PYTHON_PATH")`
    *   `crates/op-agents/src/agents/orchestration/mem0_wrapper.rs:46`: `std::env::var("MEM0_DIR")`
    *   `crates/op-agents/src/bin/dbus-agent-manager.rs:223`: `std::env::var("DBUS_AGENT_SESSION")`

---

## 4. Architectural Vulnerabilities, Unwrap, and Clone Abuse

### Clone Abuse
The built-in agent registration mechanism uses extreme cloning of string identifiers, causing needless allocations on the stack and heap:
*   `crates/op-agents/src/agent_catalog.rs:52-127`: Over **80 instances** of `.clone()` for `agent_id.clone()`. This must be refactored to pass a shared reference (`&str` or `Arc<str>`) instead of deep-cloning owned strings inside the dynamic allocation vectors.

### Panic Risks via `unwrap` and Destructive Array indexing
*   `crates/op-agents/src/generator/md_parser.rs:114`: `captures.get(1).unwrap().as_str()` — This will panic on malformed Markdown files missing YAML block patterns, bypassing compile-time safety.
*   `crates/op-agents/src/generator/md_parser.rs:115`: `captures.get(2).unwrap().as_str()` — Same risk.
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:214`: `.parse().unwrap()` — Panics if the default logger initialization configuration fails or is modified.
*   `crates/op-agents/src/security/validation.rs:218`: `.find(...).unwrap()` — Panic risk if the forbidden character search fails to match but was flagged.

### Public API Information Leakage and Design Flaws
*   `crates/op-agents/src/agent_registry.rs:16`: `pub struct AgentSpec` exposes delicate operational configurations (including `requires_root` boolean and environment hashes) as fully public, mutable fields. This allows arbitrary out-of-bounds mutation of spawn targets.
*   `crates/op-agents/src/unified/agent_trait.rs:72`: `pub struct AgentResponse` exposes raw data as a mutable `Value`. This leaks system internal layouts to LLMs and D-Bus callers without strict mapping rules.