# Observability & Security Audit: `op-agents`

## 1. Observability Profile

### 1.1 Direct `tracing::` Usage
Directly prefixed tracing macro invocations found in the codebase:
*   `crates/op-agents/src/agent_registry.rs:249` — `tracing::warn!`
*   `crates/op-agents/src/dbus_service.rs:354` — `tracing::info!`
*   `crates/op-agents/src/dbus_service.rs:401` — `tracing::info!`

### 1.2 Imported/Unprefixed `tracing` Macro Usage
Invocations of tracing macros imported into local scopes:
*   `crates/op-agents/src/dbus_service.rs:196` — `debug!`
*   `crates/op-agents/src/dbus_service.rs:200` — `error!`
*   `crates/op-agents/src/dbus_service.rs:218` — `error!`
*   `crates/op-agents/src/dbus_service.rs:223` — `error!`
*   `crates/op-agents/src/dbus_service.rs:361` — `info!`
*   `crates/op-agents/src/dbus_service.rs:384` — `info!`
*   `crates/op-agents/src/dbus_service.rs:410` — `info!`
*   `crates/op-agents/src/dbus_service.rs:433` — `info!`
*   `crates/op-agents/src/agents/orchestration/mem0_wrapper.rs:81` — `warn!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:173` — `info!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:189` — `info!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:207` — `error!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:213` — `info!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:223` — `info!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:243` — `info!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:247` — `info!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:250` — `info!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:257` — `error!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:261` — `info!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:265` — `info!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:270` — `info!`
*   `crates/op-agents/src/bin/dbus-agent-manager.rs:273` — `info!`
*   `crates/op-agents/src/bin/dbus-agent.rs:144` — `error!`
*   `crates/op-agents/src/bin/dbus-agent.rs:145` — `warn!`
*   `crates/op-agents/src/bin/dbus-agent.rs:155` — `info!`

### 1.3 `log::` Macro Usage
*   **None.** The `log` crate is specified as a dependency but never invoked. All telemetry relies entirely on `tracing`.

### 1.4 `println!` Macro Usage
Standard output prints bypassing the telemetry framework:
*   `crates/op-agents/src/bin/dbus-agent.rs:126` — Prints the agent list directly to standard output.
*   `crates/op-agents/src/generator/template.rs:475` — Embedded inside the code-generation template.
*   `crates/op-agents/src/generator/template.rs:487` — Embedded inside the code-generation template.
*   `crates/op-agents/src/generator/template.rs:598` — Embedded inside the code-generation template.
*   `crates/op-agents/src/generator/template.rs:610` — Embedded inside the code-generation template.
*   `crates/op-agents/src/generator/template.rs:611` — Embedded inside the code-generation template.
*   `crates/op-agents/src/generator/template.rs:612` — Embedded inside the code-generation template.

### 1.5 Metrics Framework Integration
*   The crate `op-agents` does not instantiate or register Prometheus or `metrics` crate metrics itself. Metrics tracking is delegated entirely to the sibling crate `op-execution-tracker` (which relies on `prometheus` as shown in the workspace definitions).

---

## 2. Error Context Profile

### 2.1 `anyhow::Context` Usage
Constructive context wrapping for nested error propagation:
*   `crates/op-agents/src/agent_registry.rs:175` — `.context(format!("Failed..."))` on process spawning.
*   `crates/op-agents/src/agent_registry.rs:223` — `.context("Failed to read...")` on file reading.
*   `crates/op-agents/src/agent_registry.rs:229` — `.context("Failed to parse...")` on configuration parsing.
*   `crates/op-agents/src/agent_registry.rs:241` — `.context("Failed to read...")` on directory discovery.
*   `crates/op-agents/src/agent_registry.rs:333` — `.context("Failed to kill...")` on dynamic agent termination.
*   `crates/op-agents/src/generator/md_parser.rs:104` — `.context("No YAML...")` on frontmatter parsing.
*   `crates/op-agents/src/generator/md_parser.rs:111` — `.context("Failed to parse...")` on YAML structure.
*   `crates/op-agents/src/generator/md_parser.rs:129` — `.context(format!("Failed to read..."))` on file extraction.

### 2.2 `thiserror` Usage
Domain-specific error modeling using structured derivations:
*   `crates/op-agents/src/dbus_service.rs:126` — Defines `DbusAgentError` with automated formatting mappings.
*   `crates/op-agents/src/security/validation.rs:18` — Defines `ValidationError` for validation failures.
*   `crates/op-agents/src/security/validation.rs:35` — Defines `SecurityError` for sandboxing violations.

---

## 3. Unsafe Blocks & SIMD-JSON Safety Risks

### 3.1 Unsafe `simd-json` Mutations
`simd-json` requires mutable parsing buffers because it performs destructive in-place manipulation of the string slice. Using `unsafe` parsing on inputs whose lifetime is unconstrained or containing references to short-lived buffers introduces high risk of Use-After-Free (UAF) or undefined pointer dereferences:
*   `crates/op-agents/src/agent_registry.rs:229` — `unsafe { simd_json::from_str(&mut content) }`
*   `crates/op-agents/src/dbus_service.rs:200` — `unsafe { simd_json::from_str(&mut task_json_mut) }`
*   `crates/op-agents/src/agents/orchestration/memory.rs:108` — `unsafe { simd_json::from_str(&mut content_mut).unwrap_or_default() }`
*   `crates/op-agents/src/agents/orchestration/memory.rs:207` — `unsafe { simd_json::from_str(&mut content_mut).unwrap_or_default() }`
*   `crates/op-agents/src/generator/template.rs:477` — Codegen output uses `unsafe { simd_json::from_str(&mut task_json) }` for all dynamically compiled agent servers.

---

## 4. Panics, Unwraps, and Poisoning Risks

### 4.1 Float NaN Ordering Panic
*   `crates/op-agents/src/agents/orchestration/memory.rs:359`
    ```rust
    scored.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap());
    ```
    **Critical Vulnerability:** Floating-point addition and multiplication can output `NaN`. If any memory score calculates as `NaN`, `partial_cmp` returns `None`. Calling `.unwrap()` on `None` inside `sort_by` triggers a thread panic, instantly killing the core database/memory agent thread.

### 4.2 Raw Unwraps on Serialization
*   `crates/op-agents/src/agents/orchestration/sequential_thinking.rs:35`
    ```rust
    Ok(simd_json::to_string_pretty(&steps).unwrap())
    ```
    Unconditional panic vector if JSON serialization fails due to structural or character limits.

### 4.3 Mutex/RwLock Poisoning Vulnerabilities
RwLocks are acquired with `.unwrap()` throughout the unified agent modules, leaving them vulnerable to cascading lock poisoning panics:
*   `crates/op-agents/src/unified/registry.rs:41` — `self.agents.read().unwrap()`
*   `crates/op-agents/src/unified/registry.rs:50` — `self.agents.write().unwrap()`

### 4.4 Regex Capture Group Panics
*   `crates/op-agents/src/generator/md_parser.rs:106` — `captures.get(1).unwrap().as_str()`
*   `crates/op-agents/src/generator/md_parser.rs:107` — `captures.get(2).unwrap().as_str()`
    Assumes matching capture groups exist without structural guarantees, creating instant panic vectors during Markdown parsing.

---

## 5. Memory Management & Clone Abuse

### 5.1 Sequential Clone Spams
*   `crates/op-agents/src/agent_catalog.rs:71-155`
    The setup sequentially clones the `agent_id` string exactly 68 times to instantiate the static catalog.
    ```rust
    Box::new(BashProAgent::new(agent_id.clone())),
    Box::new(CProAgent::new(agent_id.clone())),
    // ... cloned continuously for 68 entries
    ```
    This causes excessive heap allocation. The constructors should accept a reference (`&str`) or use `Arc<str>` to prevent redundant string replication.

---

## 6. Critical Security Weaknesses

### 6.1 Trivial Bypass of SQLite Query Filtering (SQL Injection / System Compromise)
*   `crates/op-agents/src/agents/database/sql_pro.rs:37`
    ```rust
    let q_upper = q.to_uppercase();
    if !q_upper.trim().starts_with("SELECT")
        && !q_upper.trim().starts_with(".SCHEMA")
        && !q_upper.trim().starts_with(".TABLES")
    {
        return Err("Only SELECT queries allowed".to_string());
    }
    ```
*   `crates/op-agents/src/agents/database/database_optimizer.rs:38`
    Uses identical `starts_with("SELECT")` logic.

    **Critical Security Flaw:** This query validator is fundamentally broken. It only checks if the query *starts* with `SELECT`. This allows severe security bypasses:
    1.  **Multi-statement executions / Stacked Queries:** `SELECT 1; DROP TABLE users;` or `SELECT 1; ATTACH DATABASE '/etc/passwd' AS bypass;` will execute because the first statement begins with `SELECT`.
    2.  **Data Modification via CTEs / Nested Write Vectors:** Common Table Expressions starting with `SELECT` can invoke mutating SQLite functions, trigger arbitrary filesystem writes (if `writefile()` is linked), or exploit side-channel loading extensions.

### 6.2 Insufficient Command Argument Sanitization
*   `crates/op-agents/src/security/validation.rs:8`
    ```rust
    pub const FORBIDDEN_CHARS: &[char] = &[
        '$', '`', ';', '&', '|', '>', '<', '(', ')', '{', '}', '\n', '\r', '\0',
    ];
    ```
    **Security Flaw:** The argument filter block only screens for simple shell interpolation characters. It does not prevent compiler-specific injection flags (such as passing `-wrapper` or `-specs` flags to `gcc` or `g++`, or utilizing config imports in `cargo`/`python` to spawn child shells). Since this sandbox allows raw compilation/execution of files under `/home` and `/tmp`, attackers can easily execute arbitrary system commands by bypassing this character whitelist.