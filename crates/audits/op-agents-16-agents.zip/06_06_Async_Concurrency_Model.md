# Codebase Audit Report: op-agents

## 1. Async & Concurrency Metric Counts

* **`async fn` definitions**: **136** (including trait declarations, implementations, Axum route handlers, and agent lifecycle operations).
* **`tokio::spawn` invocations**: **1** 
  * `crates/op-agents/src/agent_registry.rs:191` (used to push the default factory in a background task).
* **`tokio::task::spawn_blocking` invocations**: **0**

---

## 2. Public Trait Send/Sync Bounds

To ensure thread safety across asynchronous boundaries (e.g., when tasks are routed via Axum or dispatched across thread pools by the `zbus` D-Bus reactor), the following public traits are explicitly bound to `Send + Sync`:

### `AgentFactory`
* **File & Line**: `crates/op-agents/src/agent_registry.rs:125`
* **Definition**:
  ```rust
  #[async_trait]
  pub trait AgentFactory: Send + Sync { ... }
  ```

### `AgentTrait`
* **File & Line**: `crates/op-agents/src/agents/base.rs:178`
* **Definition**:
  ```rust
  #[async_trait]
  pub trait AgentTrait: Send + Sync { ... }
  ```

### `UnifiedAgent`
* **File & Line**: `crates/op-agents/src/unified/agent_trait.rs:152`
* **Definition**:
  ```rust
  #[async_trait]
  pub trait UnifiedAgent: Send + Sync { ... }
  ```

---

## 3. Concurrency Anti-Pattern: Blocking Calls in Async Contexts

The codebase is highly saturated with synchronous file-system operations (`std::fs`) and synchronous process executions (`std::process::Command`) running directly within cooperative asynchronous tasks. 

Because Tokio utilizes cooperative scheduling, performing a blocking syscall on a worker thread deprives the runtime of its ability to yield, starving the reactor of execution cycles.

### 3.1. Synchronous Disk I/O (`std::fs`)
The following locations perform synchronous disk reads/writes inside async execution blocks instead of using `tokio::fs`:

* **`crates/op-agents/src/agents/content/docs_architect.rs:30`**: `std::fs::read_to_string(&validated_path)`
* **`crates/op-agents/src/agents/content/mermaid_expert.rs:28`**: `std::fs::read_to_string(&validated_path)`
* **`crates/op-agents/src/agents/content/tutorial_engineer.rs:24`**: `std::fs::read_to_string(&validated_path)`
* **`crates/op-agents/src/agents/content/tutorial_engineer.rs:42`**: `std::fs::read_to_string(&validated_path)`
* **`crates/op-agents/src/agents/orchestration/memory.rs:95`**: `fs::read_to_string(&memory_path)` inside the sync instantiation phase (called via `MemoryAgent::new` which can run in async closures).
* **`crates/op-agents/src/agents/orchestration/memory.rs:98`**: `fs::read_to_string(&old_path)`
* **`crates/op-agents/src/agents/orchestration/memory.rs:113`**: `fs::write(&self.memory_path, content)` executed inside `persist()`, which runs inside the asynchronous `MemoryAgent::execute` loop.

### 3.2. Synchronous Process Spawning (`std::process::Command::output`)
Over 30 distinct agents spawn child processes and synchronously block on their output via `.output()` on Tokio threads. These must be replaced with `tokio::process::Command` or moved to `spawn_blocking`:

* **Analysis Agents**:
  * `crates/op-agents/src/agents/analysis/code_reviewer.rs:43, 58, 77, 94`
  * `crates/op-agents/src/agents/analysis/debugger.rs:35, 49, 60`
  * `crates/op-agents/src/agents/analysis/performance.rs:28, 39, 50, 61`
  * `crates/op-agents/src/agents/analysis/security_auditor.rs:32, 47, 60, 73`
* **Content Agents**:
  * `crates/op-agents/src/agents/content/api_documenter.rs:30, 44, 57`
  * `crates/op-agents/src/agents/content/docs_architect.rs:53, 67`
  * `crates/op-agents/src/agents/content/mermaid_expert.rs:59`
* **Database Agents**:
  * `crates/op-agents/src/agents/database/database_architect.rs:33, 49, 67`
  * `crates/op-agents/src/agents/database/database_optimizer.rs:40, 56, 71`
  * `crates/op-agents/src/agents/database/sql_pro.rs:44, 60, 75`
* **Infrastructure & SRE Agents**:
  * `crates/op-agents/src/agents/infrastructure/cloud.rs:38, 53`
  * `crates/op-agents/src/agents/infrastructure/deployment.rs:41, 59, 75`
  * `crates/op-agents/src/agents/infrastructure/kubernetes.rs:39, 55, 78, 92`
  * `crates/op-agents/src/agents/infrastructure/network.rs:28, 38, 48, 62`
  * `crates/op-agents/src/agents/infrastructure/terraform.rs:35, 52, 69, 86`
* **Language Executors**:
  * `crates/op-agents/src/agents/language/bash_pro.rs:35, 56, 75`
  * `crates/op-agents/src/agents/language/c_pro.rs:36, 61, 78`
  * `crates/op-agents/src/agents/language/cpp_pro.rs:37, 56`
  * `crates/op-agents/src/agents/language/csharp_pro.rs:31, 50, 69`
  * `crates/op-agents/src/agents/language/elixir_pro.rs:31, 50, 69`
  * `crates/op-agents/src/agents/language/golang_pro.rs:44, 78, 99, 120, 146`
  * `crates/op-agents/src/agents/language/java_pro.rs:34, 54, 73`
  * `crates/op-agents/src/agents/language/javascript_pro.rs:42, 63, 85, 108, 129`
  * `crates/op-agents/src/agents/language/julia_pro.rs:35, 54`
  * `crates/op-agents/src/agents/language/php_pro.rs:35, 54, 69, 87`
  * `crates/op-agents/src/agents/language/python_pro.rs:44, 76, 95, 114, 142`
  * `crates/op-agents/src/agents/language/ruby_pro.rs:35, 55, 70`
  * `crates/op-agents/src/agents/language/rust_pro.rs:40, 78, 109, 139, 164`
  * `crates/op-agents/src/agents/language/scala_pro.rs:31, 50`
  * `crates/op-agents/src/agents/language/typescript_pro.rs:33, 52, 71, 95`
* **Orchestration Agents**:
  * `crates/op-agents/src/agents/orchestration/dx_optimizer.rs:74`

---

## 4. Unsafe Code Analysis (`simd-json` Mutability)

The codebase utilizes `simd-json` for high-performance JSON parsing. However, its APIs are frequently marked as `unsafe` because they require mutating the source string buffer in-place (`&mut str`). This is highly dangerous if structural pointers/references escape the lifetime of the mutating buffer, leading to Undefined Behavior.

### 4.1. Unsafe parsing of incoming D-Bus arguments
* **File & Line**: `crates/op-agents/src/dbus_service.rs:113`
* **Code**:
  ```rust
  let task: AgentTask = unsafe { simd_json::from_str(&mut task_json_mut) }.map_err(|e| ... )?;
  ```
* **Vulnerability**: While a copy is performed on line 112 (`let mut task_json_mut = task_json.to_string();`), executing `unsafe` deserialization over variable IPC payloads without isolating references or checking lifetime invariant guarantees increases regression risks during future refactors.

### 4.2. Unsafe deserialization in specifications loading
* **File & Line**: `crates/op-agents/src/agent_registry.rs:216`
* **Code**:
  ```rust
  let specs: Vec<AgentSpec> = unsafe { simd_json::from_str(&mut content) }
      .context("Failed to parse agent specifications")?;
  ```
* **Vulnerability**: The raw file buffer `content` is mutated in-place. If `AgentSpec` fields borrow string segments directly (though presently they use owned `String`s), dropping `content` before `specs` results in a use-after-free.

### 4.3. Unsafe parsing in persistent state
* **File & Line**: `crates/op-agents/src/agents/orchestration/memory.rs:123`
* **Code**:
  ```rust
  let value: simd_json::OwnedValue = unsafe { simd_json::from_str(&mut content_mut).unwrap_or_default() };
  ```
* **Vulnerability**: The code masks errors using `.unwrap_or_default()`. If corruption occurs in the JSON database on disk (`/var/lib/op-dbus/memory_cognitive.json`), the parser will fail silently, returning an empty `OwnedValue`, resulting in structural data loss during the subsequent synchronous write phase.

### 4.4. Additional unsafe parsing sites
* **File & Line**: `crates/op-agents/src/agents/orchestration/memory.rs:207`
  * `simd_json::from_str` over migrating database values.
* **File & Line**: `crates/op-agents/src/security/validation.rs:175`
  * Parsing in-place JSON within a security validation library.
* **File & Line**: `crates/op-agents/src/generator/template.rs:446`
  * Generates code containing the unsafe template string `unsafe { simd_json::from_str(&mut task_json) }`.

---

## 5. Allocation & Clone Abuse

### 5.1. Allocation Storm in Built-In Agent Catalog
* **File & Line**: `crates/op-agents/src/agent_catalog.rs:58-132`
* **Code**:
  ```rust
  Box::new(BashProAgent::new(agent_id.clone())),
  Box::new(CProAgent::new(agent_id.clone())),
  ...
  ```
* **Issue**: The `builtin_agent_descriptors()` function performs a heap-allocated `.clone()` of `agent_id` more than **75 times** sequentially just to construct throwaway descriptors for catalog enumeration. This is severe allocation abuse.
* **Correction**: The constructors should accept `&str` or share the identifier via an `Arc<str>` reference.

### 5.2. Heavy heap reallocation inside AXUM router
* **File & Line**: `crates/op-agents/src/router.rs:118`
* **Code**:
  ```rust
  let config = request.get("config").cloned();
  ```
* **Issue**: In `spawn_agent_handler`, cloning `OwnedValue` copies the entire polymorphic tree recursively on every single POST invocation, introducing lock contention on high-load HTTP nodes.

---

## 6. Public API Leakage

### 6.1. Leaking Internals of Process Lifecycles
* **File & Line**: `crates/op-agents/src/agent_registry.rs:141`
* **Code**:
  ```rust
  pub struct AgentHandle {
      pub id: String,
      pub process: tokio::process::Child,
      pub spec: AgentSpec,
  }
  ```
* **Issue**: Exposing the `tokio::process::Child` handle directly inside a public struct leaks low-level operating system handles. Any downstream consumer can calling `.kill().await` or drain stdout, bypassing internal state trackers (`AgentRegistry`) and causing synchronization desyncs on `AgentInstance` health reports.

### 6.2. Leaking Lock State in States
* **File & Line**: `crates/op-agents/src/router.rs:19`
* **Code**:
  ```rust
  pub struct AgentsState {
      pub registry: Arc<RwLock<AgentRegistry>>,
  }
  ```
* **Issue**: Making `registry` a public property of `AgentsState` leaks internal synchronization primitives. Consumers can seize the lock directly and cause deadlocks or mutate agent collections without calling the routing layer.

---

## 7. Panic Risks & Fragile Error Handling

### 7.1. Regular Expression Capture Unwraps
* **File & Line**: `crates/op-agents/src/generator/md_parser.rs:114-115`
* **Code**:
  ```rust
  let yaml_content = captures.get(1).unwrap().as_str();
  let markdown_content = captures.get(2).unwrap().as_str();
  ```
* **Issue**: High panic risk. If the regular expression matches, but the capture groups fail due to edge-case formatting anomalies in generated markdown definitions, the program panics immediately. Use `captures.get(1).ok_or(...)` instead of unconstrained unwraps.