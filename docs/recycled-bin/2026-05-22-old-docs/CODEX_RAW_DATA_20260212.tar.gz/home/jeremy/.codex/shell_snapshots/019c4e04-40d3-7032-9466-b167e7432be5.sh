# Snapshot file
# Unset all aliases to avoid conflicts with functions
# Functions

# setopts 3
set -o braceexpand
set -o hashall
set -o interactive-comments

# aliases 0

# exports 65
declare -x AWS_DEFAULT_REGION="us-east-1"
declare -x AWS_REGION="us-east-1"
declare -x AWS_SSO_START_URL="https://identitycenter.amazonaws.com/ssoins-72238e735c50b2ed"
declare -x CF_ACCOUNT_ID="b049bc6141e3b098b50da901a5cca6b1"
declare -x CF_DNS_ZONE_TOKEN="xYr5oIq_kN8hT4ZsddqFnERKtD6u015eSmXnqWtV"
declare -x CF_EMAIL="jeremy.alan.hobson@gmail.com"
declare -x CF_GLOBAL_API_KEY="c5ae69bd725446360b71fa629b0fd3f0f89a9"
declare -x CF_ORIGINCA_KEY="v1.0-813cdd84bbaafc42b91a1aa6-5dd279624202470da1debda7c85b65b5eba2a73e3e1b0fad8d65fd21a57ce5587bdc0db871098440a52c035ddf31304c268f19cf3b7cd5f21a379634a0f06bd5ea2455f9"
declare -x CF_ZONEID_GHOSTBRIDGETECH="44e82825999f76048b62999a8c0a1446"
declare -x CF_ZONEID_HOBSONSCHOICENET="1dc162b206d5a70dd034c4603f83b063"
declare -x CF_ZONEID_JEREMYTECHNET="03be45f974baeeb27c1e93b9ea72fda5"
declare -x CODEX_MANAGED_BY_NPM="1"
declare -x ENABLE_GEMINI_CLI_PROVIDER="1"
declare -x GH_TOKEN="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"
declare -x GOOGLE_AI_REGION="us-east1"
declare -x GOOGLE_APPLICATION_CREDENTIALS="/home/jeremy/.config/gcloud/application_default_credentials.json"
declare -x GOOGLE_CLOUD_PROJECT="op-dbus-ent-20260211-1621"
declare -x GOOGLE_CLOUD_QUOTA_PROJECT="op-dbus-ent-20260211-1621"
declare -x GOOGLE_CLOUD_REGION="us-east1"
declare -x GOOGLE_GENAI_USE_GCA="false"
declare -x GOOGLE_GENAI_USE_VERTEXAI="false"
declare -x HF_EMAIL="jeremy@ghostbridge.tech"
declare -x HF_TOKEN="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"
declare -x HOME="/home/jeremy"
declare -x HOSTKEY_API_KEY="575dfaf190e1d5b1-439297214e04dd15"
declare -x HOSTKEY_PIN="19421942"
declare -x HOSTKEY_SERVERID="166213"
declare -x LANG="C.UTF-8"
declare -x LANGUAGE
declare -x LC_ADDRESS
declare -x LC_COLLATE="C"
declare -x LC_CTYPE
declare -x LC_INDENTIFICATION
declare -x LC_MEASUREMENT
declare -x LC_MESSAGES
declare -x LC_MONETARY
declare -x LC_NAME
declare -x LC_NUMERIC
declare -x LC_PAPER
declare -x LC_TELEPHONE
declare -x LC_TIME
declare -x LLM_PROVIDER="gemini-cli"
declare -x LOGNAME="jeremy"
declare -x MAIL="/var/mail/jeremy"
declare -x MOTD_SHOWN="pam"
declare -x NVM_DIR="/home/jeremy/.nvm"
declare -x OLLAMA_API_KEY="9153edc4dc194f2d96e29721268837c7.IAks11054IyW6xbXSzcfxgdh"
declare -x OPENCLAW_GATEWAY_PASSWORD="O52131o4"
declare -x PAPERSPACE_API_KEY="4d8b392532a67e2625202723520eb5"
declare -x PAPERSPACE_NOTEBOOK_ID="naq3jqa7q3"
declare -x PAPERSPACE_PROJECT_ID="pu02aylj1ic"
declare -x PAPERSPACE_WORKSPACE_ID="t9hrlpxjj9"
declare -x PATH="/home/jeremy/.local/bin:/home/jeremy/.codex/tmp/arg0/codex-arg08gikJ8:/usr/lib/node_modules/@openai/codex/node_modules/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl/path:/home/jeremy/.local/bin:/home/jeremy/.nvm/versions/node/v24.13.0/bin:/home/jeremy/.cargo/bin:/home/jeremy/.local/bin:/usr/local/bin:/usr/bin:/home/jeremy/android-studio/bin"
declare -x PINECONE_API_KEY="pcsk_3dmyep_V7paYD38ukAzTUB7xgTQMmcRC2jUstQAfaRJNVX3y5iTnzX7M9bb69uYw7Yik4"
declare -x PINECONE_INDEXES="sms-messages:sms-messages-to7co8x.svc.aped-4627-b74a.pinecone.io"
declare -x SHELL="/bin/bash"
declare -x SHLVL="2"
declare -x SSH_CLIENT="97.221.123.78 46920 2222"
declare -x SSH_CONNECTION="97.221.123.78 46920 148.113.204.83 2222"
declare -x SSH_TTY="/dev/pts/0"
declare -x TERM="xterm-256color"
declare -x USER="jeremy"
declare -x XDG_DATA_DIRS="/home/jeremy/.local/share/flatpak/exports/share:/var/lib/flatpak/exports/share:/usr/local/share:/usr/share"
declare -x ZEN_CODER_CLIENT_ID="4f3716fb-df0f-49d0-8297-617254224cd9"
declare -x ZEN_CODER_SECRET_KEY="5d5bccb9-dee6-4a37-9f5d-705198c4ffa8"
